/*
Programming Project 1.6 (Pg 55)

Write a program that prints the outline of a
	tree using asterisk (*) characters.
At least 7 lines tall

*/
public class PP1_6
{
	public static void main(String[] args)
	{
		//Program goes here
		System.out.println("    *");
		System.out.println("   * *");
		System.out.println("  *   *");
		System.out.println(" *     *");
		System.out.println("**** ****");
		System.out.println("   * *");
		System.out.println("   ***");
	}
}