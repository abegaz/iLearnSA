/*
Programming Project 1.8 (Pg 55)

Write a program that prints the phrase "Knowledge is Power"
 a. on one line

 	Knowledge is Power

 b. on three lines, one word per line, with the words
 	centered relative to each other

 	Knowledge
 	   is
 	  Power

 c. inside a box made up of the characters '=' and '|'

 	|=========|
 	|Knowledge|
 	|   is    |
 	|  Power  |
	|=========|
*/
public class PP1_8
{
	public static void main(String[] args)
	{
		System.out.println("Knowledge is Power");
		System.out.println("");
		System.out.println("Knowledge");
		System.out.println("   is");
		System.out.println("  Power");
		System.out.println("");
		System.out.println("|=========|");
		System.out.println("|Knowledge|");
		System.out.println("|   is    |");
		System.out.println("|  Power  |");
		System.out.println("|=========|");
	}
}