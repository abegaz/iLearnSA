/*
Written by JET
Date: Jan 25, 2016
*/
public class HelloWorld
{
	public static void main(String[] args)
	{
		//Prints hello world
		System.out.println("Hello, World!");
		System.out.println("       My name is JET");
		System.out.println("This");
		System.out.println("     is");
		System.out.println("        on");
		System.out.println("           another");
		System.out.println("                   line!");
	}
}
/*
Program requirements:
Need to create a program to print hello world

*/