import java.util.Random;
public class Die
{
	//States
	private int faceValue;
	private int numberOfSides;

	//Constructors
	public Die()
	{
		numberOfSides = 6;
		rollDie();
	}
	public Die(int sides)
	{
		numberOfSides = sides;
		rollDie();
	}

	//Behaviors
	public void rollDie()
	{
		Random rand = new Random();
		faceValue = rand.nextInt(numberOfSides) + 1;
	}

	//toString
	public String toString()
	{
		return numberOfSides + " sided die has a value of " + faceValue;
	}
	//Accessors/Getters
	public int getFaceValue()
	{
		return faceValue;
	}
	public int getNumberOfSides()
	{
		return numberOfSides;
	}
	//Mutators/Setters
	public void setFaceValue(int fv)
	{
		faceValue = fv;
	}
	public void setNumberOfSides(int nos)
	{
		numberOfSides = nos;
	}

}