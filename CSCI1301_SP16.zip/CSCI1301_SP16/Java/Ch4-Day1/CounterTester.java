//PP4.1 on page 202
public class CounterTester
{
	public static void main(String[] args)
	{
		//create Counter object
		Counter c1 = new Counter();

		//print Counter
		System.out.println(c1);

		//click Counter
		c1.click();
		c1.click();
		c1.click();
		c1.click();
		c1.click();

		//print Counter
		System.out.println(c1);

		//call getCount()
		int currentCount = c1.getCount();
		c1.click();
		c1.click();
		System.out.println("The old count was " + currentCount);
		System.out.println(c1);
	}
}