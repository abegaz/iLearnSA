public class RollDice
{
	public static void main(String[] args)
	{
		//Create instances of the Die class
		Die d1 = new Die();
		Die d2 = new Die(20);

		//print the dice
		System.out.println(d1);
		System.out.println(d2);

		//roll the dice
		d1.rollDie();
		d2.rollDie();

		//print the dice
		System.out.println(d1);
		System.out.println(d2);

		//set the dice values
		d1.setFaceValue(6);
		d2.setFaceValue(20);

		//print the dice
		System.out.println(d1);
		System.out.println(d2);
	}
}