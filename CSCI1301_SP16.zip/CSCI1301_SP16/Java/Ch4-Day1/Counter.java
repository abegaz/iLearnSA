//PP4.1 on page 202
public class Counter
{
	//States
	private int count;

	//Constructors
	public Counter()
	{
		count = 0;
	}

	//Behaviors
	public void click()
	{
		count++;
		//count += 1;
		//count = count + 1;
	}
	//toString
	public String toString()
	{
		return "The current count is " + count;
	}
	//Accessors (getters)
	public int getCount()
	{
		return count;
	}
	//Mutators (setters)
}