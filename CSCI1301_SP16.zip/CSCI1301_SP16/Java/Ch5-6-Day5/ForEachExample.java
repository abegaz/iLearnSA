import java.util.ArrayList;
public class ForEachExample
{
	public static void main(String[] args)
	{
		ArrayList<String> words = new ArrayList<String>();
		words.add("Hello");
		words.add(", ");
		words.add("World");
		words.add("!");
		for(int i = 0; i < words.size(); i++)
		{
			System.out.print(words.get(i));
		}
		System.out.println();

		for(String word : words)
		{
			System.out.println(word.length() + " : " + word);
		}

		ArrayList<Integer> numbers = new ArrayList<Integer>();
		numbers.add(5);
		numbers.add(10);
		numbers.add(15);
		numbers.add(20);
		numbers.add(25);

		int sum = 0;
		for(Integer number : numbers)
		{
			sum += number;
		}
		System.out.println(sum);
		System.out.println(sum/numbers.size());

	}
}