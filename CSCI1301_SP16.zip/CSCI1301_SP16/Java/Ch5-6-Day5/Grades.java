import java.util.Scanner;
import java.util.ArrayList;
public class Grades
{
	public static void main(String[] args)
	{
		//create scanner object
		Scanner scan = new Scanner(System.in);
		//create ArrayList object to hold grades
		ArrayList<Integer> grades = new ArrayList<Integer>();

		//ask user for 10 grades and store in the ArrayList
		for(int i = 0;i < 10;i++)
		{
			System.out.print("Enter a grade: ");
			grades.add(scan.nextInt());
		}

		//use a for-each style loop to print out the grades
		//and their letter equivalent
		//for-each grade that is inside of grades
		int sum = 0;
		for(Integer grade : grades)
		{
			/*
			System.out.print(grade + " - ");
			switch(grade%10)
			{
				case 10:
				case 9:
					System.out.println("A");
					break;
				case 8:
					System.out.println("B");
					break;
				case 7:
					System.out.println("C");
					break;
				case 6:
					System.out.println("D");
					break;
				default:
					System.out.println("F");
					break;
			}
			*/
			System.out.print(grade + " - ");
			if(grade >= 90)
				System.out.println("A");
			else if(grade >= 80)
				System.out.println("B");
			else if(grade >= 70)
				System.out.println("C");
			else if(grade >= 60)
				System.out.println("D");
			else
				System.out.println("F");
			sum += grade;
		}
		System.out.println("Average: " + (sum/grades.size()));
	}
}