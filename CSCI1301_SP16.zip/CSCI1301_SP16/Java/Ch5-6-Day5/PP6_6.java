public class PP6_6
{
	public static void main(String[] args)
	{
		//create coin object
		Coin myCoin = new Coin();

		//initialize variables to hold number of heads/tails
		int heads = 0;
		int tails = 0;

		//loop 100 times
		for(int i = 0; i < 100;i++)
		{
			//flip coin
			myCoin.flip();
			//count number of heads/tails
			if(myCoin.isHeads())
				heads++;
			else
				tails++;
		}

		//print number of heads/tails
		System.out.println("Number of heads: " + heads);
		System.out.println("Number of tails: " + tails);
	}
}