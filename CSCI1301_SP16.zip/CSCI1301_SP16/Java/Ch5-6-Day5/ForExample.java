public class ForExample
{
	public static void main(String[] args)
	{
		//loop runs 10 times
		System.out.println("i zero to ten");
		for(int i = 0; i < 10; i++)
		{
			System.out.println(i);
		}
		System.out.println("i zero to ten by two");
		for(int i = 0; i < 10; i = i + 2)
		{
			System.out.println(i);
		}
		System.out.println("i : j");
		for(int i = 0; i < 5; i++)
		{
			for(int j = 5; j > 0; j--)
			{
				System.out.println(i + " : " + j);
			}
		}
		String s = "Hello, World!";
		for(int i = 0; i < s.length(); i++)
		{
			System.out.println(s.charAt(i));
		}
	}
}