import java.util.ArrayList;
public class ArrayListExample
{
	public static void main(String[] args)
	{
		ArrayList<Integer> numbers = new ArrayList<Integer>();
		numbers.add(5);
		numbers.add(10);
		numbers.add(15);
		numbers.add(20);
		numbers.add(25);

		System.out.println("Items in ArrayList:" + numbers.size());

		for(int i = 0; i < numbers.size(); i++)
		{
			System.out.println(numbers.get(i));
		}

		System.out.println("Items in ArrayList:" + numbers.size());

		System.out.println(numbers.remove(2));
		System.out.println("Items in ArrayList:" + numbers.size());

		ArrayList<String> words = new ArrayList<String>();
		words.add("Hello");
		words.add(", ");
		words.add("World");
		words.add("!");
		for(int i = 0; i < words.size(); i++)
		{
			System.out.print(words.get(i));
		}
		System.out.println();
	}
}