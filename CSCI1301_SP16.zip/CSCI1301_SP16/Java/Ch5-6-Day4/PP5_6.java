/*
Use the Coin class provided
Create two coins, flip the coins until one of them comes up heads
	three times in a row
After each flip, print out what each coin came up as
When complete, print how many times the coins were flipped and which coin won
*/
public class PP5_6
{
	public static void main(String[] args)
	{
		//Create coin objects
		Coin c1 = new Coin();
		Coin c2 = new Coin();

		//create variables to hold flips and number of consecutive heads
		int c1heads = 0;
		int c2heads = 0;
		int flips = 0;

		//loop that ends when one coin reaches three heads in a row
		System.out.println("Coin 1 :: Coin 2");
		do{
			//flip coins
			c1.flip();
			c2.flip();
			flips++;//count number of flips

			//print what each coin flipped each time
			System.out.println(c1 + "  :: " + c2);

			//increment consecutive heads counters
			if(c1.isHeads())
				c1heads++;
			else
				c1heads = 0;
			//conditional operator equivalent to if/else
			c2heads = (c2.isHeads()) ? c2heads + 1 : 0;

			//Test to confirm counters working correctly
			//System.out.println(c1heads + "  :: " + c2heads);
		}while(c1heads < 3 && c2heads < 3);
		//print which coin wins
		if(c1heads == 3 && c2heads == 3)
			System.out.println("Coin 1 and 2 Tied");
		else if(c1heads == 3)
			System.out.println("Coin 1 Wins!");
		else
			System.out.println("Coin 2 Wins!");
		//print number of flips
		System.out.println("Number of flips: " + flips);
	}
}