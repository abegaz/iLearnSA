/*
Create a rock/paper/scissors game
Keep playing until the user chooses to quit
Keep a running total of number of games played
Keep a running total of games won by the computer and player and ties
Output statistics at the end
*/
import java.util.Scanner;
import java.util.Random;
public class PP5_7
{
	public static void main(String[] args)
	{
		//Create object of scanner class
		Scanner scan = new Scanner(System.in);
		//Random generator for computer choices
		Random gen = new Random();

		//Variables for holding running totals
		int games = 0;
		int computer = 0;
		int player = 0;
		int ties = 0;
		String playerChoice = "";
		int computerChoice = 0;
		boolean quit = false;

		//loop to play game
		do{
			System.out.print("Choose (R)ock, (P)aper, (S)cissors [-1 to quit]: ");
			playerChoice = scan.next().toLowerCase();
			computerChoice = gen.nextInt(3);
			switch(playerChoice.charAt(0))
			{
				case 'r':
					games++;
					System.out.print("Computer chose ");
					switch(computerChoice)
					{
						case 0://rock
							System.out.println("Rock");
							ties++;
							break;
						case 1://paper
							System.out.println("Paper");
							computer++;
							break;
						case 2://scissors
							System.out.println("Scissors");
							player++;
							break;
					}

					break;
				case 'p':
					games++;
					System.out.print("Computer chose ");
					if(computerChoice == 0)//rock
					{
						System.out.println("Rock");
						player++;
					}
					else if(computerChoice == 1)//paper
					{
						System.out.println("Paper");
						ties++;
					}
					else//scissors
					{
						System.out.println("Scissors");
						computer++;
					}
					break;
				case 's':
					games++;
					System.out.print("Computer chose ");
					switch(computerChoice)
					{
						case 0://rock
							System.out.println("Rock");
							computer++;
							break;
						case 1://paper
							player++;
							System.out.println("Paper");
							break;
						case 2://scissors
							ties++;
							System.out.println("Scissors");
							break;
					}
					break;
				default:
					quit = true;
					break;
			}
		}while(!quit);

		//output statistics
		System.out.println("Total games played: " + games);
		System.out.println("Games won by player: " + player);
		System.out.println("Games won by computer: " + computer);
		System.out.println("Ties: " + ties);

	}
}