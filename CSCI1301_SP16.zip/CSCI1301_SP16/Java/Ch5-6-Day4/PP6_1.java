/*
Ask the user for a positive whole number
Use a while loop to sum up all the even numbers between zero and
	the number entered
*/
import java.util.Scanner;
public class PP6_1
{
	public static void main(String[] args)
	{
		//Create object of scanner class
		Scanner scan = new Scanner(System.in);
		//Ask user for a number
		System.out.print("Enter a number: ");
		int number = scan.nextInt();

		int sum = 0;
		int counter = 0;
		//loop to sum up even numbers
		do{
			//increase sum by the current counter value
			sum += counter;
			//print equation
			if(counter == 0)
				System.out.print(counter);
			else
				System.out.print(" + " + counter);
			//set counter to next even number
			counter += 2;
		}while(counter <= number);

		//output total
		System.out.println(" = " + sum);
	}
}