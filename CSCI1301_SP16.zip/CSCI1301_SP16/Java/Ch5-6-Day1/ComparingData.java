public class ComparingData
{
	public static void main(String[] args)
	{
		char c1 = '0';//48
		char c2 = 'A';//65
		char c3 = 'a';//97

		if(c1 < c2)
		{
			System.out.println(c1 + " < " + c2);
		}
		if(c2 < c3)
		{
			System.out.println(c2 + " < " + c3);
		}

		String s1 = "Justin";
		String s2 = "jet";
		String s3 = "Justin";

		if(s1.compareTo(s2) > 0)
		{
			System.out.println(s1 + " > " + s2);
		}
		else if(s1.compareTo(s2) < 0)
		{
			System.out.println(s1 + " < " + s2);
		}

		if(s1.toLowerCase().compareTo(s2.toLowerCase()) > 0)
		{
			System.out.println(s1.toLowerCase() + " > " + s2.toLowerCase());
		}
		else if(s1.toLowerCase().compareTo(s2.toLowerCase()) < 0)
		{
			System.out.println(s1.toLowerCase() + " < " + s2.toLowerCase());
		}

		if(s1.equals(s3))
		{
			System.out.println(s1 + " is equal to " + s3);
		}
		if(s1 == s3)
		{
			System.out.println(s1 + " is equal to " + s3);
		}
		else
		{
			System.out.println("Can't compare objects with ==");
		}

		double d1 = 5.123456789;
		double d2 = 5.123456788;
		final double CLOSE_ENOUGH = 0.00001;
		if(Math.abs(d1-d2) < CLOSE_ENOUGH)
		{
			System.out.println(d1 + " is about equal to " + d2);
		}
	}
}