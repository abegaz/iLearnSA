public class BasicConditional
{
	public static void main(String[] args)
	{
		int num1 = 5;
		int num2 = 10;
		int num3 = 10;
		if(num1 > num2)
			System.out.println("Num 1 is greater than Num 2");
		if(num1 < num2)
			System.out.println("Num 1 is less than Num 2");
		if(num2 == num3)
			System.out.println("Num 2 is equal to Num 3");
		if(num2 != num3)
			System.out.println("Num 2 is not equal to Num 3");
	}
}