public class LogicalOperators
{
	public static void main(String[] args)
	{
		int num1 = 5;
		int num2 = 10;
		int num3 = 10;
		if(num1 > num2 || num1 < num3)
			System.out.println("Num 1 is greater than Num 2 OR Num 1 is less than Num 3");
		if(num1 < num2 && num1 > num3)
			System.out.println("Num 1 is less than Num 2 AND Num 1 is less than Num 3");
		if(!(num1 > num2))
			System.out.println("NOT: Num 1 is greater than Num 2");
	}
}