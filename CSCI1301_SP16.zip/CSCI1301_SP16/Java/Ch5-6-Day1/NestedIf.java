import java.util.Scanner;
public class NestedIf
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 3 numbers: ");
		int num1 = scan.nextInt();
		int num2 = scan.nextInt();
		int num3 = scan.nextInt();

		if(num1 < num2)
		{
			System.out.println("if 1 is true");
			if(num2 == num3)
			{
				System.out.println("if 2 is true");
				if(num1 > num3)
				{
					System.out.println("if 3 is true");
				}
				else
				{
					System.out.println("if 3 is false");
				}
			}
			else
			{
				System.out.println("if 2 is false");
			}
		}
		else
		{
			System.out.println("if 1 is false");
		}
	}
}