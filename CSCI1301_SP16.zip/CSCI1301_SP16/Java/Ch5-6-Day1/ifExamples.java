public class ifExamples
{
	public static void main(String[] args)
	{
		int num1 = 5;
		int num2 = 10;
		int num3 = 10;
		if(num1 > num2)
		{
			//executed if num1 > num2
			System.out.println("num1 > num2");
			num1 = 6;
		}
		else if(num1 < num2)
		{
			//executed if num1 < num2
			System.out.println("num1 < num2");
			num1 = 7;
		}
		else
		{
			//executed if both of the above are false
			System.out.println("num1 is not > or < num2");
			num1 = 4;
		}
		System.out.println(num1);
		if(num1 < num2)
		{
			System.out.println("num1 < num2");
		}
		if(num2 == num3)
		{
			System.out.println("num2 == num3");
		}
		else
		{
			System.out.println("else statement");
		}

		if(num1 < num2)
		{
			System.out.println("num1 < num2");
		}
		else if(num2 == num3)
		{
			System.out.println("num2 == num3");
		}
		else
		{
			System.out.println("else statement");
		}

		boolean b1 = true;
		boolean b2 = false;
		if(b1 && b2)
		{
		}
		else if(b1 || b2)
		{
		}
		else if(!b1)
		{
		}
		else if(!b2)
		{
		}

		boolean n1Gn2 = (num1 > num2);
		boolean n2En3 = (num2 == num3);
		if(n1Gn2 || n2En3)
		{

		}
	}
}