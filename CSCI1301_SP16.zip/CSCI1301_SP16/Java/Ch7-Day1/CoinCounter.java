public class CoinCounter
{
	public static void main(String[] args)
	{
		System.out.println("Current Coin Count:"+CoinV2.getCount());
		CoinV2 c1 = new CoinV2();
		CoinV2 c2 = new CoinV2();
		CoinV2 c3 = new CoinV2();
		CoinV2 c4 = new CoinV2();
		System.out.println("Current Coin Count:"+CoinV2.getCount());
		System.out.println("Current Coin Count:"+c1.getCount());
		System.out.println("Current Coin Count:"+c4.getCount());
	}
}