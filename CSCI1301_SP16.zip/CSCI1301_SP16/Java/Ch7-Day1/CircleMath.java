public class CircleMath
{
	public static void main(String[] args)
	{
		System.out.println("Radius:"+CircleFormulas.getCircleRadius(10));
		System.out.println("Diameter:"+CircleFormulas.getCircleDiameter(5));
		System.out.println("Circumference:"+CircleFormulas.getCircleCircumference(5));
		System.out.println("Area:"+CircleFormulas.getCircleArea(5));
		System.out.println();
		CircleFormulas.setRadius(10);
		System.out.println("Radius:"+CircleFormulas.getCircleRadius());
		System.out.println("Diameter:"+CircleFormulas.getCircleDiameter());
		System.out.println("Circumference:"+CircleFormulas.getCircleCircumference());
		System.out.println("Area:"+CircleFormulas.getCircleArea());
	}
}