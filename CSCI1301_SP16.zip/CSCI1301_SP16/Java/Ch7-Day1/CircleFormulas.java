public class CircleFormulas
{
	private static double r = 5;
	//setRadius
	public static void setRadius(double radius)
	{
		r = radius;
	}
	public static void setDiameter(double diameter)
	{
		r = diameter/2;
	}

	//getRadius (d/2)
	public static double getCircleRadius(double diameter)
	{
		r = diameter/2;
		return r;
	}
	public static double getCircleRadius()
	{
		return r;
	}

	//getDiameter (r*2)
	public static double getCircleDiameter(double radius)
	{
		r = radius;
		return radius*2;
	}
	public static double getCircleDiameter()
	{
		return getCircleDiameter(r);
	}

	//getCircumference (2*PI*r)
	public static double getCircleCircumference(double radius)
	{
		r = radius;
		return 2 * Math.PI * radius;
	}
	public static double getCircleCircumference()
	{
		return getCircleCircumference(r);
	}

	//getArea (PI*r^2)
	public static double getCircleArea(double radius)
	{
		r = radius;
		return Math.PI * Math.pow(radius, 2);
	}
	public static double getCircleArea()
	{
		return getCircleArea(r);
	}
}