import java.util.Random;
import java.util.Arrays;
public class ArrayExamples
{
	public static void main(String[] args)
	{
		Random rand = new Random();
		int[] scores = new int[10];
		scores[0] = 50;
		scores[1] = 75;
		//System.out.println(scores[0]);
		for(int i = 0; i < 10; i++)
		{
			scores[i] = rand.nextInt(100)+1;
		}
		for(int i = 0; i < 10; i++)
		{
			System.out.println(scores[i]);
		}
		System.out.println("Random score: " + scores[rand.nextInt(10)]);
		//Out of bounds error: 10 is outside of array size
		//System.out.println(scores[10]);

		Coin[] myCoins = new Coin[100];
		//produces null because object not created
		//System.out.println(myCoins[0]);
		for(int i = 0; i < myCoins.length; i++)
		{
			myCoins[i] = new Coin();
		}
		int heads = 0, tails = 0;
		for(int i = 0; i < myCoins.length; i++)
		{
			if(myCoins[i].isHeads())
				heads++;
			else
				tails++;
		}
		System.out.println("Heads: " + heads);
		System.out.println("Tails: " + tails);

		Die[] myDice = new Die[10];
		for(int i = 0; i < myDice.length; i++)
		{
			myDice[i] = new Die();
		}
		System.out.println("Unsorted");
		for(int i = 0; i < myDice.length; i++)
		{
			System.out.println(myDice[i]);
		}
		Arrays.sort(myDice);
		System.out.println("Sorted");
		for(int i = 0; i < myDice.length; i++)
		{
			System.out.println(myDice[i]);
		}
	}
}