import java.util.Scanner;
import java.io.IOException;
import java.io.File;
public class FileCompare
{
	public static void main(String[] args) throws IOException
	{
		//create scanner objects to read from files
		Scanner file1 = new Scanner(new File("File1.txt"));
		Scanner file2 = new Scanner(new File("File2.txt"));

		//line counter
		int lineNumber = 1;

		//loop through file contents
		while(file1.hasNextLine() || file2.hasNextLine())
		{
			/*
			//used for testing reading from files
			if(file1.hasNextLine())
				System.out.println("File 1:" + file1.nextLine());
			if(file2.hasNextLine())
				System.out.println("File 2:" + file2.nextLine());
			*/
			//compare each line
			System.out.println("Line " + lineNumber + ":");
			//print if the lines are different
			if(file1.hasNextLine() && file2.hasNextLine())
			{
				String temp1 = file1.nextLine();
				String temp2 = file2.nextLine();
				if(temp1.equals(temp2))
				{
					//printed if the lines are exactly the same
					System.out.println("[[SAME]]");
				}
				else if(temp1.toLowerCase().equals(temp2.toLowerCase()))
				{
					//printed if the lines are the same when both lower case
					System.out.println("[[SIMILAR]]");
				}
				else
				{
					//print both lines because they are different
					System.out.println(temp1);
					System.out.println(temp2);
				}
			}
			else if(file1.hasNextLine())
			{
				//print the extra line from file 1
				System.out.println(file1.nextLine());
				System.out.println("[[FILE2]]");
			}
			else
			{
				//print the extra line from file 2
				System.out.println("[[FILE1]]");
				System.out.println(file2.nextLine());
			}
			//increment the line counter
			lineNumber++;
		}
	}
}