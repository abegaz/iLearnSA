import java.util.Scanner;
public class BottlesOfBeer
{
	public static void main(String[] args)
	{
		//create scanner object
		Scanner scan = new Scanner(System.in);

		//ask user for a number
		System.out.print("Enter a number: ");
		int verses = scan.nextInt();
		int verses2 = verses;//copy of number entered for second loop

		//start song at 100
		for(int i = 100; i > 0 && verses2 > 0; verses2--)
		{
			System.out.println(i + " bottles of beer on the wall");
			System.out.println(i + " bottles of beer");
			System.out.println("If one of those bottles should happen to fall");
			i--;
			System.out.println(i + " bottles of beer on the wall\n");
		}

		//print verses of song from number entered to zero
		//start song at number given
		while(verses > 0)
		{
			System.out.println(verses + " bottles of beer on the wall");
			System.out.println(verses + " bottles of beer");
			System.out.println("If one of those bottles should happen to fall");
			verses--;
			System.out.println(verses + " bottles of beer on the wall\n");
		}
	}
}