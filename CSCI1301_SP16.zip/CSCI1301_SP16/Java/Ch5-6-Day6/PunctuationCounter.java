import java.util.Scanner;
import java.io.IOException;
import java.io.File;
public class PunctuationCounter
{
	public static void main(String[] args) throws IOException
	{
		//create scanner object to read from a file
		Scanner file3 = new Scanner(new File("File3.txt"));

		//initialize punctuation counters
			//count the following: . , ? !
		int period = 0;//.
		int comma = 0;//,
		int ques = 0;//?
		int excl = 0;//!

		//loop through file
		while(file3.hasNextLine())
		{
			//test reading file
			//System.out.println(file3.nextLine());

			//read line from file into String variable
			String line = file3.nextLine();
			//loop through each line
			for(int i = 0; i < line.length(); i++)
			{
				//count different punctuation
				//line.charAt(i)//character at given position in String
				switch(line.charAt(i))
				{
					case '.':
						period++;
						break;
					case ',':
						comma++;
						break;
					case '?':
						ques++;
						break;
					case '!':
						excl++;
						break;
				}
			}
		}

		//print table of results
		System.out.println("*********");
		System.out.println("* . * " + period + " * ");
		System.out.println("*********");
		System.out.println("* , * " + comma + " * ");
		System.out.println("*********");
		System.out.println("* ? * " + ques + " * ");
		System.out.println("*********");
		System.out.println("* ! * " + excl + " * ");
		System.out.println("*********");

	}
}