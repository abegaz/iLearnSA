public class Shapes
{
	public static void main(String[] args)
	{
		System.out.println("Bottom Left Corner");
		for(int i = 1; i <= 10; i++)
		{
			for(int j = 1; j <= i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("Top Left Corner");
		for(int i = 0; i < 10; i++)
		{
			for(int j = 1; j <= 10-i; j++)
			{
				System.out.print("*");
			}
			System.out.println();
		}
		System.out.println("Bottom Right Corner");
		for(int i = 0; i < 10; i++)
		{
			for(int j = 1; j <= 10; j++)
			{
				if(j >= 10-i)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		System.out.println("Top Right Corner");
		for(int i = 1; i <= 10; i++)
		{
			for(int j = 1; j <= 10; j++)
			{
				if(j >= i)
					System.out.print("*");
				else
					System.out.print(" ");
			}
			System.out.println();
		}
		System.out.println("Diamond");
		for(int i = 1; i <= 9; i++)
		{
			for(int j = 1; j <= 9; j++)
			{
				if(j <= Math.abs(5-i) || j > 9 - Math.abs(5-i))
					System.out.print(" ");
				else
					System.out.print("*");
			}
			System.out.println();
		}

	}
}