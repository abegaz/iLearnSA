import java.text.DecimalFormat;
import java.util.Scanner;
public class MultiSphere
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);

		DecimalFormat df = new DecimalFormat("0.00##");
		//create objects of the Sphere class
		System.out.print("Enter Sphere 1's Diameter: ");
		Sphere s1 = new Sphere(scan.nextDouble());
		System.out.print("Enter Sphere 2's Diameter: ");
		Sphere s2 = new Sphere(scan.nextDouble());
		System.out.print("Enter Sphere 3's Diameter: ");
		Sphere s3 = new Sphere(scan.nextDouble());

		//Test the methods of the Sphere class
		System.out.println(s1);
		System.out.println(s2);
		System.out.println(s3);

		System.out.print("Enter a new diameter for Sphere 1: ");
		s1.setDiameter(scan.nextDouble());
		System.out.println(s1);

		double average = 0;
		average += s1.calcVolume();
		average += s2.calcVolume();
		average += s3.calcVolume();
		average /= 3;
		System.out.println("The average volume is " + df.format(average));
	}
}