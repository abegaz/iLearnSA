import java.text.DecimalFormat;
public class Sphere
{
	//States
	//Store Diameter as a double
	private double diameter;
	private double radius;

	//Behaviors
	//Constructor
	public Sphere(double diam)
	{
		diameter = diam;
		radius = diameter / 2;
	}

	//Getter(Accessor)
	public double getDiameter()
	{
		return diameter;
	}
	public double getRadius()
	{
		return radius;
	}

	//Setter(Mutator)
	public void setDiameter(double diam)
	{
		diameter = diam;
		radius = diameter / 2;
	}
	public void setRadius(double rad)
	{
		radius = rad;
		diameter = radius * 2;
	}

	//Volume (4/3)*PI*(radius^3)
	public double calcVolume()
	{
		double volume = (4.0/3.0)*Math.PI*Math.pow(radius, 3);
		//double volume = (4.0/3.0)*Math.PI*(radius*radius*radius);
		return volume;
	}

	//Surface Area 4*PI*(radius^2)
	public double calcSurfaceArea()
	{
		double surfaceArea = 4*Math.PI*Math.pow(radius, 2);
		return surfaceArea;
	}

	//toString
	public String toString()
	{
		DecimalFormat df = new DecimalFormat("0.00##");
		return "This sphere has a diameter of " + df.format(diameter) + ".\n" +
			"The volume is " + df.format(calcVolume()) + ".\n" +
			"The surface area is " + df.format(calcSurfaceArea()) + ".\n";
	}
}