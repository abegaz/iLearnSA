import java.text.NumberFormat;
public class CurrencyPercent
{
	public static void main(String[] args)
	{
		NumberFormat currency = NumberFormat.getCurrencyInstance();
		NumberFormat percent = NumberFormat.getPercentInstance();

		System.out.println(currency.format(3.11534436457));
		System.out.println(percent.format(0.01));

	}
}