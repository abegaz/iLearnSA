/*
Generate a UNG ID
Ask the user for their First, Middle, and Last Name
Generate 4 random numbers

First:Justin
Middle:E
Last:Turner

UNG ID: JETurn1234
*/
import java.util.Scanner;
import java.util.Random;
public class UNGID
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter your first name: ");
		String first = scan.next();
		System.out.print("Enter your middle name: ");
		String middle = scan.next();
		System.out.print("Enter your last name: ");
		String last = scan.next();

		Random gen = new Random();
		String id = "" + first.charAt(0);
		id += middle.charAt(0);
		id += last.substring(0, 4);



		id += gen.nextInt(10);
		id += gen.nextInt(10);
		id += gen.nextInt(10);
		id += gen.nextInt(10);

		id = id.toUpperCase();

		System.out.println("Your UNG ID is: " + id);
	}
}