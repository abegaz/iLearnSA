public class StringMutation
{
	public static void main(String[] args)
	{

		String original = "Change is inevitable!";
		String mutation1, mutation2, mutation3, mutation4, mutation5;

		//print original
		System.out.println("Original String: " + original);
		//print original length
		System.out.println("Original String: " + original.length());

		//mutation1 concat()
		//same as mutation1 = original + " more text";
		mutation1 = original.concat(" more text");
		//mutation2 toUpperCase()
		mutation2 = original.toUpperCase();
		//mutation3 replace('','')
		mutation3 = original.replace('n','N');
		//mutation4 substring(start, end)
		mutation4 = original.substring(6, original.length()-5);
		//mutation4 substring(start)
		mutation5 = original.substring(6);

		//print mutations
		System.out.println("Mutation 1 String: " + mutation1);
		System.out.println("Mutation 2 String: " + mutation2);
		System.out.println("Mutation 3 String: " + mutation3);
		System.out.println("Mutation 4 String: " + mutation4);
		System.out.println("Mutation 5 String: " + mutation5);
		//print mutation4 length
		System.out.println("Mutation 4 String: " + mutation4.length());
		System.out.println("Mutation 5 String: " + mutation5.length());

		System.out.println(original.charAt(5));
	}
}