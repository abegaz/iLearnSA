import java.util.Scanner;
public class Aliases
{
	public static void main(String[] args)
	{
		Scanner scan1 = new Scanner(System.in);
		Scanner scan2 = scan1;
		//System.out.print("Enter data:");
		//String data1 = scan1.next();

		System.out.println("Scan1 delimiter:" + scan1.delimiter());
		System.out.println("Scan2 delimiter:" + scan2.delimiter());

		scan2.useDelimiter(",");

		System.out.println("Scan1 delimiter:" + scan1.delimiter());
		System.out.println("Scan2 delimiter:" + scan2.delimiter());
	}
}