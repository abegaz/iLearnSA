public class MathEquations
{
	public static void main(String[] args)
	{
		double x = 4.499;
		int y = 4;

		System.out.println("y: " + y + " :: abs(y): " + Math.abs(y));
		System.out.println("x: " + x + " :: sqrt(x): " + Math.sqrt(x));
		System.out.println("x^y: " + Math.pow(x, y));

		System.out.println("floor(x): " + Math.floor(x) + " :: ceil(x): " + Math.ceil(x) + " :: round(x): " + Math.round(x));

		System.out.println(Math.PI);
		System.out.println(Math.E);
	}
}