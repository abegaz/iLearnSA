import java.text.DecimalFormat;
public class CircleStats
{
	public static void main(String[] args)
	{
		int radius = 5;
		double area, circumference;

		area = Math.PI * Math.pow(radius, 2);
		circumference = 2 * Math.PI * radius;

		DecimalFormat fmt = new DecimalFormat ("0.00#");
		System.out.println("The circle's area: " + fmt.format(area));
		System.out.println("The circle's circumference: " + fmt.format(circumference));
	}
}