import java.util.*;
public class RandomNumbers
{
	public static void main(String[] args)
	{
		Random generator = new Random();
		int num1;
		double num2;

		num1 = generator.nextInt();
		System.out.println("Random Number 1: " + num1);
		num1 = generator.nextInt(11);
		System.out.println("From 0 to 10: " + num1);
		num1 = generator.nextInt(10) + 1;
		System.out.println("From 1 to 10: " + num1);


		num2 = generator.nextDouble();
		System.out.println("Random Number 2: " + num2);
		num2 = generator.nextDouble() * 6;//0.0 to 5.9999
		System.out.println("From 0-5.9999: " + num2);
	}
}