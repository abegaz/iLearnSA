import java.util.Random;
public class Die implements Comparable<Die>
{
	/*** States ***/
	private int faceValue;
	private int numberOfSides;

	/*** Constructor ***/
	//Die Constructor
	public Die()
	{
		numberOfSides = 6;
		rollDie();
	}
	public Die(int sides)
	{
		numberOfSides = sides;
		rollDie();
	}
	/*** Behaviors ***/
	//rollDie Behavior
	public int rollDie()
	{
		Random gen = new Random();
		faceValue = gen.nextInt(numberOfSides) + 1;
		return faceValue;
	}
	//accessor for faceValue
	public int getFaceValue()
	{
		return faceValue;
	}
	//mutator for faceValue
	public void setFaceValue(int value)
	{
		faceValue = value;
	}
	//accessor for numberOfSides
	public int getNumberOfSides()
	{
		return numberOfSides;
	}
	//no mutator for numberOfSides

	//toString method
	public String toString()
	{
		String output = numberOfSides + " sided die, with a value of " + faceValue;
		return output;
	}

	//compareTo method
	// d1.compareTo(d2)
	public int compareTo(Die otherDie)
	{
		//faceValue // d1 face value
		//otherDie.getFaceValue() // d2 face value
		if(faceValue > otherDie.getFaceValue())
			return 1;
		else if(faceValue < otherDie.getFaceValue())
			return -1;
		else
			return 0;
	}
}