public interface Priority
{
	//ensure priority is numeric
	//setPriority
	public void setPriority(int priority);
	//getPriority
	public int getPriority();
}