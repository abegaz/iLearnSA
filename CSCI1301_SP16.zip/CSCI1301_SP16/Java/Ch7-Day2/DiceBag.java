public class DiceBag
{
	public static void main(String[] args)
	{
		Dice bag = new Dice();//adds initial die with 6 sides
		bag.addDie();
		bag.addDie(10);
		bag.addDie();
		bag.addDie(20);
		while(bag.hasNext())
		{
			System.out.println(bag.next());
		}
	}
}