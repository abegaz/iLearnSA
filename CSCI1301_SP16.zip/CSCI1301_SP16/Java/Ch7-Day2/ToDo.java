import java.util.ArrayList;
import java.util.Collections;
public class ToDo
{
	public static void main(String[] args)
	{
		ArrayList<Task> tasks = new ArrayList<Task>();
		tasks.add(new Task("Drive to School", 1, 8, 2));
		tasks.add(new Task("CSCI 1301", 2, 3, 5));
		tasks.add(new Task("Lunch", 1));
		tasks.add(new Task("Breakfast", 1, 4));
		tasks.add(new Task("Dinner", 2));
		tasks.add(new Task("Sleep", 8, 1, 0));

		System.out.println(tasks.get(0));
		System.out.println(tasks.get(4));
		System.out.println(tasks.get(0).compareTo(tasks.get(4)));

		System.out.println();

		System.out.println("Unsorted Tasks");
		for(Task t : tasks)
			System.out.println(t);

		System.out.println();

		Collections.sort(tasks);

		System.out.println("Sorted Tasks");
		for(Task t : tasks)
			System.out.println(t);
	}
}