import java.util.ArrayList;
import java.util.Iterator;
public class Dice implements Iterator
{
	//states
	private ArrayList<Die> dice = new ArrayList<Die>();
	//constructors
	public Dice()
	{
		dice.add(new Die());
	}
	public Dice(int sides)
	{
		dice.add(new Die(sides));
	}
	//behaviors
	public void addDie()
	{
		dice.add(new Die());
	}
	public void addDie(int sides)
	{
		dice.add(new Die(sides));
	}

	//accessors
	public ArrayList<Die> getDice()
	{
		return dice;
	}

	//toString
	public String toString()
	{
		String output = "";
		for(Die currentDie : dice)
		{
			output += currentDie + "\n";
		}
		return output;
	}

	//add methods from Iterator interface
	public boolean hasNext()
	{
		if(dice.size() > 0)
			return true;
		else
			return false;
	}
	public Die next()
	{
		return dice.remove(0);
	}
	public void remove()
	{
		dice.remove(0);
	}
}