//implement the Priority interface
//implement the Combarable interface
public class Task implements Priority, Comparable<Task>, Complexity
{
	//STATES
	private int priority;
	private int complexity;
	private String name;
	private int time;

	//BEHAVIORS
	//Constructors
	public Task(String name, int time)
	{
		this.name = name;
		this.time = time;
		priority = 5;
		complexity = 1;
	}
	public Task(String name, int time, int priority)
	{
		this.name = name;
		this.time = time;
		this.priority = priority;
		complexity = 1;
	}
	public Task(String name, int time, int priority, int complexity)
	{
		this.name = name;
		this.time = time;
		this.priority = priority;
		this.complexity = complexity;
	}

	//Accessors
	public String getName()
	{
		return name;
	}
	public int getTime()
	{
		return time;
	}

	//Mutators
	public void setName(String name)
	{
		this.name = name;
	}
	public void setTime(int time)
	{
		this.time = time;
	}

	//Interface Methods
	//Priority Interface methods
	public int getPriority()
	{
		return priority;
	}
	public void setPriority(int priority)
	{
		if(priority > 0 && priority <= 10)
			this.priority = priority;
	}
	//Complexity Interface methods
	public int getComplexity()
	{
		return complexity;
	}
	public void setComplexity(int complexity)
	{
		if(complexity >= 0)
			this.complexity = complexity;
	}
	//Comparable Interface method
	public int compareTo(Task t)
	{
		if(this.priority < t.getPriority())
			return 1;
		else if(this.priority > t.getPriority())
			return -1;
		else
		{
			if(this.time > t.getTime())
				return 1;
			else if(this.time < t.getTime())
				return -1;
			else
				return 0;
		}
	}

	//toString
	public String toString()
	{
		return "Task: " + name
			+ ", Time: " + time
			+ ", Priority: " + priority
			+ ", Complexity: " + complexity;
	}
}