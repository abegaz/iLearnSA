//********************************************************************
//  Coin.java       Author: Lewis/Loftus
//
//  Represents a coin with two sides that can be flipped.
//********************************************************************

public class Coin implements Comparable<Coin>
{
	private final int HEADS = 0;
	private final int TAILS = 1;
	private static int count = 0;

	private int face;

	//-----------------------------------------------------------------
	//  Sets up the coin by flipping it initially.
	//-----------------------------------------------------------------
	public Coin()
	{
		flip();
		count++;
	}

	public static int getInstanceCount()
	{
		return count;
	}

	//-----------------------------------------------------------------
	//  Flips the coin by randomly choosing a face value.
	//-----------------------------------------------------------------
	public void flip()
	{
		face = (int) (Math.random() * 2);
	}

	//-----------------------------------------------------------------
	//  Returns true if the current face of the coin is heads.
	//-----------------------------------------------------------------
	public boolean isHeads()
	{
		return (face == HEADS);
	}

	//-----------------------------------------------------------------
	//  Returns the current face of the coin as a string.
	//-----------------------------------------------------------------
	public String toString()
	{
		String faceName;

		if (face == HEADS)
			faceName = "Heads";
		else
			faceName = "Tails";

		return faceName;
	}

	//-----------------------------------------------------------------
	//  Override compareTo method defined in interface.
	//-----------------------------------------------------------------
	public int compareTo(Coin c)
	{
		if(this.isHeads() == c.isHeads())
			return 0;//equal
		else if(this.isHeads() && !c.isHeads())
			return 1;//obj1 is greater
		else
			return -1;//obj2 is greater
	}
}
