public class Car
{
	/* STATES */
	private int year;
	private String make;
	private String model;

	/* BEHAVIORS */
	//Constructor(s)
	public Car(int y, String ma, String mo)
	{
		make = ma;
		model = mo;
		year = y;
	}
	//Services
		//isAntique
	public boolean isAntique()
	{
		return ((2016-45) > year);
	}
	//Accessors/Getters
	public int getYear()
	{
		return year;
	}
	public String getModel()
	{
		return model;
	}
	public String getMake()
	{
		return make;
	}
	//Mutators/Setters
	public void setYear(int y)
	{
		year = y;
	}
	public void setModel(String mo)
	{
		model = mo;
	}
	public void setMake(String ma)
	{
		make = ma;
	}
	//toString
	public String toString()
	{
		return "The car is a " + year + " " + make + " " + model + ".";
	}

}