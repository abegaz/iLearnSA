public class Bookshelf
{
	public static void main(String[] args)
	{
		Book b1 = new Book("Java Software Solutions",
							"Lewis",
							"Pearson",
							2015);//title, author, publisher, copyright
		System.out.println(b1);
	}
}