public class Book
{
	/* STATES */
		//title, author, publisher, copyright
	private String title, author, publisher;
	private int copyright;

	/* BEHAVIORS */
	//Constructor(s)
	public Book(String t, String a, String p, int c)
	{
		title = t;
		author = a;
		publisher = p;
		copyright = c;
	}
	//Accessors/Getters
	public String getTitle()
	{
		return title;
	}
	public String getAuthor()
	{
		return author;
	}
	public String getPublisher()
	{
		return publisher;
	}
	public int getCopyright()
	{
		return copyright;
	}
	//Mutators/Setters
	public void setTitle(String t)
	{
		title = t;
	}
	public void setAuthor(String a)
	{
		author = a;
	}
	public void setPublisher(String p)
	{
		publisher = p;
	}
	public void setCopyright(int c)
	{
		copyright = c;
	}
	//toString
	public String toString()
	{
		String temp = "Title:" + title + "\n";
		temp += "Author:" + author + "\n";
		temp += "Publisher:" + publisher + "\n";
		temp += "Copyright:" + copyright;
		return temp;
	}
}