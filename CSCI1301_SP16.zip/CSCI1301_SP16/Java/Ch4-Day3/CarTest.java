public class CarTest
{
	public static void main(String[] args)
	{
		//create object of car class
		Car c1 = new Car(2016, "Tesla", "Model S");//year, make, model
		//test methods
		System.out.println(c1);
		System.out.println("Is it an antique? " + c1.isAntique());
		//create object of car class
		Car c2 = new Car(1970, "Ford", "F-150");//year, make, model
		//test methods
		System.out.println(c2);
		System.out.println("Is it an antique? " + c2.isAntique());

	}
}