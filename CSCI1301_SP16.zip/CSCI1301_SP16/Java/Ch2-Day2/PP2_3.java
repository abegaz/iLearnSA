//PP 2.3 on Page 108
//Ask the user for two decimal numbers
//print the sum, product, and difference
import java.util.Scanner;
public class PP2_3
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter a number: ");
		double num1 = scan.nextDouble();
		System.out.print("Please enter a number: ");
		double num2 = scan.nextDouble();
		System.out.println("The sum of your numbers is: " +
			(num1 + num2));
		System.out.println("The difference of your numbers is: " +
			(num1 - num2));
		System.out.println("The product of your numbers is: " +
			(num1 * num2));
	}
}