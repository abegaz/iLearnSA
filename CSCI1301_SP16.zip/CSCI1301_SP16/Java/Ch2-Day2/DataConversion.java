public class DataConversion
{
	public static void main(String[] args)
	{
		//assignment conversion
		int sum = 5;
		double total = sum;//widening conversion
		//sum = total;//Error: narrowing conversion/ loss of precision
		System.out.println("Sum: " + sum);
		System.out.println("Total: " + total);

		//promotion
		double product = sum * total;//converts sum to a double and produces a double answer
		System.out.println("Product: " + product);
		System.out.println("Ans: " + (sum / 2));
		System.out.println("Ans: " + (sum / 2.0));

		//casting
		total = 5.5;
		sum = (int)total;//narrowing conversion
		System.out.println("Sum: " + sum  + " :: Total: " + total);
		System.out.println((char)67);
		System.out.println((int)'C');
	}
}
