public class Division
{
	public static void main(String[] args)
	{
		System.out.println(14/3);
		System.out.println(14%3);
		System.out.println(10/3);
		System.out.println(10%3);
		System.out.println(54/2);
		System.out.println(54%2);
		System.out.println(97/2);
		System.out.println(97%2);
		System.out.println(10/4.0);
	}
}