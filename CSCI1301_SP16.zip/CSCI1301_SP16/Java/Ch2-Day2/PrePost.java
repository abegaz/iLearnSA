public class PrePost
{
	public static void main(String[] args)
	{
		int count = 0;
		count++;
		System.out.println(count);
		System.out.println(count++);
		++count;
		System.out.println(count);
		System.out.println(++count);
		System.out.println(count);
		System.out.println(count--);
		System.out.println(count);
		System.out.println(--count);
	}
}