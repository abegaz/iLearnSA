//Tell the compiler where the Scanner class is located
import java.util.Scanner;
public class ScannerExample
{
	public static void main(String[] args)
	{
		//Initialize the Scanner object
		Scanner scan = new Scanner(System.in);

		System.out.print("Enter some text: ");
		String text = scan.nextLine();
		System.out.println("Your text was: " + text);

		System.out.println("Enter a whole number: ");
		int num1 = scan.nextInt();
		System.out.println("Enter a decimal number: ");
		double num2 = scan.nextDouble();
		System.out.println(num1 + " X " + num2 + " = " +
			(num1 * num2));
		//next(), nextInt, and nextDouble() leave the cursor on the same line
		//this moves the cursor to the next line so we can read another line of text
		scan.nextLine();

		System.out.print("Enter some text: ");
		text = scan.nextLine();
		System.out.println("Your text was: " + text);
	}
}