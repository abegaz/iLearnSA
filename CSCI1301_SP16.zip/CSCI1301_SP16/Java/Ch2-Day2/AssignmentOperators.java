public class AssignmentOperators
{
	public static void main(String[] args)
	{
		int count = 0;
		count += 5;//count = count + 5
		System.out.println(count);
		count *= 5 + 2;//count = count * (5 + 2)
		System.out.println(count);
		count /= 2;//count = count / 2
		System.out.println(count);
		count -= 2;//count = count - 2
		System.out.println(count);
	}
}