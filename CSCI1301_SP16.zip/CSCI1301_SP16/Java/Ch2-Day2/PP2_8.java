//PP 2.8 on Page 109
//Read in a time duration in hours, minutes, seconds
//Print out the total number of seconds
import java.util.Scanner;
public class PP2_8
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Hours:");
		int hours = scan.nextInt();
		System.out.print("Minutes:");
		int minutes = scan.nextInt();
		System.out.print("Seconds:");
		int seconds = scan.nextInt();
		minutes += hours * 60;
		seconds += minutes * 60;
		System.out.println("Total Seconds:" + seconds);
	}
}