//PP 2.2 on Page 108
//Read three integers from the user
//print the average of those numbers
import java.util.Scanner;
public class PP2_2
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		System.out.print("Please enter a whole number: ");
		int num1 = scan.nextInt();
		System.out.print("Please enter a whole number: ");
		int num2 = scan.nextInt();
		System.out.print("Please enter a whole number: ");
		int num3 = scan.nextInt();
		System.out.println("The average of the three numbers is: " +
			( (num1+num2+num3) / 3)
			);
	}
}