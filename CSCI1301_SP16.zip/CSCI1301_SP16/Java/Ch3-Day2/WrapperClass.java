public class WrapperClass
{
	public static void main(String[] args)
	{
		Integer num1 = new Integer(21);
		System.out.println(num1);
		int num2 = Integer.parseInt("56");
		System.out.println(num2);
		System.out.println("Max Int:" + Integer.MAX_VALUE);
		System.out.println("Min Int:" + Integer.MIN_VALUE);

		System.out.println(Integer.parseInt("1000", 2));
		System.out.println(Integer.parseInt("FF", 16));

		System.out.println(Integer.toString(8, 2));
		System.out.println(Integer.toString(255, 16));


	}
}