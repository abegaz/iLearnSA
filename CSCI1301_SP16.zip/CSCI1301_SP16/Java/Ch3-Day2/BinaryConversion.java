import java.util.Scanner;
public class BinaryConversion
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);

		//Ask user for a binary number (base 2)
		System.out.print("Enter a binary number: ");
		String binary = scan.next();
		int base10 = Integer.parseInt(binary, 2);
		String base16 = Integer.toString(base10, 16);

		//print out the integer equivalent (base 10)
		System.out.println("You entered " + base10 + " in base 10 counting");

		//print out the hex equivalent (base 16)
		System.out.println("You entered " + base16.toUpperCase() + " in base 16 counting");

		System.out.println("The number you entered stands for " + (char)base10 + " character.");
	}
}