/*
Read two (x,y) coordinates from the user
Compute the distance using the following formula:
SquareRoot( (x2-x1)^2 + (y2-y1)^2 )
*/
import java.util.Scanner;
import java.text.DecimalFormat;
public class PP3_5
{
	public static void main(String[] args)
	{
		//Read data from the user
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter X1:");
		int x1 = scan.nextInt();
		System.out.print("Enter Y1:");
		int y1 = scan.nextInt();
		System.out.print("Enter X2:");
		int x2 = scan.nextInt();
		System.out.print("Enter Y2:");
		int y2 = scan.nextInt();
		/*
		SquareRoot( (x2-x1)^2 + (y2-y1)^2 )
		Math.sqrt(#);
		Math.pow(#,#);
		*/
		//(x2-x1)^2
		double xSquared = Math.pow(x2-x1, 2);
		//(y2-y1)^2
		double ySquared = Math.pow(y2-y1, 2);
		//SquareRoot( (x2-x1)^2 + (y2-y1)^2 )
		double distance = Math.sqrt(xSquared + ySquared);
		DecimalFormat df = new DecimalFormat("0.0###");
		System.out.println(df.format(distance));
	}
}