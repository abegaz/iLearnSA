/*
Create a random phone number in the format XXX-XXX-XXXX
Be sure to include the dashes
None of the first three digits should be 8 or 9
The middle set should be less than or equal to 655
*/
import java.util.Random;
import java.text.DecimalFormat;
public class PP3_3
{
	public static void main(String[] args)
	{
		Random rand = new Random();
		//first segment, do not use 8 or 9
		System.out.print(rand.nextInt(8));
		System.out.print(rand.nextInt(8));
		System.out.print(rand.nextInt(8));
		System.out.print("-");
		//second segment, not greater than 655
		DecimalFormat df3 = new DecimalFormat("000");
		System.out.print(df3.format(rand.nextInt(656)) + "-");
		//third segment
		DecimalFormat df4 = new DecimalFormat("0000");
		System.out.println(df4.format(rand.nextInt(10000)));
	}
}