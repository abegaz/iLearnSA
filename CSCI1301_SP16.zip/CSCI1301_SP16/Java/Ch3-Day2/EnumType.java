public class EnumType
{
	enum Term {fall, spring, maymester,
		firstShortSummer, secondShortSummer, fullSummer}
	public static void main(String[] args)
	{
		Term previous, current, next;

		previous = Term.fall;
		current = Term.spring;
		next = Term.maymester;

		System.out.println("Previous Term Value: " + previous);
		System.out.println("Previous Term Ordinal: " + previous.ordinal());
		System.out.println("Previous Term Name: " + previous.name());

		System.out.println("");

		System.out.println("Current Term Value: " + current);
		System.out.println("Current Term Ordinal: " + current.ordinal());
		System.out.println("Current Term Name: " + current.name());

		System.out.println("");

		System.out.println("Next Term Value: " + next);
		System.out.println("Next Term Ordinal: " + next.ordinal());
		System.out.println("Next Term Name: " + next.name());

	}
}