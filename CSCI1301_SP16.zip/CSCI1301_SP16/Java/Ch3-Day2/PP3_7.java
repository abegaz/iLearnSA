/*
Read the lengths of the sides of a triangle from the user
Compute the area with the following formula
	SquareRoot( s * (s-a) * (s-b) * (s-c) )
	s = half the perimeter of the triangle
Print the area to 3 decimal places
*/
import java.util.Scanner;
import java.text.DecimalFormat;
public class PP3_7
{
	public static void main(String[] args)
	{
		//Read data from the user
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter triangle side 1: ");
		int a = scan.nextInt();
		System.out.print("Enter triangle side 2: ");
		int b = scan.nextInt();
		System.out.print("Enter triangle side 3: ");
		int c = scan.nextInt();

		//half of perimeter
		double s = (a+b+c)/2.0;

		//SquareRoot( s * (s-a) * (s-b) * (s-c) )
		double area = Math.sqrt(s*(s-a)*(s-b)*(s-c));
		DecimalFormat df = new DecimalFormat("0.000");
		System.out.println("Area: " + df.format(area));
	}
}