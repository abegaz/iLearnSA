public class Variables
{
	public static void main(String[] args)
	{
		int sum = 0;
		System.out.println("Sum: " + sum);
		sum = 5 + 5;
		System.out.println("Sum: " + sum);

		int total = 15;
		int number = sum + total;

		System.out.println("Sum: " + sum);
		System.out.println("Total: " + total);
		System.out.println("Number: " + number);

		final int MAX_SUM = 15;
		//MAX_SUM = 20;//not allowed to change a constant
	}
}
