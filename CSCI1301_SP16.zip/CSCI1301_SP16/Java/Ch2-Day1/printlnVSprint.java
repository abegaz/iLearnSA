public class printlnVSprint
{
	public static void main(String[] args)
	{
		System.out.println("Some text");
		System.out.print("Some text");
		System.out.print(" on the same line");
	}
}