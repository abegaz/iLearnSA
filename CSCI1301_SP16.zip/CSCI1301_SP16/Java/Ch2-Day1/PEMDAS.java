public class PEMDAS
{
	public static void main(String[] args)
	{
		System.out.println(5 + 2 * 3);
		System.out.println((5 + 2) * 3);
		System.out.println("There are " + 5 + " items");
		System.out.println("There are " + 5 + 5 + " items");
		/*
		"There are " + 5 + 5 + " items"
		"There are 5" + 5 + " items"
		"There are 55" + " items"
		"There are 55 items"
		*/
		System.out.println("There are " + (5 + 5) + " items");
	}
}