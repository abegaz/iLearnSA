public class Escape
{
	public static void main(String[] args)
	{
		//System.out.println("I said "Hello" to the world!");
		System.out.println("I said \"Hello\" to the world!");
		System.out.println("This is on the first line \nThis is on the second");
		System.out.println("This is on the first line" +
		"\nThis is on the second");
/*

\" print "
\n print newline


*/
	}
}
