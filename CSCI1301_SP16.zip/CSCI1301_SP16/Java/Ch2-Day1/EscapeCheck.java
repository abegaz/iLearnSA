/*
Produce the following output with a single println() statement

"I hope you are
enjoying this
class so far,"
said the professor.

*/
public class EscapeCheck
{
	public static void main(String[] args)
	{
		System.out.println("\"I hope you are \n" +
							"enjoying this \n" +
							"class so far,\" \n" +
							"said the professor.");
	}
}