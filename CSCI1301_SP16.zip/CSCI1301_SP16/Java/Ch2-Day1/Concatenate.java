/*
Project 1
Name

*/
public class Concatenate
{
	public static void main(String[] args)
	{
		/*

		*/
		System.out.println("A very very very " +
			"long sentence");
		System.out.println("Two " + "words" + "!");
	}
}