public class DataTypes
{
	public static void main(String[] args)
	{
		byte var1 = 127;
		System.out.println(var1);
		short var2 = 30000;
		System.out.println(var2);
		int var3 = 20000000;//primary whole number data type
		System.out.println(var3);
		long var4 = 100000000;
		System.out.println(var4);

		double var5 = 3.145;//decimal numbers
		System.out.println(var5);

		char var6 = 'A';//single quotes instead of double quotes
		System.out.println(var6);

		boolean var7 = true;//false
		System.out.println(var7);

	}
}