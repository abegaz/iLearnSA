/*
PP 5.2 - Page 263
Determine if a year entered by a user is a leap year or not

Return an error for values before 1582
A leap year is divisble by 4, but not 100, unless also divisble by 400
2000 is a leap year
2100 is not a leap year
1996 is a leap year
1995 is not a leap year
1581 is before leap years existed
*/
import java.util.Scanner;
import java.io.File;//for reading files
import java.io.IOException;//to catch errors with file not found
public class LeapYears
{
	public static void main(String[] args) throws IOException
	{
		Scanner scan = new Scanner(new File("Years.txt"));
		//Get year from file
		int year;

		while(scan.hasNextInt())
		{
			year = scan.nextInt();
			//tell user if it is a leap year
			//check if year is a leap year
			if(year < 1582)
			{
				System.out.println(year + " is before leap years existed");
			}
			else if(year % 4 == 0 && (year % 400 == 0 || year % 100 != 0))
			{
				System.out.println(year + " is a leap year");
			}
			else
			{
				System.out.println(year + " is not a leap year");
			}


		}

	}
}