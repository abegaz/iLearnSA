/*
PP 5.2 - Page 263
Determine if a year entered by a user is a leap year or not

Return an error for values before 1582
A leap year is divisble by 4, but not 100, unless also divisble by 400
2000 is a leap year
2100 is not a leap year
1996 is a leap year
1995 is not a leap year
1581 is before leap years existed
*/
import java.util.*;
public class PP5_2
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		//Get year from user
		System.out.print("Enter a year: ");
		int year = scan.nextInt();

		while(year != -1)
		{
			//tell user if it is a leap year
			//check if year is a leap year
			if(year < 1582)
			{
				System.out.println(year + " is before leap years existed");
			}
			else if(year % 4 == 0 && (year % 400 == 0 || year % 100 != 0))
			{
				System.out.println(year + " is a leap year");
			}
			else
			{
				System.out.println(year + " is not a leap year");
			}

			//ask user for another year
			System.out.print("Enter another year or -1 to quit: ");
			year = scan.nextInt();
		}

	}
}