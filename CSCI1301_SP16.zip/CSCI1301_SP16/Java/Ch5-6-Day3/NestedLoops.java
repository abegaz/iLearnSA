import java.util.Scanner;
public class NestedLoops
{
	public static void main(String[] args)
	{
		//Create scanner object
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a number: ");
		int num = scan.nextInt();

		int var1 = 0;
		int var2 = 0;
		int sum = 0;
		while(var1 < num)
		{
			var2 = 0;
			while(var2 < num)
			{
				sum += var1+var2;
				System.out.println("Var1: " + var1 +
					" :: Var2: " + var2 +
					" :: Sum: " + sum);
				var2++;
			}
			var1++;
		}
		System.out.println("Sum: " + sum);

	}
}
