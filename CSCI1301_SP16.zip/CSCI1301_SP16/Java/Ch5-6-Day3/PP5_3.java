/*
PP5.3
Ask the user for a number
specify which numbers are odd,even,zero
divide by 10 drops the last digit
remainder by 10 tells you the current digit
*/
import java.util.*;
public class PP5_3
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		//Get number from user
		System.out.print("Enter a number: ");
		int number = scan.nextInt();
		System.out.println("Your number is : " + number);
		int digit;
		do
		{
			//find current digit
			digit = number % 10;
			//System.out.println(digit);
			//determine if digit is zero, odd, even
			if(digit == 0)
				System.out.println("Digit is Zero");
			else if(digit % 2 == 0)
				System.out.println("Digit is Even");
			else
				System.out.println("Digit is Odd");
			//find new number to test
			number = number / 10;
			//System.out.println(number);
		}while(number != 0);//condition that will end after checking all digits
	}
}
