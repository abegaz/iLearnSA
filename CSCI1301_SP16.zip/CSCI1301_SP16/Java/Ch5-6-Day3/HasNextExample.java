import java.util.Scanner;
import java.io.File;//for reading files
import java.io.IOException;//to catch errors with file not found
public class HasNextExample
{
	public static void main(String[] args) throws IOException
	{
		//Create object of scanner that reads in a file
		Scanner scan = new Scanner(new File("HasNextText.txt"));

		while(scan.hasNext())
		{
			System.out.println(scan.next());
		}

		Scanner scan2 = new Scanner("Hello World!");
		while(scan2.hasNext())
		{
			System.out.println(scan2.next());
		}

	}
}