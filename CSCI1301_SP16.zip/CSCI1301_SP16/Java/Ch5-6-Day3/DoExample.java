import java.util.Scanner;
public class DoExample
{
	public static void main(String[] args)
	{
		//Create scanner object
		Scanner scan = new Scanner(System.in);
		int total = 0;
		int num = 0;
		//check if number entered is >= 0
		do
		{
			//Add the number to the total and ask for another number
			total += num;
			System.out.print("Enter a whole number (-1 to quit): ");
			num = scan.nextInt();
		}while(num >= 0);
		//output the total after receiving a number < 0
		System.out.println("The total value of numbers entered is " + total);
	}
}