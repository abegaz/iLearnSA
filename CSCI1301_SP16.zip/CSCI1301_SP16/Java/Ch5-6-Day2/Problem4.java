public class Problem4
{
	public static void main(String[] args)
	{
		//Create two die objects
		DieVersion2 d1 = new DieVersion2();
		DieVersion2 d2 = new DieVersion2();

		System.out.println(d1);
		System.out.println(d2);

		switch(d1.compareTo(d2))
		{
			case 1:
				System.out.println("Die 1 is greater than Die 2");
				break;
			case -1:
				System.out.println("Die 1 is less than Die 2");
				break;
			default:
				System.out.println("Die 1 is equal to Die 2");
				break;
		}

		if(d1.compareTo(d2) == -1)
		{
			System.out.println("Die 1 is less than Die 2");
		}
		else if(d1.compareTo(d2) == 1)
		{
			System.out.println("Die 1 is greater than Die 2");
		}
		else
		{
			System.out.println("Die 1 is equal to Die 2");
		}


	}
}
