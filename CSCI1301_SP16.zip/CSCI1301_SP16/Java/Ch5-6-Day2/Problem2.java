import java.util.Scanner;
public class Problem2
{
	public static void main(String[] args)
	{
		//Create an object of the scanner class
		Scanner scan = new Scanner(System.in);
		//Ask the user for a grade
		System.out.print("Enter a numeric grade: ");
		int grade = scan.nextInt();
		//Tell the user what letter grade they got
			//HINT (grade/10) gives 0-10 to shorten the switch statement
		switch(grade/10)
		{
			case 10:
			case 9:
				System.out.println("A");
				break;
			case 8:
				System.out.println("B");
				break;
			case 7:
				System.out.println("C");
				break;
			case 6:
				System.out.println("D");
				break;
			default:
				System.out.println("F");
				break;
		}
	}
}