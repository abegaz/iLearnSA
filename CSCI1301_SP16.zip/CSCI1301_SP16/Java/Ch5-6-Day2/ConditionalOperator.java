import java.util.Scanner;
public class ConditionalOperator
{
	public static void main(String[] args)
	{
		//Create Scanner Object
		Scanner scan = new Scanner(System.in);
		//Ask user for a number
		System.out.print("Enter a whole number:");
		int input = scan.nextInt();
		//Set output text based on number entered
		String text = "";
		/*
		if(input >= 10)
		{
			text = "Greater than or equal to 10";
		}
		else
		{
			text = "Less than 10";
		}
		//print output text
		System.out.println(text);
		*/
		//conditional operator
		text = (input >= 10) ? "Greater than or equal to 10" : "Less than 10";
		System.out.println(text);
		System.out.println( (input > 5) ? "Greater than 5" : "not greater than 5");
	}
}