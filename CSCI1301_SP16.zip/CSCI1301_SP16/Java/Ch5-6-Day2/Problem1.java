import java.util.Scanner;
public class Problem1
{
	public static void main(String[] args)
	{
		//Create an object of the scanner class
		Scanner scan = new Scanner(System.in);
		//Ask the user for a number between 1 and 7
		System.out.print("Enter a number between 1 and 7: ");
		int day = scan.nextInt();
		//Tell the user what day that number stands for
		switch(day)
		{
			case 1:
				System.out.println("Sunday");
				break;
			case 2:
				System.out.println("Monday");
				break;
			case 3:
				System.out.println("Tuesday");
				break;
			case 4:
				System.out.println("Wednesday");
				break;
			case 5:
				System.out.println("Thursday");
				break;
			case 6:
				System.out.println("Friday");
				break;
			case 7:
				System.out.println("Saturday");
				break;
			default:
				System.out.println("Not a valid entry");
				break;
		}
		/*
		The above switch statement is the same as:
		if(day == 1)
			System.out.println("Sunday");
		else if(day == 2)
			System.out.println("Monday");
		else if(day == 3)
			System.out.println("Tuesday");
		else if(day == 4)
			System.out.println("Wednesday");
		else if(day == 5)
			System.out.println("Thursday");
		else if(day == 6)
			System.out.println("Friday");
		else if(day == 7)
			System.out.println("Saturday");
		else
			System.out.println("Not a valid entry");
		*/
	}
}