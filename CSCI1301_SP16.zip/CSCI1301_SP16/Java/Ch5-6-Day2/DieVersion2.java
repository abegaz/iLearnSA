import java.util.Random;
public class DieVersion2
{
	//States
	private int faceValue;
	private int numberOfSides;

	//Constructors
	public DieVersion2()
	{
		numberOfSides = 6;
		rollDie();
	}
	public DieVersion2(int sides)
	{
		numberOfSides = sides;
		rollDie();
	}

	//Behaviors
	public void rollDie()
	{
		Random rand = new Random();
		faceValue = rand.nextInt(numberOfSides) + 1;
	}

	//toString
	public String toString()
	{
		return numberOfSides + " sided die has a value of " + faceValue;
	}
	//Accessors/Getters
	public int getFaceValue()
	{
		return faceValue;
	}
	public int getNumberOfSides()
	{
		return numberOfSides;
	}
	//Mutators/Setters
	public void setFaceValue(int fv)
	{
		if(fv <= 0)
			faceValue = 1;
		else if(fv > numberOfSides)
			faceValue = numberOfSides;
		else
			faceValue = fv;
	}
	public void setNumberOfSides(int nos)
	{
		if(nos <= 1)
			numberOfSides = 2;
		else
			numberOfSides = nos;
		rollDie();
	}

	//compareTo
	//return -1 if this is smaller
	//return 0 if this is the same
	//return 1 if this is larger
	public int compareTo(DieVersion2 d)
	{
		if(faceValue < d.getFaceValue())
			return -1;
		else if(faceValue > d.getFaceValue())
			return 1;
		else
			return 0;
	}

}