public class Problem3
{
	public static void main(String[] args)
	{
		//Create two die objects
		DieVersion2 d1 = new DieVersion2();
		DieVersion2 d2 = new DieVersion2();

		System.out.println(d1);
		System.out.println(d2);

		//create a switch statement to produce a message based on the dice sum
		int sum = d1.getFaceValue() + d2.getFaceValue();
		switch(sum)
		{
			case 2:
				System.out.println("Snake Eyes");
				break;
			case 7:
				System.out.println("Winner!");
				break;
			case 12:
				System.out.println("Double Sixes");
				break;
			default:
				System.out.println(sum + " is a losing value");
				break;
		}

		//use conditional operators to print even/odd for each die
		System.out.println( (d1.getFaceValue() % 2 == 0) ? "Even" : "Odd");
		System.out.println( (d2.getFaceValue() % 2 == 0) ? "Even" : "Odd");
	}
}