import java.util.Scanner;
public class SwitchExample
{
	public static void main(String[] args)
	{
		//Create Scanner Object
		Scanner scan = new Scanner(System.in);
		//Ask user for a number
		System.out.print("Enter a number between 1 and 3:");
		int input = scan.nextInt();
		//Print output based on number entered
		/*
		if(input == 1)
		{
			System.out.println("You entered one");
			System.out.println(input);
		}
		else if(input == 2)
		{
			System.out.println("You entered two");
		}
		else if(input == 3)
		{
			System.out.println("You entered three");
		}
		else
		{
			System.out.println("You did not enter a valid number");
		}
		*/
		//Print output based on number entered using a switch statement
		switch(input)
		{
			case 1:
				System.out.println("You entered one");
				System.out.println(input);
				break;
			case 2:
				System.out.println("You entered two");
				break;
			case 3:
				System.out.println("You entered three");
				break;
			case 4:
				System.out.println("You entered four");
				break;
			default:
				System.out.println("You did not enter a valid number");
				break;
		}
	}
}