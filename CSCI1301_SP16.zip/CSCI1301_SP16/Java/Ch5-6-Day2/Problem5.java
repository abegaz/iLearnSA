import java.util.Scanner;
public class Problem5
{
	public static void main(String[] args)
	{
		//Create an object of the scanner class
		Scanner scan = new Scanner(System.in);
		//Ask the user for a year
		System.out.print("Enter a year >= 1965: ");
		int year = scan.nextInt();
		/*
1965 - Snake		1966 - Horse		1967 - Sheep
1968 - Monkey		1969 - Rooster		1970 - Dog
1971 - Pig			1972 - Rat			1973 - Ox
1974 - Tiger		1975 - Rabbit		1976 - Dragon
		*/

		//Tell the user what the chinese zodiac is for the given year
		switch((year-1965)%12)
		{
			case 0:
				System.out.println("Snake");
				break;
			case 1:
				System.out.println("Horse");
				break;
			case 2:
				System.out.println("Sheep");
				break;
			case 3:
				System.out.println("Monkey");
				break;
			case 4:
				System.out.println("Rooster");
				break;
			case 5:
				System.out.println("Dog");
				break;
			case 6:
				System.out.println("Pig");
				break;
			case 7:
				System.out.println("Rat");
				break;
			case 8:
				System.out.println("Ox");
				break;
			case 9:
				System.out.println("Tiger");
				break;
			case 10:
				System.out.println("Rabbit");
				break;
			case 11:
				System.out.println("Dragon");
				break;
			default:
				System.out.println("Invalid year");
				break;
		}
	}
}
