//********************************************************************
//  StyleOptionsPanel.java       Author: Lewis/Loftus
//
//  Demonstrates the use of check boxes.
//********************************************************************

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class StyleOptionsPanel extends JPanel
{
   private JLabel saying, fontSizeLabel;
   private JCheckBox bold, italic;
   private JTextField fontSize;

   //-----------------------------------------------------------------
   //  Sets up a panel with a label and some check boxes that
   //  control the style of the label's font.
   //-----------------------------------------------------------------
   public StyleOptionsPanel()
   {
      saying = new JLabel("Say it with style!");
      saying.setFont(new Font("Helvetica", Font.PLAIN, 36));

      bold = new JCheckBox("Bold");
      bold.setBackground(Color.cyan);
      italic = new JCheckBox("Italic");
      italic.setBackground(Color.cyan);

	  fontSizeLabel = new JLabel("Enter a Font Size:");
      fontSize = new JTextField(5);
      fontSize.setText("36");

      FontSizeListener sizeListener = new FontSizeListener();
      fontSize.addActionListener(sizeListener);

      StyleListener listener = new StyleListener();
      bold.addItemListener(listener);
      italic.addItemListener(listener);

      add(saying);
      add(bold);
      add(italic);
      add(fontSizeLabel);
      add(fontSize);

      setBackground(Color.cyan);
      setPreferredSize(new Dimension(300, 200));
   }

   //*****************************************************************
   //  Represents the listener for both check boxes.
   //*****************************************************************
   private class StyleListener implements ItemListener
   {
      //--------------------------------------------------------------
      //  Updates the style of the label font style.
      //--------------------------------------------------------------
      public void itemStateChanged(ItemEvent event)
      {
		  String text = fontSize.getText();
		int size = Integer.parseInt(text);

         int style = Font.PLAIN;

         if (bold.isSelected())
            style = Font.BOLD;

         if (italic.isSelected())
            style += Font.ITALIC;

         saying.setFont(new Font("Helvetica", style, size));
      }
   }
   //*****************************************************************
  //  Represents an action listener for the temperature input field.
  //*****************************************************************
  private class FontSizeListener implements ActionListener
  {
	 //--------------------------------------------------------------
	 //  Performs the conversion when the enter key is pressed in
	 //  the text field.
	 //--------------------------------------------------------------
	 public void actionPerformed(ActionEvent event)
	 {
		String text = fontSize.getText();
		int size = Integer.parseInt(text);

		int style = Font.PLAIN;

		 if (bold.isSelected())
			style = Font.BOLD;

		 if (italic.isSelected())
		style += Font.ITALIC;

		saying.setFont(new Font("Helvetica", style, size));
	 }
   }
}
