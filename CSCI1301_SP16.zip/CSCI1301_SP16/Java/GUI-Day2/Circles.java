//********************************************************************
//  Circles.java       Author: Lewis/Loftus
//
//  Demonstrates the use of loops to draw.
//********************************************************************

import javax.swing.JFrame;

public class Circles
{
   //-----------------------------------------------------------------
   //  Creates the main frame of the program.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
      JFrame frame = new JFrame("Circles");
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

      CirclesPanel panel = new CirclesPanel();

      frame.getContentPane().add(panel);
      frame.pack();
      frame.setVisible(true);
   }
}
