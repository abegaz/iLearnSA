//********************************************************************
//  CirclesPanel.java       Author: Lewis/Loftus
//
//  Demonstrates the use of conditionals and loops to guide drawing.
//********************************************************************

import javax.swing.JPanel;
import java.awt.*;
import java.util.Random;

public class CirclesPanel extends JPanel
{
   private final int NUM_CIRCLES = 100, MAX_SIDE = 50;
   private final int MAX_X = 350, MAX_Y = 250;
   private Random generator;

   //-----------------------------------------------------------------
   //  Sets up the drawing panel.
   //-----------------------------------------------------------------
   public CirclesPanel()
   {
      generator = new Random();

      setBackground(Color.black);
      setPreferredSize(new Dimension(400, 300));
   }

   //-----------------------------------------------------------------
   //  Paints boxes of random width and height in a random location.
   //  Narrow or short boxes are highlighted with a fill color.
   //-----------------------------------------------------------------
   public void paintComponent(Graphics page)
   {
      super.paintComponent(page);

      int x, y, width, height;
      int color, fill;

      for (int count = 0; count < NUM_CIRCLES; count++)
      {
         x = generator.nextInt(MAX_X) + 1;
         y = generator.nextInt(MAX_Y) + 1;

         width = generator.nextInt(MAX_SIDE) + 1;
         height = generator.nextInt(MAX_SIDE) + 1;

		//random color
		//white, green, yellow, blue, red, orange
		color = generator.nextInt(6);
		switch(color)
		{
			case 0:
				page.setColor(Color.red);
				break;
			case 1:
				page.setColor(Color.white);
				break;
			case 2:
				page.setColor(Color.blue);
				break;
			case 3:
				page.setColor(Color.yellow);
				break;
			case 4:
				page.setColor(Color.green);
				break;
			case 5:
				page.setColor(Color.orange);
				break;
		}


		//random fill/not fill
		fill = generator.nextInt(2);
		if(fill == 0)
			page.drawOval(x, y, width, height);
		else
			page.fillOval(x, y, width, height);
      }
   }
}
