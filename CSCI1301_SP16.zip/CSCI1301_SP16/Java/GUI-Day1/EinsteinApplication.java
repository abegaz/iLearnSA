public class EinsteinApplication
{
	public static void main(String[] args)
	{
		System.out.println("**************************************");
		System.out.println("*                                    *");
		System.out.println("*  Out of clutter, find simplicity.  *");
		System.out.println("*       -- Albert Einstein           *");
		System.out.println("*                                    *");
		System.out.println("**************************************");
	}
}