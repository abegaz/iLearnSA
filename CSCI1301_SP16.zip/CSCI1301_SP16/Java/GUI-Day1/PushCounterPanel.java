//********************************************************************
//  PushCounterPanel.java       Authors: Lewis/Loftus
//
//  Demonstrates a graphical user interface and an event listener.
//********************************************************************

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class PushCounterPanel extends JPanel
{
   private int count;
   private JButton increase, decrease;
   private JLabel label;

   //-----------------------------------------------------------------
   //  Constructor: Sets up the GUI.
   //-----------------------------------------------------------------
   public PushCounterPanel()
   {
      count = 50;

      increase = new JButton("Increase");
      increase.addActionListener(new IncreaseButtonListener());

      decrease = new JButton("Decrease");
      decrease.addActionListener(new DecreaseButtonListener());

      label = new JLabel(" "+count+" ");

      add(increase);
      add(label);
      add(decrease);

      setPreferredSize(new Dimension(300, 40));
      setBackground(Color.cyan);
   }

   //*****************************************************************
   //  Represents a listener for button push (action) events.
   //*****************************************************************
   private class IncreaseButtonListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Updates the counter and label when the button is pushed.
      //--------------------------------------------------------------
      public void actionPerformed(ActionEvent event)
      {
         count++;
         label.setText(" "+count+" ");
      }
   }
   //*****************************************************************
   //  Represents a listener for button push (action) events.
   //*****************************************************************
   private class DecreaseButtonListener implements ActionListener
   {
      //--------------------------------------------------------------
      //  Updates the counter and label when the button is pushed.
      //--------------------------------------------------------------
      public void actionPerformed(ActionEvent event)
      {
         count--;
         label.setText(" "+count+" ");
      }
   }
}
