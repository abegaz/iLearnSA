import java.awt.*;
import javax.swing.*;

public class PanelHierarchy
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("Panel Hierarchy");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		//Primary Panel
		JPanel primary = new JPanel();
		primary.setBackground(Color.red);

		JPanel container = new JPanel();
		container.setBackground(Color.red);
		container.setPreferredSize(new Dimension(350, 100));


		//Sub Panel 1
		JPanel subPanel1 = new JPanel();
		subPanel1.setPreferredSize(new Dimension(150, 100));
		subPanel1.setBackground(Color.orange);
		JLabel label1 = new JLabel("Sub-Panel One");
		subPanel1.add(label1);

		//Sub Panel 2
		JPanel subPanel2 = new JPanel();
		subPanel2.setPreferredSize(new Dimension(150, 100));
		subPanel2.setBackground(Color.blue);
		JLabel label2 = new JLabel("Sub-Panel Two");
		subPanel2.add(label2);

		//Add Sub Panels to Primary Panel
		container.add(subPanel1);
		container.add(subPanel2);
		primary.add(container);

		//Add Primary Panel to Frame
		frame.getContentPane().add(primary);
		frame.pack();
		frame.setVisible(true);

	}
}