
import javax.swing.JApplet;
import java.awt.*;
public class EinsteinApplet extends JApplet
{
	public void paint(Graphics page)
	{
		page.setColor(Color.blue);
		page.drawRect(50,50,40,40);
		// x coordinate, y coordinate, x width, y width
		page.setColor(Color.cyan);
		page.drawRect(60,80,225,30);
		page.setColor(Color.orange);
		page.drawOval(75,65,20,20);
		page.setColor(Color.red);
		page.drawLine(35,60,100,120);
		page.setColor(Color.black);

		page.drawString("Out of clutter, find simplicity.", 110, 70);
		page.drawString("-- Albert Einstein", 130, 100);

	}
}