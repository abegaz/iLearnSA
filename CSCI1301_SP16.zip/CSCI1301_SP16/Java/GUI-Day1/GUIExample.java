import java.awt.*;
import javax.swing.*;

public class GUIExample
{
	public static void main(String[] args)
	{
		JFrame frame = new JFrame("CSCI 1301");

		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		JPanel primary = new JPanel();
		primary.setBackground(Color.green);
		primary.setPreferredSize(new Dimension(250, 75));

		JLabel label1 = new JLabel("Any questions");
		JLabel label2 = new JLabel("about using frames, panels, and labels?");

		primary.add(label1);
		primary.add(label2);

		frame.getContentPane().add(primary);
		frame.pack();
		frame.setVisible(true);
	}
}