//********************************************************************
//  SolveTowers.java       Author: Lewis/Loftus
//
//  Demonstrates recursion.
//********************************************************************

public class SolveTowers2
{
   //-----------------------------------------------------------------
   //  Creates a TowersOfHanoi puzzle and solves it.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
      TowersOfHanoi2 towers = new TowersOfHanoi2(10);

      towers.solve();
   }
}
