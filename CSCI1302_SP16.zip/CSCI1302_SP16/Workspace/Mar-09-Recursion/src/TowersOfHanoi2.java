//********************************************************************
//  TowersOfHanoi.java       Author: Lewis/Loftus
//
//  Represents the classic Towers of Hanoi puzzle.
//********************************************************************
import java.util.*;

public class TowersOfHanoi2
{
	private int totalDisks;
	private Stack<Integer> post1 = new Stack<Integer>();
	private Stack<Integer> post2 = new Stack<Integer>();
	private Stack<Integer> post3 = new Stack<Integer>();

	//-----------------------------------------------------------------
	//  Sets up the puzzle with the specified number of disks.
	//-----------------------------------------------------------------
	public TowersOfHanoi2(int disks)
	{
		totalDisks = disks;
		//fill first post with disks, largest to smallest
		for(int i = totalDisks; i > 0; i--)
			post1.push(i);//push adds to top of stack
	}

	//-----------------------------------------------------------------
	//  Performs the initial call to moveTower to solve the puzzle.
	//  Moves the disks from tower 1 to tower 3 using tower 2.
	//-----------------------------------------------------------------
	public void solve()
	{
		System.out.println("Starting game state:" + " :: " + post1 + " " + post2 + " " + post3);
		moveTower(totalDisks, 1, 3, 2);
		System.out.println("Ending game state:" + " :: " + post1 + " " + post2 + " " + post3);
	}

	//-----------------------------------------------------------------
	//  Moves the specified number of disks from one tower to another
	//  by moving a subtower of n-1 disks out of the way, moving one
	//  disk, then moving the subtower back. Base case of 1 disk.
	//-----------------------------------------------------------------
	private void moveTower(int numDisks, int start, int end, int temp)
	{
		if (numDisks == 1)
			moveOneDisk(start, end);
		else
		{
			moveTower(numDisks-1, start, temp, end);
			moveOneDisk(start, end);
			moveTower(numDisks-1, temp, end, start);
		}
	}

	//-----------------------------------------------------------------
	//  Prints instructions to move one disk from the specified start
	//  tower to the specified end tower.
	//-----------------------------------------------------------------
	private void moveOneDisk(int start, int end)
	{
		int d = 0;
		switch(start)
		{
			case 1:
				d = post1.pop();
				break;
			case 2:
				d = post2.pop();
				break;
			case 3:
				d = post3.pop();
				break;
		}
		switch(end)
		{
			case 1:
				post1.push(d);
				break;
			case 2:
				post2.push(d);
				break;
			case 3:
				post3.push(d);
				break;
		}
		System.out.println("Move disk #" + d + " from " + start + " to " + end + " :: " + post1 + " " + post2 + " " + post3);
	}
}
