/*
Author:JET
Date Written:Sept 12, 2014
CCSC:SE 1996

Problem: Parenthetical Expressions
*/
import java.util.Scanner;
public class ParentheticalExpressionsRecursive
{
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		while(s.hasNextLine())
		{
			String prefix = s.nextLine().replace(" ","");
			System.out.println(prefixToInfix(prefix));
		}
	}
	public static String prefixToInfix(String prefix)
	{
		if(prefix.length() > 0)
		{
			String infix = "";
			int charCount = 0;
			char test = prefix.charAt(0);
			switch(test)
			{
				case '+':
				case '-':
				case '*':
				case '/':
					infix = "(" + prefixToInfix(prefix.substring(1)) + " " + test + " ";
					charCount = infix.replace("(","").replace(")","").replace(" ","").length();
					infix = infix + prefix.charAt(charCount) + ")";
					return infix;
					//break;
				default:
					return "" + test;
					//break;
			}
		}
		return "";
	}
}