/*
Author:JET
Date Written:Sept 12, 2014
CCSC:SE 1996

Problem: Parenthetical Expressions
*/
import java.util.Scanner;
public class ParentheticalExpressions
{
	public static void main(String[] args)
	{
		Scanner s = new Scanner(System.in);
		while(s.hasNextLine())
		{
			String prefix = s.nextLine().replace(" ","");
			String infix = "";
			int prefixLength = prefix.length();
			char[] symbols = new char[prefixLength];
			int symCount = 0;
			char[] numbers = new char[prefixLength];
			int numCount = 0;
			for(int i = 0; i < prefixLength; i++)
			{
				char test = prefix.charAt(i);
				switch(test)
				{
					case '+':
					case '-':
					case '*':
					case '/':
						symbols[symCount] = test;
						symCount++;
						break;
					default:
						numbers[numCount] = test;
						numCount++;
						break;
				}
			}
			infix = "" + numbers[0];
			for(int j = 1; j<numCount; j++)
			{
				infix = "(" + infix + " " + symbols[symCount-j] + " " + numbers[j] + ")";
			}
			System.out.println(infix);
		}
	}
}