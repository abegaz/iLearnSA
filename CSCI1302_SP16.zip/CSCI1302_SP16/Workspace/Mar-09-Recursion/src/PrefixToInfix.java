import java.util.Scanner;
public class PrefixToInfix {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		while(scan.hasNextLine())
		{
			String prefix = scan.nextLine().replace(" ","");
			System.out.println(prefixToInfix(prefix));
		}
	}
	public static String prefixToInfix(String prefix)
	{
		System.out.println(prefix);
		if(prefix.length() > 0)
		{
			String infix = "";
			char test = prefix.charAt(0);
			switch(test)
			{
			case '+':
			case '-':
			case '*':
			case '/':
				infix = "(";
				infix += prefixToInfix(prefix.substring(1, prefix.length()-1));
				infix += test;
				infix += prefix.charAt(prefix.length()-1);
				infix += ")";
				return infix;
			default:
				return test+"";
			}
		}
		return "";
	}
}