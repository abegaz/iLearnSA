
public class DivideByZero {

	public static void main(String[] args) {
		//divide by zero runtime exception
		int num1 = 50;
		int num2 = 0;
		System.out.println(num1/num2);
	}

}
