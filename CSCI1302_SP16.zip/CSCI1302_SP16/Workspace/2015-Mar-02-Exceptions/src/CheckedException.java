import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;


public class CheckedException {

	public static void main(String[] args) throws FileNotFoundException{
		//try{
			Scanner scan = new Scanner(new File("filename.txt"));
			/*
		}catch(FileNotFoundException e){
			e.printStackTrace();
		}*/
		

	}

}
