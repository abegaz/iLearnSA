import java.util.Scanner;


public class pp11_2 {

	public static void main(String[] args) {
		//create exception object
		StringToLongException exception = new StringToLongException("String has more than 20 characters");
		
		//ask for strings from user
		Scanner scan = new Scanner(System.in);
		String str;
		do{
			System.out.print("Enter a string: ");
			str = scan.next();
			
			//throw exception if string 20+ characters long
			try {
				if(str.length() > 20)
					throw exception;
			} catch (StringToLongException e) {
				System.out.println(e.getMessage());
				//e.printStackTrace();
			}
			
		}while(!str.equals("DONE"));//stop asking for strings when receiving "DONE"

		

	}

}
