
public class ExceptionScope {

	public void level1()
	{
		System.out.println("Begin Level 1");
		try{
			level2();
		}catch(ArithmeticException e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("End Level 1");
	}
	public void level2()
	{
		System.out.println("Begin Level 2");
		level3();
		System.out.println("End Level 2");
	}
	public void level3()
	{
		System.out.println("Begin Level 3");
		System.out.println(50/0);
		System.out.println("End Level 3");
	}
	/*
level 1-3 methods (level 3 divide by zero)
print begin/end
try/catch in level 1
ArithmeticException
getMessage()
printStackTrace

	 */
}
