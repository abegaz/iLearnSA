import java.util.Scanner;


public class ProductCodes {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a code:");
		String code = scan.next();//AAA1234AA
		int valid = 0;
		int banned = 0;
		while(!code.equals("DONE"))
		{
			try{
				char zone = code.charAt(9);
				int region = Integer.parseInt(code.substring(3, 7));
				valid++;
				if(zone == 'R' && region > 2000)
					banned++;
			}catch(StringIndexOutOfBoundsException e){
				System.out.println("invalid code, not correct length");
			}catch(NumberFormatException e){
				System.out.println("invalid code, region not a number");
			}
			
			System.out.print("Enter a code:");
			code = scan.next();//AAA1234AA
		}
		System.out.println("Number valid codes: " + valid);
		System.out.println("Number banned codes: " + banned);
		/*
		Read code from user input
		Code should be format: ***####**
		charAt(9), parseInt(substring(3,7))
		valid++
		9th character = R and number > 2000 = banned++
		StringIndexOutOfBoundsException
		NumberFormatException
		Print number of valid/banned codes
		*/
	}

}
