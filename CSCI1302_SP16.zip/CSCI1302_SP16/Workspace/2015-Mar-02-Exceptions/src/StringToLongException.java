
public class StringToLongException extends Exception {

	public StringToLongException(String msg) {
		super(msg);
	}

}
