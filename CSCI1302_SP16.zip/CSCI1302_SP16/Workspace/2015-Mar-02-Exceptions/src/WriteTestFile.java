import java.io.FileNotFoundException;
import java.io.PrintWriter;


public class WriteTestFile {

	public static void main(String[] args) {
		String filename = "output.txt";
		
		try {
			PrintWriter pw = new PrintWriter(filename);
			
			for(int i = 0; i < 1000; i++)
				pw.println(i);
			
			pw.close();
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e){
			e.printStackTrace();
		}

	}

}
