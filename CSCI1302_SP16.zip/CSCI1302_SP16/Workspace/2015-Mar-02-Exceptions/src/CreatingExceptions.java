import java.util.Scanner;


public class CreatingExceptions {

	public static void main(String[] args) throws OutOfRangeException {
		OutOfRangeException except = new OutOfRangeException();
		
		int num;
		Scanner scan = new Scanner(System.in);
		do{
			num = scan.nextInt();
			
			if(num > 20 || num < -1)
				throw except;
			
		}while(num != -1);

	}

}
