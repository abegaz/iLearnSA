
public class Propagation {

	public static void main(String[] args) {
		// call level 1 method
		ExceptionScope es = new ExceptionScope();
		es.level1();
	}

}
