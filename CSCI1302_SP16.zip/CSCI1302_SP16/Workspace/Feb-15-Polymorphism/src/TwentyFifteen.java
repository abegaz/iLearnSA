
public class TwentyFifteen {

	public static void main(String[] args) {
		Holiday[] days = new Holiday[2];
		
		days[0] = new FourthOfJuly();
		days[1] = new Halloween();
		
		for(int i = 0; i < days.length; i++)
		{
			System.out.println(days[i]);
		}

	}

}
