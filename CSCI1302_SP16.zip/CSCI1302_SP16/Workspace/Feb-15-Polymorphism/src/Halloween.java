
public class Halloween extends Holiday {

	public Halloween() {
		super("Halloween");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String celebrate() {
		return "Trick or Treat!";
	}

	@Override
	public String toString() {
		return "Halloween [celebrate()=" + celebrate() + ", getName()="
				+ getName() + "]";
	}

}
