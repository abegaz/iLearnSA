
public class FourthOfJuly extends Holiday {

	public FourthOfJuly() {
		super("4th of July");
		// TODO Auto-generated constructor stub
	}

	@Override
	public String celebrate() {
		return "Shoot fireworks!!";
	}
	@Override
	public String toString() {
		return "Fourth Of July [celebrate()=" + celebrate() + ", getName()="
				+ getName() + "]";
	}
}
