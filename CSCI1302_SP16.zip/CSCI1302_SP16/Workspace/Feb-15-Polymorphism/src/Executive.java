
public class Executive extends PaidEmployee {
	private double bonus;

	public Executive(String name, String address, String phone,
			String socialSecurityNumber, double payRate) {
		super(name, address, phone, socialSecurityNumber, payRate);
		this.bonus = 0;
	}

	public double getBonus() {
		return bonus;
	}

	public void awardBonus(double bonus) {
		this.bonus = bonus;
	}
	public double pay()
   {
      double payment = super.pay() + bonus;

      bonus = 0;

      return payment;
   }
}
