
public class Hourly extends PaidEmployee {
	private int hoursWorked;

	public Hourly(String name, String address, String phone,
			String socialSecurityNumber, double payRate) {
		super(name, address, phone, socialSecurityNumber, payRate);
		this.hoursWorked = 0;
	}

	public int getHoursWorked() {
		return hoursWorked;
	}

	public void addHours(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public double pay()
   {
      double payment = payRate * hoursWorked;

      hoursWorked = 0;

      return payment;
   }
}
