
public class ReadingMaterial implements Comparable<ReadingMaterial> {

	@Override
	public int compareTo(ReadingMaterial o) {
		// TODO Auto-generated method stub
		return 0;
	}

}
