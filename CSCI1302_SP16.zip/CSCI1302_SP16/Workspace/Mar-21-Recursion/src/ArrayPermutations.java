import java.util.Arrays;


public class ArrayPermutations {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		printPermutations(new int[]{1,2,3,4,5,6,7,8,9,10}, 0);
	}
	public static void printPermutations(int arr[], int i)
	{
		if(i == 0)
			System.out.println(Arrays.toString(arr));
		
		if(i+1 < arr.length)
			printPermutations(arr, i+1);
		
		int swap;
		for(int j = i+1; j < arr.length; j++)
		{
			swap = arr[i];
			arr[i] = arr[j];
			arr[j] = swap;
			
			System.out.println(Arrays.toString(arr));
			
			printPermutations(arr, i+1);
			
			swap = arr[i];
			arr[i] = arr[j];
			arr[j] = swap;
		}
	}

}
