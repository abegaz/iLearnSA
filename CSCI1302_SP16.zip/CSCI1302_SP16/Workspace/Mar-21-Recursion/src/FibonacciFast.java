import java.math.BigInteger;
import java.util.ArrayList;


public class FibonacciFast {
	public static ArrayList<BigInteger> fib = new ArrayList<BigInteger>();
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("5600:" + fib(5600));
		System.out.println("5000:" + fib(5000));
		System.out.println("5100:" + fib(5100));
		System.out.println("5200:" + fib(5200));
		System.out.println("5300:" + fib(5300));
		System.out.println("5400:" + fib(5400));
		System.out.println("5500:" + fib(5500));
		System.out.println("5600:" + fib(5600));
	}
	public static BigInteger fib(int n)
	{
		fib.ensureCapacity(n);
		if(fib.size() == 0)//put base cases in array list
		{
			fib.add(BigInteger.ZERO);
			fib.add(BigInteger.ONE);
		}
		if(fib.size() >= n+1)
			return fib.get(n);
		fib.add(n, fib(n-1).add(fib(n-2)));
		return fib.get(n);
	}
}
