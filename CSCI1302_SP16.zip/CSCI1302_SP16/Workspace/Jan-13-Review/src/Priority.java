
public interface Priority {
	public void setPriority(int x);
	public int getPriority();
}
