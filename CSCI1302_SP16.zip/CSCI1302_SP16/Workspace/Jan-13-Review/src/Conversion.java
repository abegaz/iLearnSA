import java.text.DecimalFormat;
import java.util.Scanner;


public class Conversion {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		int x = 5;
		long y = 10;
		double z = 5;
		System.out.println("z:" + z);
		double a = x*z;
		System.out.println("a:" + a);
		x = (int)a;
		System.out.println("x:" + x);
		
		DecimalFormat df = new DecimalFormat(".00");
		
		System.out.println(df.format(a));
		a = 5.1234;
		System.out.println(df.format(a));
		a = 0.1;
		System.out.println(df.format(a));
		
		double b = 1.23456789;
		double c = 1.234567899;
		
		double temp = b-c;
		if(Math.abs(temp) <= 0.00000000001)
		{
			System.out.println("close enough");
		}
		else
			System.out.println("not close enough");
		
		x = 25;
		switch(x)
		{
		case 25:
			System.out.println("25");
			break;
		case 24:
			System.out.println("24");
			break;
		default:
			System.out.println("none");
			break;
		}
		
		if(x == 25)
		{
			
		}
		else if(x == 24)
		{
			
		}
		else
		{
			
		}
		
		
		int d = 1, e = 2, f = 3;
		System.out.println((d > 0) ? e : f);
		
		System.out.println("While:");
		d = 3;
		while(d > 0)
		{
			System.out.println(d);
			d--;
		}
		System.out.println("Do:");
		do{
			System.out.println(d);
			d--;			
		}while(d > 0);
		
		System.out.println("For:");
		for(int i = 0; i < 5; i++)
		{
			System.out.println(i);
		}
		
		System.out.println("Scanner:");
		Scanner s = new Scanner("Hello World, Here is a line of text");
		while(s.hasNext())
		{
			System.out.println(s.next());
		}
		System.out.println("End of Scanner");
		
		System.out.println(Math.PI);
	}

}
