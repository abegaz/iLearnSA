
public class Rectangle implements Priority, Comparable<Rectangle> {
	/*
	 * Instance Date (States)
	 */
	private int width;
	private int height;
	private int priority;
	private static int counter;
	
	/*
	 * Constructors
	 */
	public Rectangle()
	{
		width = 5;
		height = 5;
		counter++;
	}
	public Rectangle(int x)
	{
		width = x;
		height = x;
		counter++;
	}
	public Rectangle(int x, int y)
	{
		counter++;
		if(x > 0 && y > 0)
		{
			width = x;
			height = y;
		}
		else if(x > 0)
		{
			width = x;
			height = x;
		}
		else if(y > 0)
		{
			width = y;
			height = y;
		}
		else
		{
			width = 1;
			height = 1;
		}
	}

	
	/*
	 * Accessors/Mutators (Getters/Setters)
	 */
	public int getWidth() {
		return width;
	}
	public void setWidth(int w) {
		if(w > 0)
		{
			width = w;
		}
	}
	public int getHeight() {
		return height;
	}
	public void setHeight(int height) {
		if(height > 0)
			this.height = height;
	}
	
	/*
	 * toString
	 */
	@Override
	public String toString() {
		return "Rectangle [width=" + width + ", height=" + height + "]";
	}
	
	/*
	 * Methods (Behaviors)
	 */
	public Integer getArea()
	{
		return width*height;
	}
	public static int getRectangleArea(int x, int y)
	{
		return x*y;
	}
	
	
	/*
	 * Interface Methods
	 */
	@Override
	public void setPriority(int x) {
		priority = x;
	}
	@Override
	public int getPriority() {
		// TODO Auto-generated method stub
		return priority;
	}
	@Override
	public int compareTo(Rectangle o) {
		return this.getArea().compareTo(o.getArea());
	}
}
