
public class Propagation {

	public static void main(String[] args) {
		//Call level 1 in Exception Scope
		ExceptionScope es = new ExceptionScope();
		
		es.method1();
	}

}
