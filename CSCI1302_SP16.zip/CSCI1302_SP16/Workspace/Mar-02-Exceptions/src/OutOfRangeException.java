
public class OutOfRangeException extends Exception {
	public OutOfRangeException() {
		super("Number out of range.");
	}
}
