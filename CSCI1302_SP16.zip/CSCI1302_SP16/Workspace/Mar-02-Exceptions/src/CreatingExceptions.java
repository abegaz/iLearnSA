import java.util.Scanner;


public class CreatingExceptions {

	public static void main(String[] args) throws OutOfRangeException {
		//Create an object of the OutOfRangeException
		//Read numbers from the user until -1
		//throw out of range exception if greater than a given value
		OutOfRangeException exc = new OutOfRangeException();
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		while(num != -1)
		{
			//try{
			if(num > 20 || num < 0)
				throw exc;
			//}catch(OutOfRangeException e){
			//	System.out.println(e.getMessage());
			//}
			num = scan.nextInt();
		}
	}

}
