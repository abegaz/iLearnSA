import java.io.IOException;
import java.io.PrintWriter;


public class WriteTestFile {

	public static void main(String[] args) //throws IOException
	{
		String filename = "output.txt";
		try{
			PrintWriter pw = new PrintWriter(filename);
			for(int i = 0; i < 50; i++)
			{
				pw.println(Math.random());
			}
			pw.close();
		}catch(IOException e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}

	}

}
