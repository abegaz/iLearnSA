import java.util.Scanner;

//Program should crash when an exception is hit
public class PP11_1 {

	public static void main(String[] args) throws StringToLongException {
		//Create objects of scanner and exception
		Scanner scan = new Scanner(System.in);
		StringToLongException except = new StringToLongException();
		
		//get words from user until entering "DONE"
		String word = scan.next();
		while(!word.equals("DONE"))
		{
			//if word is to long, throw exception
			if(word.length() > 20)
			{
				throw except;
			}
			word = scan.next();
		}

	}

}
