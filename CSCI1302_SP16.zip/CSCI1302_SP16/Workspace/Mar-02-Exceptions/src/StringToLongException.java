
public class StringToLongException extends Exception {
	public StringToLongException()
	{
		super("String is to long!");
	}
	public StringToLongException(String s)
	{
		super(s);
	}
}
