
public class ExceptionScope {
	public void method1()
	{
		System.out.println("Begin Method 1");
		try{
			method2();
		}catch(ArithmeticException e){
			//System.out.println(e.getMessage());
			//e.printStackTrace();
		}catch(Exception e){
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
		System.out.println("End Method 1");
	}
	public void method2()
	{
		System.out.println("Begin Method 2");
		method3();
		System.out.println("End Method 2");
	}
	public void method3()
	{
		System.out.println("Begin Method 3");
		System.out.println(50/0);
		System.out.println("End Method 3");
	}
/*
level 1-3 methods (level 3 divide by zero)
print begin/end
try/catch in level 1
ArithmeticException
getMessage()
printStackTrace
*/
}
