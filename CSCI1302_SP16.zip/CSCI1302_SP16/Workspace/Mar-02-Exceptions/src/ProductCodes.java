import java.util.Scanner;


public class ProductCodes {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter a codes: ");//AAA1234AA
		String code = scan.next();
		int valid = 0, invalid = 0;
		while(!code.equals("DONE")){
			try{
				char region = code.charAt(8);
				int num = Integer.parseInt(code.substring(3,7));
				if(region == 'R' && num > 2000)
					invalid++;
				else
					valid++;
			}catch(StringIndexOutOfBoundsException e){
				System.out.println("Your code was not the correct length");
			}catch(NumberFormatException e){
				System.out.println("Your code was not correctly formatted");
			}finally{
				code = scan.next();
			}
			
		}
		System.out.println("Valid: " + valid);
		System.out.println("Invalid: " + invalid);
		/*
		Read code from user input
		Code should be format: ***####**
		charAt(9), parseInt(substring(3,7))
		valid++
		9th character = R and number > 2000 = banned++
		StringIndexOutOfBoundsException
		NumberFormatException
		Print number of valid/banned codes
		*/
	}

}
