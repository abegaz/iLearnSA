import java.io.File;
import java.io.IOException;
import java.util.Scanner;


public class CheckedException {

	public static void main(String[] args)// throws IOException
	{
		try{
			Scanner scan = new Scanner(new File("input.txt"));
		}catch(IOException e){
			
		}
	}

}
