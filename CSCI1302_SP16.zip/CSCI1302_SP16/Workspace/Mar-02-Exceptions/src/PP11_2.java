import java.util.Scanner;

//Program should crash when an exception is hit
public class PP11_2 {

	public static void main(String[] args) {
		//Create objects of scanner and exception
		Scanner scan = new Scanner(System.in);
		StringToLongException except = new StringToLongException();
		
		//get words from user until entering "DONE"
		String word = scan.next();
		while(!word.equals("DONE"))
		{
			try{
				//if word is to long, throw exception
				if(word.length() > 20)
				{
					throw except;
				}
			}catch(StringToLongException e){
				System.out.println(e.getMessage());
			}
			word = scan.next();
		}

	}

}
