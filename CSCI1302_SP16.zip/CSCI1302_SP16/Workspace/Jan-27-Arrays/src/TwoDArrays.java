import java.util.Arrays;


public class TwoDArrays {

	public static void main(String[] args) {
		int[] numbers = new int[5];
		Arrays.fill(numbers, 5);
		
		int[][] grid = new int[2][5];
		/*
		 * 1, 2, 3, 4, 5
		 * 6, 7, 8, 9, 10
		 */
		for(int x = 0; x < grid.length; x++)
		{
			for(int y = 0; y < grid[0].length; y++)
			{
				grid[x][y] = x+y;
				System.out.println("x:" + x + ", y:" + y + ", val:" + grid[x][y]);
			}
		}
		
		numbers = grid[0];
		for(int i = 0; i < numbers.length; i++)
		{
			System.out.println(numbers[i]);
		}
		
		System.out.println(grid[1][4]);
		
		
		
	}

}
