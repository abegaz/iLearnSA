
public class VariableLengthParameterList {

	public static void main(String[] args) {
		System.out.println(TestClass.average("Students",10,15,20));
		System.out.println(TestClass.average("Grades",10,15,20,25,30));
		System.out.println(TestClass.distance(10,15,20));
		System.out.println(TestClass.distance(10,15,20,25,30));
	}

}
