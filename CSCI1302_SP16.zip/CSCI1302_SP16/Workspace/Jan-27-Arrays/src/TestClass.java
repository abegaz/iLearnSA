
public class TestClass {

	public static double average(String name, double ... nums)
	{
		System.out.print(name + " : ");
		double sum = 0;
		for(double num : nums)
			sum += num;
		return sum/nums.length;
	}
	public static int distance(int ... distances)
	{
		int sum = 0;
		for(int num : distances)
			sum += num;
		return sum;
	}
}
