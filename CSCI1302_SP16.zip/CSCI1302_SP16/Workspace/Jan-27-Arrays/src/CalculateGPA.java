import java.text.DecimalFormat;
import java.util.Scanner;

/*
 * 
Create a multidimensional array that stores 
	Course Number(1301), GPA(0.0-4.0), Credit Hours, 
	Quality Points(GPA * Credit Hours)

Ask the user for the Course Number, GPA, Credit Hours

Calculate the Quality Points

Loop through the array, print each item, 
	store a running total of credit hours and quality points

Calculate overall GPA from these values (total quality points/total credit hours)

 */
public class CalculateGPA {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("How many courses have you taken:");
		int courseCount = scan.nextInt();
		double[][] courseInfo = new double[courseCount][4];
		for(int i = 0; i < courseCount; i++)//can also use i < hobbyInfo.length
		{
			System.out.print("Course Number:");
			courseInfo[i][0] = scan.nextDouble();
			System.out.print("GPA:");
			courseInfo[i][1] = scan.nextDouble();
			System.out.print("Credit Hours:");
			courseInfo[i][2] = scan.nextDouble();
			//Quality points = Credits * GPA
			courseInfo[i][3] = courseInfo[i][1]*courseInfo[i][2];
		}
		/*
Loop through the array, print each item, 
	store a running total of credit hours and quality points

Calculate overall GPA from these values (total quality points/total credit hours)

		 */
		double totalQuality = 0, totalCredit = 0;
		for(int i = 0; i < courseCount; i++)//can also use i < hobbyInfo.length
		{
			System.out.println("Course " + (int)courseInfo[i][0] +
					", Grade:" + courseInfo[i][1] +
					", Credit Hours:" + (int)courseInfo[i][2] +
					", Quality Points:" + courseInfo[i][3]);
			totalQuality += courseInfo[i][3];
			totalCredit += courseInfo[i][2];
		}
		DecimalFormat df = new DecimalFormat("0.0");
		System.out.println("Overall GPA:" + df.format(totalQuality/totalCredit));
	}

}
