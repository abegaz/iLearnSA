import java.util.Scanner;

/*
Prompt the user for a number of hobbies
Use this number to create a multidimensional array 
	to hold the following information about each hobby
		Name of hobby (Reading)
		Number of hours spent on hobby each week (2)
		Number of people you do the hobby with (1)
Prompt the user for their hobby information
Print out the data received
Print out the sum of hours spent on hobbies
Print out the average number of people you do hobbies with
*/
public class Hobbies {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("How many hobbies do you have:");
		int hobbyCount = scan.nextInt();
		String[][] hobbyInfo = new String[hobbyCount][3];
		for(int i = 0; i < hobbyCount; i++)//can also use i < hobbyInfo.length
		{
			scan.nextLine();
			System.out.print("Hobby Name:");
			hobbyInfo[i][0] = scan.nextLine();
			System.out.print("Hours spent on hobby:");
			hobbyInfo[i][1] = scan.next();
			scan.nextLine();
			System.out.print("Number of people you do the hobby with:");
			hobbyInfo[i][2] = scan.next();
		}
		/*
Print out the data received
Print out the sum of hours spent on hobbies
Print out the average number of people you do hobbies with
		 */
		double sum = 0;
		int numPeople = 0;
		for(int i = 0; i < hobbyCount; i++)//can also use i < hobbyInfo.length
		{
			System.out.println("My hobby is " + hobbyInfo[i][0]
					+ " and I spend "  + hobbyInfo[i][1]
					+ " hours doing my hobby with "  + hobbyInfo[i][2]
					+ " people.");
			sum += Double.parseDouble(hobbyInfo[i][1]);
			numPeople += Integer.parseInt(hobbyInfo[i][2]);
		}
		System.out.println("Total hours spent on hobbies:" + sum);
		System.out.println("Average people I do hobbies with: " 
				+ (numPeople/(double)hobbyCount) );
	}

}
