/*
 * Group #3 - DRAM Contest
 * CSCI1302 - Section DC (5:30pm-7:20pm)
 * Matthew Freeman
 * Christopher Patrick
 * Savannah Oaks
 * Richard Wilbanks
 */

import java.math.BigInteger;
import java.util.Scanner;
 
public class PalindromeTest
{
    //Creating methods for processing the numbers
     
	static BigInteger reverseNumber(BigInteger number)  //method that reverses the BigInteger
    {
    	    	{
    	StringBuilder reverse = new StringBuilder();
    	String valString = number.toString();
		reverse.append(valString);
		String valReverse = reverse.reverse().toString();
		BigInteger reversed = new BigInteger(valReverse);
    	       
        return reversed;
    	}
    }
     
    
	static boolean checkForPal(BigInteger number) //Method that checks if it's a palindrome or not
    {
		
		{
        BigInteger reverse = reverseNumber(number);
         
        if(reverse.equals(number))
        {
            return true;
        }
        else
        {
            return false;
        }}
    }
     
   
    static void reverseAdd(BigInteger number) //checks for palindrome and says so if it is, otherwise, reverses and adds until it is one
    {
        if(checkForPal(number))
        {
            System.out.println("Initial value: " + number + " gives palindrome " +number);
        }
        else
        {
        	int count = 0;
        	BigInteger num2 = number;
            while (!checkForPal(number) && count < 1001)
            {
            	
                BigInteger reverse = reverseNumber(number);
                 
                BigInteger sum = number.add(reverse);
                                    
                number = sum;
                
                count++;
                if(checkForPal(number))
                {
                	System.out.println("Initial Value: " + num2 + " gives palindrome " +sum);
                }
                if(count == 1001) // if it tries to go over 1000, it says there's no palindrome
                {
                	System.out.println("Initial value: " + num2 + " No palindrome found.");
                }
            	}
            }
            
        }

     
    public static void main(String[] args) 
    {
        Scanner scan = new Scanner(System.in);
         
        System.out.println("Please enter a number to test for a palindrome: ");
         
        BigInteger val = BigInteger.valueOf(0);
        BigInteger end = BigInteger.valueOf(-1);
        
        
        {
            
        do{
        
        val = scan.nextBigInteger();
        if(val.intValue() == end.intValue())
        {
        	break;
        }
        else{
    	reverseAdd(val);
        }   
    	}while(val.intValue() != end.intValue());
        }
    }
}
        
     