/*
Author:JET
Date Written:Oct 22, 2014
ACM:SE 2006

Problem: Digital Reversal Addition Method (DRAM)
*/
import java.util.Scanner;
import java.math.BigInteger;
public class DRAM2
{
    public static void main(String[] args)
    {
		//System.out.println(Integer.MAX_VALUE);
		//System.exit(0);
        //Scanner s = new Scanner(System.in);
        int input = 0, prevMaxFound = 0, maxFound = 0;
        while(input <= Integer.MAX_VALUE)
        {
            boolean found = false;
            //System.out.print("Initial Value: " + input);
            BigInteger num1 = new BigInteger(Integer.toString(input));
            int i;
            for(i = 0; i <= 1000; i++)
            {
                BigInteger num2 = new BigInteger(new StringBuilder(num1.toString()).reverse().toString());
                found = num1.equals(num2);
                if(found)
                {
					if(maxFound < i)
						maxFound = i;
                    //System.out.println(" gives palindrome " + num1.toString());
                    break;
                }
                else
                    num1 = num1.add(num2);
            }
            //if(!found)
                //System.out.println(" No palindrome found");
            //System.out.println(i);
            if(prevMaxFound < maxFound)
            {
				prevMaxFound = maxFound;
				System.out.println("Iterations: " + maxFound + " :: For input: " + input);
			}
            input++;
        }
    }
}