/*Daniel Hicks
Parth Patel
Anna Blasingame
Christian Watts
Drake Packard*/

import java.math.BigInteger;
import java.util.Scanner;


public class Group4 
{

	public static void main(String[] args)
	{
		int value = 0;
		String s1Value =  " ";
		StringBuilder sReverse;
		long counter = 0;
		int reverseInt;
		BigInteger added;
		String addedS;
		boolean found = false;
		
		do //while1
		{
			Scanner scan = new Scanner (System.in);
			//System.out.println("Enter the interger (-1 to stop");//make sure to remove
			value = scan.nextInt();
			found = false;
			counter = 1;
			
			
				//takes the first value and turns it into big int
				BigInteger initialVal = new BigInteger(Integer.toString(value));
				
				
				while (counter <= 1000 && found == false && value !=-1)
					{
					
						
						
						//turns the first value to a string
						s1Value = initialVal.toString();
						
						//creates a new StringBuilder and stores the initial value
						StringBuilder reverseString = new StringBuilder(s1Value);
						reverseString.reverse();//reverses the value
						
						//stores the reversed value in a big integer
						BigInteger reverseVal = new BigInteger(reverseString.toString());
						
						
						if (s1Value.equals(reverseString.toString()) == true)
						{
							System.out.println ("Inintial Value: " + value + " gives palindrome " + value);
							found = true;	
						}
						
						
						//added the two big ints together
						added = initialVal.add(reverseVal);
						
						addedS = added.toString();
						StringBuilder reverseAdded= new StringBuilder(addedS);
						reverseAdded.reverse();
						
						///System.out.println(added);
						
						if (addedS.equals(reverseAdded.toString()) == true)
						{
							System.out.println ("Inintial Value: " + value + " gives palindrome " + added);
							found = true;	
						}
						
						 initialVal = added;
						counter++;
					}//end 2 while
				
				
					if (found != true && value !=-1)
					{
						System.out.println ("Inintial Value: " + value + " No palindrome found ");
					}
			
		} while (value != -1);
		
		
	}

}
