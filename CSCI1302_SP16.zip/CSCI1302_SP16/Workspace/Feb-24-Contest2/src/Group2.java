//Team 2: Himanshu Mangla, Rachel Henderson, Tyler Moon, Brandon Byers

import java.math.BigInteger;
import java.util.Scanner;
import java.lang.StringBuilder;

public class DRAM {

	public static boolean isPalindrome(String s) {
		  int n = s.length();
		  if (n==1)
		  {
			  return true;
		  }
		  for (int i=0;i<(n / 2) + 1;++i) {
		     if (s.charAt(i) != s.charAt(n - i - 1)) {
		         return false;
		     }
		  }

		  return true;
		}

	public static void main (String []args)
	{
		
		System.out.println("Enter in value.");
		Scanner scan = new Scanner (System.in);
	    String blah = scan.nextLine();
	    int asdf = Integer.parseInt(blah);

	    
	    while(asdf>0)
	    {
		boolean isPalindrome = false;
		boolean pal = true;
	    BigInteger value = new BigInteger(blah);
	   if (isPalindrome(blah)==true)
	   {
		   System.out.println("Initial Value: "+ blah + " gives palindrome " +  blah);
	   }
	   else
	   {
	    String temp = "";
	    temp += value;
	    StringBuilder sb = new StringBuilder(temp);
	    sb.reverse();
	    //System.out.println(sb);
	    
	    String temp2 = (sb.toString());
	    BigInteger value2 = new BigInteger (temp2);
	    BigInteger value3 = value.add(value2);
	    //System.out.println(value3.toString());
	    String test = value3.toString();
	    //System.out.println(isPalindrome(test));
	    
	    if (isPalindrome(test)==false)
	    {
	    	for (int i = 0; i < 999; i++)
	    	{
	    		String temp3 = value3.toString();
	    		StringBuilder sb2 = new StringBuilder(temp3);
	    		sb2.reverse();
	    		String temp4 = (sb2.toString());
	    		BigInteger value4 = new BigInteger (temp4);
	    		BigInteger value5 = value3.add(value4);
	    		if (isPalindrome(value5.toString())==true)
	    		{
	    			System.out.println("Initial Value: "+ blah + " gives palindrome " +  value5);
	    			i = 999;
	    			pal = true;
	    		}
	    		else
	    		{
	    			value3 = value5;
	    			pal = false;
	    		}
	    	}
	    	
	    	}
	    	else
	    	{
	    		System.out.println("Initial Value: "+ blah + " gives palindrome " +  test);
	    	}
	    		
	   
	}
	   if (pal==false)
	   {
		   System.out.println("No Palindrome found.");
	   }
	   
	   System.out.println("Enter in value.");
	    blah = scan.nextLine();
	    asdf = Integer.parseInt(blah);

}
}
}

