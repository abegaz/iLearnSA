/*
Author:JET
Date Written:Oct 22, 2014
ACM:SE 2006

Problem: Digital Reversal Addition Method (DRAM)
*/
import java.util.Scanner;
import java.math.BigInteger;
public class DRAM
{
    public static void main(String[] args)
    {
        Scanner s = new Scanner(System.in);
        int input = s.nextInt();
        while(input != -1)
        {
            boolean found = false;
            System.out.print("Initial Value: " + input);
            BigInteger num1 = new BigInteger(Integer.toString(input));
            for(int i = 0; i <= 1000; i++)
            {
                BigInteger num2 = new BigInteger(new StringBuilder(num1.toString()).reverse().toString());
                found = num1.equals(num2);
                if(found)
                {
                    System.out.println(" gives palindrome " + num1.toString());
                    break;
                }
                else
                    num1 = num1.add(num2);
            }
            if(!found)
                System.out.println(" No palindrome found");
            input = s.nextInt();
        }
    }
}