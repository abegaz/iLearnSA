import java.util.Arrays;
import java.util.Scanner;


public class SafeCrackerExample {
	public static String[][] grid;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		grid = new String[size][size];
		int y=0, x=0;
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				grid[i][j] = s.next().toUpperCase();
				if(grid[i][j].equals("OPEN"))
				{
					x = j;
					y = i;
				}
			}
		}
		System.out.println(traverse(x,y));
	}
	//Start at OPEN and work backwards
	public static String traverse(int x, int y)
	{
		/*
		 * Check up, left, down, right for square that leads to current one
		 * Call method again on found square
		 * when no option found, you have completed the path
		 */
		return "";
	}
}
