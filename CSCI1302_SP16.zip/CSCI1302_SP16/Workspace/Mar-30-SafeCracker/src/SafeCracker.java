
import java.util.Scanner;

public class SafeCracker {
	public static String[][] safe;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		for(int i = s.nextInt(); i > 0; i--)
		{
			int posx = 0;
			int posy = 0;
			int size = s.nextInt();
			safe = new String[size][size];
			//nested loops to fill grid
			for(int y = 0; y < size; y++)
			{
				for(int x = 0; x < size; x++)
				{
					safe[x][y] = s.next().toUpperCase();
					//if found "OPEN", store position
					if(safe[x][y].equals("OPEN"))
					{
						posx = x;
						posy = y;
					}
				}
			}
			//find path
			System.out.println(findPath(posx, posy) + "OPEN");
		}
	}
	public static String findPath(int posx, int posy)
	{
		int count = 0;
		//check up
		count = 0;
		for(int i = posy-1; i >= 0; i--)
		{
			count++;
			if(safe[posx][i].equals(count+"D"))
			{
				return findPath(posx, i) + safe[posx][i] + " " ;
			}
		}
		//check left
		count = 0;
		for(int i = posx-1; i >= 0; i--)
		{
			count++;
			if(safe[i][posy].equals(count+"R"))
			{
				return findPath(i, posy) + safe[i][posy] + " " ;
			}
		}
		//check down
		count = 0;
		for(int i = posy+1; i < safe.length; i++)
		{
			count++;
			if(safe[posx][i].equals(count+"U"))
			{
				return findPath(posx, i) + safe[posx][i] + " " ;
			}
		}
		//check right
		count = 0;
		for(int i = posx+1; i < safe.length; i++)
		{
			count++;
			if(safe[i][posy].equals(count+"L"))
			{
				return findPath(i, posy)+ safe[i][posy] + " " ;
			}
		}
		return "";
	}
}