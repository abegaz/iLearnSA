import java.util.ArrayList;


public class recursion {
	
	public static ArrayList<Integer> nums = new ArrayList<>();
	
	public static void main(String[] args) {
		String numbers = "1,4,7,9,2,3";
		List(numbers);
		System.out.println(nums);
		
		System.out.println("5! = " + factorial(5));
		
		System.out.println("5*3 = " + fivesByOne(3));
		
		System.out.println("5*3 = " + fivesByTwo(3));
		System.out.println("5*4 = " + fivesByTwo(4));
		
	}
	
	public static void List(String list)
	{
		System.out.println(list);
		if(list.length() >= 2)
		{
			int number = Integer.parseInt(list.substring(0, 1));
			nums.add(number);
			list = list.substring(2);
			List(list);
		}
		else
		{
			int number = Integer.parseInt(list.substring(0, 1));
			nums.add(number);
		}
	}
	public static int factorial(int n)
	{
		System.out.println(n+"!");
		if(n == 1)
		{
			return 1;
		}
		else
		{
			return n * factorial(n-1);
		}
	}
	
	public static int fivesByOne(int n)
	{
		if(n == 1)
			return 5;
		else
			return 5 + fivesByOne(n-1);
	}
	public static int fivesByTwo(int n)
	{
		if(n == 1)
			return 5;
		else if(n == 2)
			return 10;
		else
			return 10 + fivesByTwo(n-2);
	}

}
