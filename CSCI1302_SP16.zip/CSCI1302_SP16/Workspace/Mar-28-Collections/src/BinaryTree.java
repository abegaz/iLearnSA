import java.util.Arrays;
import java.util.Scanner;


public class BinaryTree {


	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String tree = scan.nextLine();//correct format : (a()())
		String[] t = splitTree(tree);
		System.out.println(Arrays.toString(t));

	}
	public static String[] splitTree(String tree)
	{
		//expected tree format
		//(node tree tree)
		//0 1 2-x x-(length-2) length-1
		if(tree.length() <= 2)//tree not long enough to process
			return new String[]{tree, "", ""};

		String[] temp = new String[3];
		temp[0] = "" + tree.charAt(1);//grab tree node
		tree = tree.substring(2, tree.length()-1);//remove node and outer paren
		int parenCount = 0;//count of open paren
		int endTreeOne = 0;//end of first tree
		for(int i = 0; i < tree.length(); i++)
		{
			if(tree.charAt(i) == '(')
				parenCount++;
			if(tree.charAt(i) == ')')
				parenCount--;
			if(parenCount == 0)
			{
				endTreeOne = i;
				break;//ends for loop early
			}
		}
		temp[1] = tree.substring(0, endTreeOne+1);//left tree
		temp[2] = tree.substring(endTreeOne+1);//right tree
		return temp;
	}

}
