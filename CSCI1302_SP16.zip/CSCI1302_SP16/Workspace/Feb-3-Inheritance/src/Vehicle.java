
public class Vehicle implements Comparable<Vehicle> {
	private boolean land;
	private boolean sea;
	private boolean air;
	private int passengers;
	public Vehicle(boolean land, boolean sea, boolean air, int passengers) {
		this.land = land;
		this.sea = sea;
		this.air = air;
		this.passengers = passengers;
	}
	public boolean isLand() {
		return land;
	}
	public void setLand(boolean land) {
		this.land = land;
	}
	public boolean isSea() {
		return sea;
	}
	public void setSea(boolean sea) {
		this.sea = sea;
	}
	public boolean isAir() {
		return air;
	}
	public void setAir(boolean air) {
		this.air = air;
	}
	public int getPassengers() {
		return passengers;
	}
	@Override
	public String toString() {
		String temp = "Vehicle travels over ";
		if(land)
			temp += "land ";
		if(sea)
			temp += "sea ";
		if(air)
			temp += "air ";
		temp += "with " + passengers + " passengers.";
		return temp;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (air ? 1231 : 1237);
		result = prime * result + (land ? 1231 : 1237);
		result = prime * result + passengers;
		result = prime * result + (sea ? 1231 : 1237);
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		if (air != other.air)
			return false;
		if (land != other.land)
			return false;
		if (passengers != other.passengers)
			return false;
		if (sea != other.sea)
			return false;
		return true;
	}
	public void setPassengers(int passengers) {
		this.passengers = passengers;
	}
	@Override
	public int compareTo(Vehicle o) {
		if(land == o.isLand() &&
				air == o.isAir() &&
				sea == o.isSea() &&
				passengers == o.getPassengers())
			return 0;
		if(passengers > o.getPassengers())
			return 1;
		else
			return -1;
	}
	
}
