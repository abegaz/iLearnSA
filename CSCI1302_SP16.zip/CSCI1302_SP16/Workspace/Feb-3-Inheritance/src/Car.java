
public class Car extends Vehicle {
	private int wheels;
	public Car(int passengers, int wheels) {
		super(true, false, false, passengers);
		this.wheels = wheels;
		// TODO Auto-generated constructor stub
	}
	public int getWheels() {
		return wheels;
	}
	public void setWheels(int wheels) {
		this.wheels = wheels;
	}
	@Override
	public String toString() {
		return "Car has " + wheels + " wheels, " + super.toString();
	}

}
