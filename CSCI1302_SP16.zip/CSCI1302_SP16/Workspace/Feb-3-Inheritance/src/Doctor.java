
public class Doctor extends Employee {
	private int numberOfPatients;
	public Doctor(double salary, int hoursWorked, String firstName, String lastName)
	{
		super(salary, hoursWorked, firstName,
				lastName);
		numberOfPatients = 0;
	}
	public int getNumberOfPatients() {
		return numberOfPatients;
	}
	public void setNumberOfPatients(int numberOfPatients) {
		this.numberOfPatients = numberOfPatients;
	}
	public void makeRounds()
	{
		System.out.println("Dr. " + super.getLastName() 
				+ " is making rounds to see patients");
	}
}
