
public class Janitor extends Employee {

	public Janitor(double salary, int hoursWorked, String firstName,
			String lastName) {
		super(salary, hoursWorked, firstName, lastName);
		// TODO Auto-generated constructor stub
	}
	public void sweep()
	{
		System.out.println(super.getFirstName() + " " + super.getLastName() 
				+ " is sweeping the floor");
	}

}
