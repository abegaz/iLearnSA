import java.text.DecimalFormat;
public class Employee implements Comparable<Employee> {
	private Double salary;
	private int hoursWorked;
	private String firstName;
	private String lastName;
	private static DecimalFormat df = new DecimalFormat("0.00");
	public Employee(double salary, int hoursWorked, String firstName,
			String lastName) {
		this.salary = salary;
		this.hoursWorked = hoursWorked;
		this.firstName = firstName;
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return firstName + " " + 
				lastName + " works " + 
				hoursWorked + " hours and makes $" + 
				df.format(salary);
	}
	public Double getSalary() {
		return salary;
	}
	public void setSalary(Double salary) {
		this.salary = salary;
	}
	public int getHoursWorked() {
		return hoursWorked;
	}
	public void setHoursWorked(int hoursWorked) {
		this.hoursWorked = hoursWorked;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public int compareTo(Employee o) {
		// TODO Auto-generated method stub
		if(salary.compareTo(o.getSalary()) > 0)
			return -1;
		else if(salary.compareTo(o.getSalary()) < 0)
			return 1;
		else
		{
			return lastName.compareTo(o.getLastName());
		}
	}
	
}
