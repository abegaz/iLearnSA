import java.util.Arrays;


public class HospitalTester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Doctor d1 = new Doctor(95000, 60, "Bob", "Barker");
		Janitor j1 = new Janitor(15.50, 60, "Joe", "Dirt");
		
		d1.makeRounds();
		j1.sweep();
		
		System.out.println(d1);
		System.out.println(j1);
		if(d1.compareTo(j1) > 0)
			System.out.println("Doctor has a higher salary than janitor");
		else if(d1.compareTo(j1) < 0)
			System.out.println("Doctor has a lower salary than janitor");
		else if(d1.compareTo(j1) == 0)
			System.out.println("Doctor has the same salary as the janitor");
		
		Employee[] employees = new Employee[5];
		employees[0] = new Doctor(95000, 60, "Bob1", "Barker1");
		employees[1] = new Janitor(20.5, 60, "Bob2", "Barker2");
		employees[2] = new Doctor(100000, 60, "Bob3", "Barker3");
		employees[3] = new Janitor(15.5, 60, "Bob4", "Barker4");
		employees[4] = new Doctor(75000, 60, "Bob5", "Barker5");
		
		for(int i = 0; i < employees.length; i++)
		{
			System.out.println(employees[i]);
		}
		Arrays.sort(employees);
		for(int i = 0; i < employees.length; i++)
		{
			System.out.println(employees[i]);
		}
	}

}
