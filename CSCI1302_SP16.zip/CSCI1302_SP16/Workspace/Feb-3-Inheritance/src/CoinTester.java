import java.text.NumberFormat;
import java.util.Arrays;
import java.util.Random;


public class CoinTester {

	public static void main(String[] args) {
		int[] values = new int[]{1,5,10,25,50,100};
		int[] counts = new int[values.length];
		Arrays.fill(counts, 0);
		Random rand = new Random();
		MonetaryCoin[] myCoins = new MonetaryCoin[2000000];
		for(int i = 0; i < myCoins.length; i++)
		{
			myCoins[i] = new MonetaryCoin(
					values[rand.nextInt(values.length)]);
		}
		int sum = 0;
		int heads = 0;
		int tails = 0;
		for(int i = 0; i < myCoins.length; i++)
		{
			sum += myCoins[i].getValue();
			if(myCoins[i].isHeads())
				heads++;
			else
				tails++;
			switch(myCoins[i].getValue())
			{
			case 1:
				counts[0]++;
				break;
			case 5:
				counts[1]++;
				break;
			case 10:
				counts[2]++;
				break;
			case 25:
				counts[3]++;
				break;
			case 50:
				counts[4]++;
				break;
			case 100:
				counts[5]++;
				break;
			}
		}
		System.out.println("I have " + myCoins.length + " coins.");
		System.out.println("When I dropped them, " + heads + 
				" landed heads up and " + tails + " landed tails up");
		
		NumberFormat currency = NumberFormat.getCurrencyInstance();
		
		System.out.println("The total value of my coins is " + 
				currency.format(sum/100.0));
		for(int i = 0; i < counts.length; i++)
		{
			System.out.println("I have " + counts[i] + 
					" coins of value " + values[i]);
		}
	}

}
