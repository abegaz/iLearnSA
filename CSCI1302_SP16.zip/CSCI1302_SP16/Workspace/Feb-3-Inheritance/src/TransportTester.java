
public class TransportTester {

	public static void main(String[] args) {
		Car myCar = new Car(5, 4);
		System.out.println(myCar.toString());
		System.out.println(myCar.getPassengers());

	}

}
