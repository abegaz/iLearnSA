
public class Node {

	public int info;
	public Node north, south, east, west;
	
	public Node(int i){
		info = i;
		north = null;
		south = null;
		east = null;
		west = null;
	}
}
