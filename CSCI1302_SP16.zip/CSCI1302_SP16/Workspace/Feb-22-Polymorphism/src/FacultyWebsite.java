
public class FacultyWebsite extends Website implements Content {
	/*
	 * faculty
	 */
	private Faculty faculty;

	public FacultyWebsite(String path, Faculty faculty) {
		super("http", "faculty", "ung", "edu", path);
		this.faculty = faculty;
	}

	public Faculty getFaculty() {
		return faculty;
	}

	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}

	@Override
	public String toString() {
		return "FacultyWebsite [faculty=" + faculty + ", getURL()=" + getURL()
				+ "]";
	}

	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return "Faculty Website: "+super.getURL();
	}

	@Override
	public String displayContent() {
		// TODO Auto-generated method stub
		String temp = "";
		temp += "Faculty Website: " + faculty.getName() + "\n";
		temp += "Courses: " + faculty.getCoursesTaught();
		return temp;
	}
	
}
