
public class WebsiteDriver {

	public static void main(String[] args) {
		Faculty jet = new Faculty("JET", "CSCI1301", "CSCI1302", "CSCI3000");
		Faculty mullins = new Faculty("Sean Mullins", "CSCI1301", "CSCI1302", "CSCI2150");
		Website[] websites = new Website[4];
		websites[0] = new Website("http", "www", "ung", "edu", "");
		websites[1] = new DepartmentWebsite("IT", "Information Technology", jet, mullins);
		websites[2] = new FacultyWebsite("jet", jet);
		websites[3] = new FacultyWebsite("smullins", mullins);
		
		System.out.println("INHERITANCE POLYMORPHISM");
		
		for(Website w : websites)
			System.out.println(w.getURL());
		
		System.out.println("\n\nINTERFACE POLYMORPHISM");
		
		Content[] websites2 = new Content[3];
		websites2[0] = (DepartmentWebsite)websites[1];
		websites2[1] = (FacultyWebsite)websites[2];
		websites2[2] = (FacultyWebsite)websites[3];
		
		for(Content c : websites2)
			System.out.println(c.displayContent());
	}

}
