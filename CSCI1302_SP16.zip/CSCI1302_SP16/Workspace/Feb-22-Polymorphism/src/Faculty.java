import java.util.ArrayList;


public class Faculty {
	/*
	 * name, courses taught
	 */
	private String name;
	private ArrayList<String> coursesTaught;
	public Faculty(String name, String ... courses) {
		this.name = name;
		coursesTaught = new ArrayList<String>();
		for(String c : courses)
			coursesTaught.add(c);
	}
	public Faculty(String name, ArrayList<String> courses) {
		this.name = name;
		coursesTaught = courses;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public ArrayList<String> getCoursesTaught() {
		return coursesTaught;
	}
	public void setCoursesTaught(ArrayList<String> coursesTaught) {
		this.coursesTaught = coursesTaught;
	}
	public void addCoursesTaught(ArrayList<String> coursesTaught) {
		for(String c : coursesTaught)
			this.coursesTaught.add(c);
	}
	public void addCourseTaught(String c)
	{
		coursesTaught.add(c);
	}
	@Override
	public String toString() {
		return "Faculty [name=" + name + ", coursesTaught=" + coursesTaught
				+ "]";
	}
	
	
	
	
	
}
