
public class Website {
	/*
	 * protocol, sub domain, domain, top level domain, path
	 */
	private String protocol, subDomain, domain, topLevelDomain, path;
	
	public Website(String protocol, String subDomain, String domain,
			String topLevelDomain, String path) {
		this.protocol = protocol;
		this.subDomain = subDomain;
		this.domain = domain;
		this.topLevelDomain = topLevelDomain;
		this.path = path;
	}

	public String getProtocol() {
		return protocol;
	}

	public void setProtocol(String protocol) {
		this.protocol = protocol;
	}

	public String getSubDomain() {
		return subDomain;
	}

	public void setSubDomain(String subDomain) {
		this.subDomain = subDomain;
	}

	public String getDomain() {
		return domain;
	}

	public void setDomain(String domain) {
		this.domain = domain;
	}

	public String getTopLevelDomain() {
		return topLevelDomain;
	}

	public void setTopLevelDomain(String topLevelDomain) {
		this.topLevelDomain = topLevelDomain;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	@Override
	public String toString() {
		return "Website [getURL()=" + getURL() + "]";
	}

	/*
	 * getURL
	 */
	public String getURL()
	{
		//http://faculty.ung.edu/jet/
		//protocol://subDomain.domain.topLevelDomain/path
		return protocol+"://"+subDomain+"."+domain+"."+topLevelDomain+"/"+path;
	}
}
