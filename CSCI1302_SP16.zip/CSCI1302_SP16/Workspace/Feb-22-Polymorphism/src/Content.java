
public interface Content {
	/*
	 * display content
	 */
	public String displayContent();
}
