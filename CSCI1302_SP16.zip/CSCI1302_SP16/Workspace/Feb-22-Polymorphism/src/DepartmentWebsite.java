import java.util.ArrayList;


public class DepartmentWebsite extends Website implements Content {
	/*
	 * department name, faculty list (arraylist of faculty objects)
	 */
	private String departmentName;
	private ArrayList<Faculty> facultyList;
	public DepartmentWebsite(String path, String departmentName,
			ArrayList<Faculty> facultyList) {
		super("http", "www", "ung", "edu", path);
		this.departmentName = departmentName;
		this.facultyList = facultyList;
	}
	public DepartmentWebsite(String path, String departmentName,
			Faculty ... faculty) {
		super("http", "www", "ung", "edu", path);
		this.departmentName = departmentName;
		facultyList = new ArrayList<Faculty>();
		for(Faculty f : faculty)
			facultyList.add(f);
	}
	public String getDepartmentName() {
		return departmentName;
	}
	public void setDepartmentName(String departmentName) {
		this.departmentName = departmentName;
	}
	public ArrayList<Faculty> getFacultyList() {
		return facultyList;
	}
	public void setFacultyList(ArrayList<Faculty> facultyList) {
		this.facultyList = facultyList;
	}
	@Override
	public String toString() {
		return "DepartmentWebsite [departmentName=" + departmentName
				+ ", facultyList=" + facultyList + ", toString()="
				+ super.toString() + "]";
	}
	@Override
	public String getURL() {
		// TODO Auto-generated method stub
		return "Department Website: "+super.getURL();
	}
	@Override
	public String displayContent() {
		// TODO Auto-generated method stub
		String temp = "";
		temp += "Department Website: " + departmentName + "\n";
		for(Faculty f : facultyList)
			temp += "Faculty: " + f.getName();
		return temp;
	}
	
}
