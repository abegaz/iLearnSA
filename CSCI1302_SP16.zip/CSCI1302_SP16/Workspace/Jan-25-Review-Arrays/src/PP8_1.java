import java.util.Arrays;
import java.util.Scanner;

/*
 * Programming Project 8.1 (Page 435)
 * 	Write a program that reads an arbitrary number of integers that are in the
 * 		range 0 to 50 inclusive and counts how many occurrences of each are
 * 		entered. Indicate the end of the input by a value outside of the range.
 * 		After all input has been processed, print all of the values (with the
 * 		number of occurrences) that were entered one or more times.
 */
public class PP8_1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] counts = new int[51];
		Arrays.fill(counts, 0);
		System.out.println("Enter numbers between 0 and 50, inclusive");
		int num = scan.nextInt();//read number from user
		while(num >= 0 && num <= 50)
		{
			counts[num]++;
			num = scan.nextInt();//read another number from user
		}
		for(int i = 0; i < counts.length; i++)
		{
			if(counts[i] > 0)
				System.out.println(i + " : " + counts[i]);
		}
		
	}

}
