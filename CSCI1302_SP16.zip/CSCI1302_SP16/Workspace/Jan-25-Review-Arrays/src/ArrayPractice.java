
public class ArrayPractice {

	public static void main(String[] args) {
		int[] scores = new int[10];
		/*
		scores[0] = 0;
		scores[1] = 1;
		scores[2] = 2;
		scores[3] = 3;
		scores[4] = 4;
		scores[5] = 5;
		scores[6] = 6;
		scores[7] = 7;
		scores[8] = 8;
		scores[9] = 9;
		*/
		for(int i = 0; i < scores.length; i++)
		{
			scores[i] = i;
		}
		//reverse order
		System.out.println("Reverse");
		for(int i = scores.length-1; i >= 0; i--)
		{
			System.out.println(scores[i]);
		}
		System.out.println("For-Each");
		for(int score : scores)
		{
			System.out.println(score);
		}
		//System.out.println(scores[15]);//index out of bounds
		System.out.println("Array Size:" + scores.length);
		int[] scores2 = {1,2,3,4,5};
		for(int score : scores2)
		{
			System.out.println(score);
		}
		
		Coin[] coins = new Coin[10000];
		for(int i = 0; i < coins.length; i++)
			coins[i] = new Coin();
		
		int heads = 0, tails = 0;
		for(int i = 0; i < coins.length; i++)
		{
			if(coins[i].isHeads())
				heads++;
			else
				tails++;
		}
		System.out.println("Heads: " + heads + "   Tails: " + tails);
		
	}

}
