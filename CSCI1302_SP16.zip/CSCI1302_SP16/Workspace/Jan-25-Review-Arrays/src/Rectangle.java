
public class Rectangle {
	private int width, height;

	public Rectangle(int width, int height) {
		super();
		this.width = width;
		this.height = height;
	}

	public Rectangle(int width) {
		super();
		this.width = width;
		this.height = width;
	}

	public int getWidth() {
		return width;
	}

	public void setWidth(int width) {
		this.width = width;
	}

	public int getHeight() {
		return height;
	}

	public void setHeight(int height) {
		if(height > 0)
			this.height = height;
	}
	
	public int getArea()
	{
		return height*width;
	}
	public int getPerimeter()
	{
		return height+height+width+width;
	}
	public double getDiagonal()
	{
		//sqrt(w^2+l^2)
		double temp = Math.pow(width, 2);//temp = w^2
		temp += Math.pow(height, 2);//temp = temp + height^2
		return Math.sqrt(temp);
	}
	
}
