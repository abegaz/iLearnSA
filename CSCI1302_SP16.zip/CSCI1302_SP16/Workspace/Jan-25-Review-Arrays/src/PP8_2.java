import java.util.Arrays;
import java.util.Scanner;

/*
 * Programming Project 8.2 (Page 435)
 * 	Modify the program from PP 8.1 so that it works for numbers in the range
 * 		-25 to 25.
 */
public class PP8_2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int[] counts = new int[51];
		Arrays.fill(counts, 0);
		System.out.println("Enter numbers between -25 and 25, inclusive");
		int num = scan.nextInt();//read number from user
		while(num >= -25 && num <= 25)
		{
			counts[num+25]++;
			num = scan.nextInt();//read another number from user
		}
		for(int i = 0; i < counts.length; i++)
		{
			if(counts[i] > 0)
				System.out.println((i-25) + " : " + counts[i]);
		}
	}

}
