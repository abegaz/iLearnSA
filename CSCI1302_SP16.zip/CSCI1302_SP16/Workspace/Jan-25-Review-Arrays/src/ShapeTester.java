
public class ShapeTester {

	public static void main(String[] args) {
		Rectangle r1 = new Rectangle(3,4);
		Rectangle r2 = new Rectangle(5);
		Circle c1 = new Circle(3);
		Circle c2 = new Circle(5);
		
		System.out.println("Rectangle 1\nArea:" + r1.getArea() +
				"  Perimeter:" + r1.getPerimeter() +
				"  Diagonal:" + r1.getDiagonal());
		System.out.println("Rectangle 2\nArea:" + r2.getArea() +
				"  Perimeter:" + r2.getPerimeter() +
				"  Diagonal:" + r2.getDiagonal());
		
		r1.setWidth(5);
		r1.setHeight(5);
		
		System.out.println("Rectangle 1\nArea:" + r1.getArea() +
				"  Perimeter:" + r1.getPerimeter() +
				"  Diagonal:" + r1.getDiagonal());
		System.out.println("Rectangle 2\nArea:" + r2.getArea() +
				"  Perimeter:" + r2.getPerimeter() +
				"  Diagonal:" + r2.getDiagonal());
		
		System.out.println("Circle 1\nArea:" + c1.getArea() +
				"  Circumference:" + c1.getCircumference() +
				"  Diameter:" + c1.getDiameter() +
				"  Radius:" + c1.getRadius());
		System.out.println("Circle 2\nArea:" + c2.getArea() +
				"  Circumference:" + c2.getCircumference() +
				"  Diameter:" + c2.getDiameter() +
				"  Radius:" + c2.getRadius());
		
		c1.setDiameter(10);
		c2.setRadius(3);
		System.out.println("Circle 1\nArea:" + c1.getArea() +
				"  Circumference:" + c1.getCircumference() +
				"  Diameter:" + c1.getDiameter() +
				"  Radius:" + c1.getRadius());
		System.out.println("Circle2\nArea:" + c2.getArea() +
				"  Circumference:" + c2.getCircumference() +
				"  Diameter:" + c2.getDiameter() +
				"  Radius:" + c2.getRadius());
	}

}
