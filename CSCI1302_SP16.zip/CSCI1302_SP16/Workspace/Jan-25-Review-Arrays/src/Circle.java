
public class Circle {
	private double radius;

	public Circle(double radius) {
		super();
		this.radius = radius;
	}

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}
	public double getDiameter(){
		return radius*2;
	}
	public void setDiameter(double diameter){
		radius = diameter/2;
	}
	public double getArea(){
		return Math.PI * Math.pow(radius, 2);
	}
	public double getCircumference(){
		return 2 * Math.PI * radius;
	}
}
