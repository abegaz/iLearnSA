public class StudentList {
	private StudentNode list;
	
	public StudentList()
	{
		list = null;
	}
	public void add(Student s)
   {
      StudentNode node = new StudentNode(s);
      StudentNode current;

      if (list == null)
         list = node;
      else
      {
         current = list;
         while (current.next != null)
            current = current.next;
         current.next = node;
      }
   }
	public String toString()
   {
      String result = "";

      StudentNode current = list;

      while (current != null)
      {
         result += current.data + "\n";
         current = current.next;
      }

      return result;
   }
}
