
public class StudentNode {
	public Student data;
	public StudentNode next;
	public StudentNode(Student s)
	{
		data = s;
		next = null;
	}
}
