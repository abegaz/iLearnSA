
public class StudentTester {

	public static void main(String[] args) {
		StudentList sl = new StudentList();
		
		sl.add(new Student("JET"));
		sl.add(new Student("Bob"));
		sl.add(new Student("Billy"));
		sl.add(new Student("Ted"));
		sl.add(new Student("Fred"));
		
		System.out.println(sl);
	}

}
