
public abstract class Task implements Priority {
	private String name;
	private int priority;
	private int timeSpent;
	

	@Override
	public int compareTo(Priority arg0) {
		return ((Integer)priority).compareTo(arg0.getPriority());
	}

	@Override
	public String toString() {
		return "Task [name=" + name + ", priority=" + priority + ", timeSpent="
				+ timeSpent + "]";
	}

	public Task(String name, int priority, int timeSpent) {
		this.name = name;
		this.priority = priority;
		this.timeSpent = timeSpent;
	}

	public int getTimeSpent() {
		return timeSpent;
	}

	public void setTimeSpent(int timeSpent) {
		this.timeSpent = timeSpent;
	}

	@Override
	public int getPriority() {
		// TODO Auto-generated method stub
		return priority;
	}

	@Override
	public void setPriority(int v) {
		// TODO Auto-generated method stub
		priority = v;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
