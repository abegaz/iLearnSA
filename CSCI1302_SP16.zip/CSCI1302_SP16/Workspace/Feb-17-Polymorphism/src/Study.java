
public class Study extends Task {
	private String courseName;

	public Study(int priority, int timeSpent, String cn) {
		super("Study for " + cn, priority, timeSpent);
		courseName = cn;
		// TODO Auto-generated constructor stub
	}

	
}
