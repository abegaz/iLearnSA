
public interface Priority extends Comparable<Priority> {
	public int getPriority();
	public void setPriority(int v);
}
