
public class SpeakerTester {

	public static void main(String[] args) {
		Speaker[] people = new Speaker[3];
		people[0] = new Teacher();
		people[1] = new Philosopher();
		people[2] = new Dictator();
		
		for(Speaker s : people)
		{
			s.speak();
			s.announce("Test on Feb 29th");
		}
		((Dictator)people[2]).conquer();

	}

}
