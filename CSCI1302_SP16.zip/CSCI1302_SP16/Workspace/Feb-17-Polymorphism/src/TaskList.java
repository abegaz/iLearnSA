import java.util.Arrays;


public class TaskList {

	public static void main(String[] args) {
		Priority[] tasks = new Priority[3];
		tasks[0] = new Sleep(4);
		tasks[1] = new Study(1, 8, "CSCI1302");
		tasks[2] = new Study(10, 2, "ENGL1101");
		
		System.out.println(tasks[0].getPriority());
		System.out.println(tasks[1].getPriority());
		tasks[2].setPriority(25);
		System.out.println(tasks[2].getPriority());
		
		
		System.out.println(tasks[0].compareTo(tasks[1]));
		
		for(Priority p : tasks)
			System.out.println(p);
		Arrays.sort(tasks);
		System.out.println("\nSORTED\n");
		for(Priority p : tasks)
			System.out.println(p);
		
	}

}
