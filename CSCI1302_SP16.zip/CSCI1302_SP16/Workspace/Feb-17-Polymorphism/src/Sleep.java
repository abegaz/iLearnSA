
public class Sleep extends Task {

	public Sleep(int priority) {
		super("Sleep", priority, 6);
		// TODO Auto-generated constructor stub
	}

}
