
public class Teacher implements Speaker {

	@Override
	public void speak() {
		System.out.println("Do your homework!");
	}

	@Override
	public void announce(String str) {
		System.out.println("Reminder: " + str);
	}

}
