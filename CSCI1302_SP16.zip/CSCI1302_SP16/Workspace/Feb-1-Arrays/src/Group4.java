import java.util.Scanner;

/*
 * Team 2
 * Authors: Drake Packard, Daniel Hicks, Kaitlin Lucas, Caleb Arcega, 
 * Savannah Oaks, Parth Patel
 */

public class Group4 {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String test = "how now brown cow";
		test = test.toLowerCase();
		
		System.out.println("Please input a line:");
		String oldInput = scan.nextLine();
		String input = oldInput.toLowerCase();
		System.out.println("");
		
		int len = input.length();
		int array[][] = new int[128][2];
		
		for(int i=0;i<128;i++){
			array[i][0] = i;
			array[i][1] =0;
		}
		
		for(int i = 0; i<len; i++ ){
			for(int j=0;j<128;j++){
				if(input.charAt(i)==array[j][0]){
					array[j][1]++;
				}
			}
		}
		
		char current;
		
		double percentage;
		boolean superfreq = false;
		
		for(int place = 97; place<123;place++){
			current = (char)array[place][0];
			percentage = (((double)array[place][1])/input.length());
			if(percentage>.15){
				superfreq = true;
				System.out.println(Character.toUpperCase(current)+" is a super freq.");
			}
		}
		if(superfreq == false){
			System.out.println("There are no super freqs.");
		}
		scan.close();
	}
}
