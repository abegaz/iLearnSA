import java.util.Scanner;
public class QuizBonus {
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		String in = s.nextLine().toUpperCase();
		int[] let = new int[26];
		int temp = 0;
		for(int i = 0; i < in.length(); i++)
		{
			temp = (int)in.charAt(i);
			if(temp >= 65 && temp <= 90)
				let[temp-65]++;
		}
		int freq = (int)Math.ceil(in.length()*.15);
		boolean found = false;
		for(int i = 0; i < 26; i++)
		{
			if(let[i] >= freq)
			{
				System.out.println((char)(i+65) + " is a super freq.");
				found = true;
			}
		}
		if(!found)
			System.out.println("There are no super freqs.");
	}
}