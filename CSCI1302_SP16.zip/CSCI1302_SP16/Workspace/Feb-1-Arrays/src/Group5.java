
import java.util.Arrays;
import java.util.Scanner;

public class Group5 {

	public static void main (String []args)
	{
		System.out.println("Enter in a string.");
		Scanner scan = new Scanner (System.in);
		String s = scan.nextLine();
		s = s.toLowerCase();
		int length = s.length();
		s = s.replace(" ", "");
		char [] c1 = new char [s.length()];
		int [] c2 = new int [s.length()];
		
		
		for (int i = 0; i < s.length(); i++)
		{
			int count = 1;
			c1 [i] = s.charAt(0);
			for (int j = 1; j < s.length(); j++)
			{
				if (s.charAt(0)==s.charAt(j))
				{
					count++;
				}
			}
			c2 [i] =  count;
			s = s.replace(s.charAt(0)+"", "");
		}
		
		int max = c2[0];

		for (int k = 1; k < c2.length; k++) 
		{
		    if (c2[k] > max) 
		    {
		      max = c2[k];
		    }
		}	
			
		//System.out.println(max);
		//System.out.println(length);	
		double a = ((double)max/(double)length);	
		//System.out.println(a);	
		
		if (a>=0.15)
		{
			int location = Arrays.binarySearch(c2, max);
			System.out.println(c1[location]);
			System.out.println("is a super frequency.");
		}
		
		
	}
}