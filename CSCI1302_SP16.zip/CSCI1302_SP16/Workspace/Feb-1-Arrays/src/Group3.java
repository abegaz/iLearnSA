/*
 * 10% Bonus
 */
//>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<
//Jeff Thomson, Brandon Byers, Ty Smith, Richard Wilbanks, Tyler Moon
//
// Hope this was worth it..
//>>>>>>>>>>>>>>>>>>>>>>>>>>>><<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<

import java.util.*;

public class Group3
{
	public static void main (String[] args)
	{
		Scanner scan = new Scanner(System.in);
		String phrase;
		String line;
		String exit;
		
		int counter2 = 0;
		
		double superFreq = 0;
		double q = 0;
		double w = 0;
		double e = 0;
		double r = 0;
		double t = 0;
		double y = 0;
		double u = 0;
		double i = 0;
		double o = 0;
		double p = 0;
		double a = 0;
		double s = 0;
		double d = 0;
		double f = 0;
			double g = 0;
			double h = 0;
			double j = 0;
			double k = 0;
			double l = 0;
			double z = 0;
			double x = 0;
			double c = 0;
			double v = 0;
			double b = 0;
			double n = 0;
			double m = 0;
			
			int length;
			int space = 0;
			
			System.out.println();
			System.out.println("Enter a sentence:");
			phrase = scan.nextLine();
			
			length = phrase.length();
			
			System.out.println();
			System.out.println();
			System.out.println();
			
			for (int incriment = 0; incriment < length; incriment++)
			{
				
				line = phrase.substring(incriment, incriment + 1);
				
				//Letter Counting
				if (line.equalsIgnoreCase("q") == true)
				{
					q++;
				}
				
				else if (line.equalsIgnoreCase("w") == true)
				{
					w++;
				}
				
				else if (line.equalsIgnoreCase("e") == true)
				{
					e++;
				}
				
				else if (line.equalsIgnoreCase("r") == true)
				{
					r++;
				}
				
				else if (line.equalsIgnoreCase("t") == true)
				{
					t++;
				}
				
				else if (line.equalsIgnoreCase("y") == true)
				{
					y++;
				}
				
				else if (line.equalsIgnoreCase("u") == true)
				{
					u++;
				}
				
				else if (line.equalsIgnoreCase("i") == true)
				{
					i++;
				}
				
				else if (line.equalsIgnoreCase("o") == true)
				{
					o++;
				}
				
				else if (line.equalsIgnoreCase("p") == true)
				{
					p++;
				}
				
				else if (line.equalsIgnoreCase("a") == true)
				{
					a++;
				}
				
				else if (line.equalsIgnoreCase("s") == true)
				{
					s++;
				}
				
				else if (line.equalsIgnoreCase("d") == true)
				{
					d++;
				}
				
				else if (line.equalsIgnoreCase("f") == true)
				{
					f++;
				}
				
				else if (line.equalsIgnoreCase("g") == true)
				{
					g++;
				}
				
				else if (line.equalsIgnoreCase("h") == true)
				{
					h++;
				}
				
				else if (line.equalsIgnoreCase("j") == true)
				{
					j++;
				}
				
				else if (line.equalsIgnoreCase("k") == true)
				{
					k++;
				}
				
				else if (line.equalsIgnoreCase("l") == true)
				{
					l++;
				}
				
				else if (line.equalsIgnoreCase("z") == true)
				{
					z++;
				}
				
				else if (line.equalsIgnoreCase("x") == true)
				{
					x++;
				}
				
				else if (line.equalsIgnoreCase("c") == true)
				{
					v++;
				}
				
				else if (line.equalsIgnoreCase("b") == true)
				{
					b++;
				}
				
				else if (line.equalsIgnoreCase("n") == true)
				{
					n++;
				}
				
				else if (line.equalsIgnoreCase("m") == true)
				{
					m++;
				}
				superFreq = phrase.length()*0.15;
			}
				//PRINT OUTPUT
				System.out.println("Your input was: '" + phrase +"'");
				System.out.println("Total length of the phrase: " + phrase.length());
				System.out.println("Super Freq requirement: " + superFreq);
				System.out.println();
					
					//Letter Counting
					if (q >= superFreq)
					{
						System.out.println("Q is a Super Freq!");
						counter2++;
					}
					if (w >= superFreq)
					{
						System.out.println("W is a Super Freq!");
						counter2++;
					}
					if (e >= superFreq)
					{
						System.out.println("E is a Super Freq!");
						counter2++;
					}
					if (r >= superFreq)
					{
						System.out.println("R is a Super Freq!");
						counter2++;
					}
					if (t >= superFreq)
					{
						System.out.println("T is a Super Freq!");

						counter2++;
					}
					if (y >= superFreq)
					{
						System.out.println("Y is a Super Freq!");

						counter2++;
					}
					if (u >= superFreq)
					{
						System.out.println("U is a Super Freq!");

						counter2++;
					}
					if (i >= superFreq)
					{
						System.out.println("I is a Super Freq!");

						counter2++;
					}
					if (o >= superFreq)
					{
						System.out.println("O is a Super Freq!");
						counter2++;
					}
					if (p >= superFreq)
					{
						System.out.println("P is a Super Freq!");
						counter2++;
					}
					if (a >= superFreq)
					{
						System.out.println("A is a Super Freq!");
						counter2++;
					}
					if (s >= superFreq)
					{
						System.out.println("S is a Super Freq!");
						counter2++;
					}
					if (d >= superFreq)
					{
						System.out.println("D is a Super Freq!");
						counter2++;
					}
					if (f >= superFreq)
					{
						System.out.println("F is a Super Freq!");
						counter2++;
					}
					if (g >= superFreq)
					{
						System.out.println("G is a Super Freq!");
						counter2++;
					}
					if (h >= superFreq)
					{
						System.out.println("H is a Super Freq!");
						counter2++;
					}
					if (j >= superFreq)
					{
						System.out.println("J is a Super Freq!");
						counter2++;
					}
					if (k >= superFreq)
					{
						System.out.println("K is a Super Freq!");
						counter2++;
					}
					if (l >= superFreq)
					{
						System.out.println("L is a Super Freq!");
						counter2++;
					}
					if (z >= superFreq)
					{
						System.out.println("Z is a Super Freq!");
						counter2++;
					}
					if (x >= superFreq)
					{
						System.out.println("X is a Super Freq!");
						counter2++;
					}
					if (c >= superFreq)
					{
						System.out.println("C is a Super Freq!");
						counter2++;
					}
					if (v >= superFreq)
					{
						System.out.println("V is a Super Freq!");
						counter2++;
					}
					if (b >= superFreq)
					{
						System.out.println("B is a Super Freq!");
						counter2++;
					}
					if (n >= superFreq)
					{
						System.out.println("N is a Super Freq!");
						counter2++;
					}
					if (m >= superFreq)
					{
						System.out.println("M is a Super Freq!");
						counter2++;
					}
					else if (counter2 <= 0)
					{
						System.out.println("There are no SuperFreqs!");
					}
				}	
			}