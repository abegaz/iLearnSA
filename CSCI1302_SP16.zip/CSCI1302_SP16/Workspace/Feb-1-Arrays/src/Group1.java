/*
 * 7% Bonus
 */
//team superFreq

//Rachel Henderson
//Anna Blasingame
//Ryan Heckman
//Joseph Seawright
//Christian Watts


import java.util.Scanner;

public class Group1

{

	public static void main(String[] args) 
	
	{
		String phrase; 
		int phraseL = 0;
		int intPhraseChar = 0;
		int phraseL2 = 0;
		String phrase2;
		Scanner scan = new Scanner (System.in);
		char character;
		boolean freq = false;
		
		
		System.out.println("Please enter a phrase");
		phrase2 = scan.nextLine();//convert to lower
		phraseL = phrase2.length();//phrase length
		
		phrase = phrase2.toLowerCase();
		
		phrase = phrase.replaceAll (" ", "");
		phraseL2 = phrase.length();//phrase length
		
		//phrase = phrase.replaceAll (" \"", "");
		//phrase = phrase.replaceAll (" \'", "");
		
		
		
		int [] superFreq = new int [26];
		
		//System.out.println (phrase); 
		
		for (int i = 0; i < phraseL2; i++)
		{
			//intPhraseChar = 0;
			
			//phrase.charAt(i);
			
			intPhraseChar = (int)phrase.charAt(i);
			intPhraseChar = intPhraseChar - 97;
			
			for (int j = 0; j < 26; j++ )
			{
				if (intPhraseChar >= 0 && intPhraseChar < 26)
				{
					//System.out.println ("Index" +  i + "Char At" + phrase.charAt(i) + "Phrase number" + intPhraseChar);
					if ((intPhraseChar)  == (j))
					{
						superFreq [j] ++;
					}
				}
			}
		}//end for
		
		
		//COunts 
		///for (int i = 0; i < 26; i++)
		//{
		//	System.out.println (superFreq [i]);
		//}
		
		System.out.println (phrase2);
		//System.out.println("Super Frequents");
		for (int i = 0; i < 26; i++)
		{
			if ((double)superFreq[i]/(double)phraseL > .15)
			{
				freq = true;
				character = (char)(97 + i);
				System.out.println ((char)(97 + i)+ " is a super freq");
				 
				//System.out.println ((char)superFreq [i]);
			}
			
		}
		
		if (freq == false)
		{
			System.out.println ("There are no super freqs.");
			
		}
		
		

	}

}
