import java.util.Scanner;

/*Chris Patrick
 * Brittany Clarke
 * Siliang liu
 * Matthew Freeman
 */
public class Group2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int NUMCHARS = 26;
		
		Scanner input = new Scanner(System.in);
		
		int[] upper = new int[NUMCHARS];
		char current;
		int other = 0;
		int nonFreq = 0;
		System.out.println("Enter a sentence");
		
		String line = input.nextLine();
		for (int ch = 0; ch < line.length(); ch++){
			current = line.toUpperCase().charAt(ch);
			if (current >= 'A' && current <= 'Z'){
				upper[current-'A']++;
			}
			else
				other++;
		}
		
		for (int letter = 0; letter< upper.length; letter++){
			if (upper[letter] >= (double)(0.15*line.length())){
				System.out.println(((char)(letter + 'A') + " is a super freq."));
			}
			else if (upper[letter] <(double)(0.15*line.length())){
				nonFreq++;
			}
		}
		if (nonFreq == 26){
			System.out.println("There are no super frequent letters.");
		}
	}
}


