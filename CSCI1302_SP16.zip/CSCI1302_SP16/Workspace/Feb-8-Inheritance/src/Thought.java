//********************************************************************
//  Thought.java       Author: Lewis/Loftus
//
//  Represents a stray thought. Used as the parent of a derived
//  class to demonstrate the use of an overridden method.
//********************************************************************

public class Thought
{
   //-----------------------------------------------------------------
   //  Prints a message.
   //-----------------------------------------------------------------
   public void message()
   {
      System.out.println("I feel like I'm diagonally parked in a " +
                         "parallel universe.");

      System.out.println();
   }
   public final void message2()
   {
      System.out.println("Second Message");

      System.out.println();
   }
   public void count(int a, double b)
   {
	   
   }
   public void count(double a, int b)
   {
	   
   }
   /*
    * Data types of variables must be different in overloaded methods
   public void count(double c, int d)
   {
	   
   }
   */
   public void count(int a, int b, int c)
   {
	   
   }
}
