
public abstract class Department {

	public Department() {
		// TODO Auto-generated constructor stub
	}

}
