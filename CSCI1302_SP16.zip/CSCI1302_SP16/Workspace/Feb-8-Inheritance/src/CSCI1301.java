
public class CSCI1301 extends Course {

	public CSCI1301() {
		super(1301, "Computer Science", "Programming I", "Intro to programming 1 with Java");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void printCourse() {
		// TODO Auto-generated method stub
		
	}

}
