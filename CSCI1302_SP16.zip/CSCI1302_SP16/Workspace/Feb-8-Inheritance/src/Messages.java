//********************************************************************
//  Messages.java       Author: Lewis/Loftus
//
//  Demonstrates the use of an overridden method.
//********************************************************************

public class Messages
{
   //-----------------------------------------------------------------
   //  Creates two objects and invokes the message method in each.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
      Thought parked = new Thought();
      Advice dates = new Advice();

      System.out.println("Parked:");
      parked.message();
      System.out.println("Dates:");
      dates.message();  // overridden
      System.out.println("Message 2:");
      parked.message2();
      dates.message2();
      
      /*
      Integer.parseInt("42");
      Integer.parseInt("101010", 2);
      Integer.parseInt("AFDE", 16);
      */
   }
}
