
public class ComputerScience extends Department {

	public ComputerScience() {
		// TODO Auto-generated constructor stub
	}

}
