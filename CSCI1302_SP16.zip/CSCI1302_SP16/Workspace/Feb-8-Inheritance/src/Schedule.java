
public class Schedule {

	public static void main(String[] args) {
		CSCI1302 c1 = new CSCI1302(new Course[]{new CSCI1301()});
		
		System.out.println(c1);
		//Course c2 = new Course(); Can't create object of abstract class
	}

}
