import java.util.Arrays;


public class CSCI1302 extends Course {
	private Course[] prereqs;

	public Course[] getPrereqs() {
		return prereqs;
	}

	public void setPrereqs(Course[] prereqs) {
		this.prereqs = prereqs;
	}

	public CSCI1302() {
		super(1302, "Computer Science", "Programming II", "Intro to programming 2 using Java");
		this.prereqs = new Course[1];
		this.prereqs[0] = new CSCI1301();
		// TODO Auto-generated constructor stub
	}

	public CSCI1302(Course[] prereqs) {
		super(1302, "Computer Science", "Programming II", "Intro to programming 2 using Java");
		this.prereqs = prereqs;
	}

	@Override
	public String toString() {
		return "CSCI1302\n\tprereqs=" + Arrays.toString(prereqs)
				+ "\n\t" + super.toString();
	}

	@Override
	public void printCourse() {
		// TODO Auto-generated method stub
		
	}
	
}
