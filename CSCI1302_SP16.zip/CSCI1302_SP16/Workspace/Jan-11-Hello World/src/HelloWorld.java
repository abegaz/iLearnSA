import java.util.Scanner;


public class HelloWorld {

	public static void main(String[] args) {
		System.out.println("Hello World!");
		Scanner s = new Scanner(System.in);
		System.out.print("Enter a string:");
		String text = s.nextLine();
		System.out.println("Text entered: " + text);
	}

}
