import java.util.Scanner;


public class Blurb {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a blurb:");
		String blurb = scan.next().toLowerCase();
		if(isBlurb(blurb))
			System.out.println("That is a blurb!");
		else
			System.out.println("That is not a blurb.");
	}
	/*
	 * Blurb = Whoozit,[Whatzit,Whoozit],[Whatzit,Whoozit],...,[Whatzit,Whoozit]
	 * Blurb = Whoozit,Whatzit+
	 * Whoozit = x[yyyy...]
	 * Whatzit = qz|qd,Whoozit
	 * Must begin/end with Whoozit
	 * Shortest: Whoozit,Whatzit,Whoozit
	 * Shortest: xqzx, xqdx
	 * 12.8 on Page 614
	 */
	public static boolean isBlurb(String s)
	{
		//remove Whoozit
		s = removeWhoozit(s);
		//remove 1+ Whatzit
		do{
			s = removeWhatzit(s);
		}while(s.length() > 2);
		//return true/false
		if(s.equals(""))
			return true;
		return false;
	}
	public static String removeWhoozit(String s)
	{
		//System.out.println(s);
		//remove x
		if(s.length() > 0 && s.charAt(0) == 'x')
		{
			s = s.substring(1);
			//remove all y's
			while(s.length() > 0 && s.charAt(0) == 'y')
			{
				s = s.substring(1);
			}
			//return what is left of string
			return s;
		}
		return "F";
	}
	public static String removeWhatzit(String s)
	{
		//System.out.println(s);
		//remove q
		if(s.length() > 2 && s.charAt(0) == 'q')
		{
			s = s.substring(1);
			//remove d or z
			if(s.length() > 1 && s.charAt(0) == 'd' || s.charAt(0) == 'z')
			{
				s = s.substring(1);
				//remove Whoozit
				s = removeWhoozit(s);
				//return what is left of string
				return s;
			}
		}
		return "F";
	}

}
