
public class EvenOrOdd {

	public static void main(String[] args) {
		for(int n = 0; n <= 10; n++)
		{
			System.out.println("isEven("+n+") : " + isEven(n));
		}
	}
	public static boolean isEven(int n)
	{
		if(n==0)
			return true;
		else
			return !isOdd(n-1);
	}
	public static boolean isOdd(int n)
	{
		if(n==0)
			return true;
		else
			return !isEven(n-1);
	}
}
