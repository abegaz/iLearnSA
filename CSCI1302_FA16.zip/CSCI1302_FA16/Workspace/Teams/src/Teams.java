import java.util.*;
public class Teams
{
	private static final int TEAMSIZE = 3;
	public static void main(String[] args)
	{
		ArrayList<String> members = new ArrayList<String>();//list of members
		members.add("Kyra Bessey");
		//members.add("Ethan David");
		members.add("Tristan Derloshon");
		members.add("Nolan Flynn");
		members.add("Madeleine Godwin");
		members.add("Michael Keeton");
		//members.add("Dwight Larkins");
		members.add("Chase Lawson");
		members.add("Kevin Lin");
		members.add("Jacob Malimban");
		//members.add("Brian Manzo");
		members.add("Chadd Monahan");
		members.add("Evan Myers");
		members.add("Bradford Regeski");
		members.add("Michael Simica");
		//members.add("Jeffrey Thomson");
		//members.add("Jon Waters");
		members.add("Emily Weeks");
		//members.add("Kyle Wilson");

		//System.out.println(members);
		Collections.shuffle(members);//shuffle members
		//System.out.println(members);
		//int teamSize = (int)Math.round(members.size() / NUMBEROFTEAMS);//decide average team size
		//System.out.println(teamSize);

		int largeTeams = members.size() % TEAMSIZE;
		int count = 0;
		int teamNumber = 1;
		for(String m : members)
		{
			if(largeTeams >= teamNumber-1 && count % (TEAMSIZE+1) == 0)
			{
				System.out.println("\nTeam " + (teamNumber++));
			}
			else if(largeTeams < teamNumber-1 && (count - (largeTeams*(TEAMSIZE+1)))%TEAMSIZE == 0)//divide into teams based on team size and max # of teams
				System.out.println("\nTeam " + (teamNumber++));
			System.out.println(m);//print team member
			count++;
		}
		System.out.println();

		/*
		int smallTeams = TEAMSIZE - members.size() % TEAMSIZE;
		if(smallTeams == TEAMSIZE)
			smallTeams = 0;
		//System.out.println(members.size() + " : " + TEAMSIZE + " : " + smallTeams);
		int count = 0;
		int teamNumber = 1;
		for(String m : members)
		{
			//System.out.println(smallTeams + " : " + teamNumber + " : " + count);
			if(smallTeams >= teamNumber && count % (TEAMSIZE-1) == 0)
			{
				System.out.println("\nTeam " + (teamNumber++));
			}
			else if(smallTeams < teamNumber && (count - (smallTeams*(TEAMSIZE-1)))%TEAMSIZE == 0)//divide into teams based on team size and max # of teams
				System.out.println("\nTeam " + (teamNumber++));
			System.out.println(m);//print team member
			count++;
		}
		System.out.println();
		*/
	}
}