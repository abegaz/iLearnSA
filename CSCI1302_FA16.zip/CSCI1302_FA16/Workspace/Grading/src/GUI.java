/*
 * Created by Michael Simica
 * CSCI 1302
 * Bonus Project
 * Due: 12/9/2016
 * Title: GUI
 * Description: This class creates a GUI environment and it
 * serves as the driver class as well. I created an array in this class
 * as well.
 */
 import java.util.Scanner;
 import javax.swing.*;
 public class GUI
 {

	 public static void main(String[] args)
	 {

		 // reads the user's name into the GUI
		 String name= JOptionPane.showInputDialog(null,
				 "What is your name?");

		 // prompts user to answer a yes or no question.
		 int choice = JOptionPane.showConfirmDialog(null,
				name + ", "+  "Did Walt Disney serve in World War 1? " + "What about Ernest Hemingway?");

		 // if the user enters yes a message is displayed
		 if (choice == JOptionPane.YES_OPTION)
		 {
			 JOptionPane.showMessageDialog(null,
			 "Correct!! Ernest Hemingway did as well!");
		 }
		 else
		 	{ // if the user enters no or cancels another message is displayed.
			 JOptionPane.showMessageDialog(null,
			"They both served as ambulance drivers during the war.");
		 	}

		    //prompts user to enter number of people
			Scanner scan = new Scanner(System.in);
			System.out.print( name + ", " + "enter how many favorite colors you have: ");
			int count = scan.nextInt();


			//String array that prompts for user to enter name
			String[] array = new String[count];


	        for (int i = 0; i < array.length; i++)
	        {
	    	 System.out.println("Enter Favorite Color: ");
	    	 array[i] = scan.next();
	        }
	        //Prints out entered names and orders them
	        System.out.println("The colors you entered: ");
	        for(String color : array)
	        	System.out.println(color + " has " +  color.length() + " letters in it.");
	        // System.out.println(" Has a length of " + array.length);

	        Color shade = null;
			/*try/catch block allows us to input different numbers to test out our exceptions
	        statement. 3 possible statements may be printed. */
			try
			{
				shade = new Color ("Input number of colors in color spectrum >>", 7);
			}

			catch(ColorSpectrum e)
			{
				System.out.println(e.getMessage());
			}

	 }
 }