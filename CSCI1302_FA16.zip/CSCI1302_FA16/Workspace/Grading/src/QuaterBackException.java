//Chase Lawson
//CSCI 1302
//Project 2
//December 5, 2016
//QuaterBackException.java
//Custom Exception Class 
public class QuaterBackException extends Exception{

	
		
		//Creates the Custom Exception Class
			public QuaterBackException(){ }
			
			public QuaterBackException(String message){
				super(message);
			}
			
		
	}
	

