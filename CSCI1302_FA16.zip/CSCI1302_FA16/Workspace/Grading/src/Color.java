/*
 * Created by Michael Simica
 * CSCI 1302
 * Bonus Project
 * Due: 12/9/2016
 * Title: Color
 * Description: The color class includes the data necessary to
 * execute the exceptions statement.
 */
class Color
{
//Instance Data
	private String name;
	private int number;


	/* I implemented an if else if series of statements here to
	 * produce different results depending on the number the user enters
	 * in the try statement in the main driver class. There are 3 possible
	 * statements that may be produced from this.
	 */
	  public Color(String name, int number) throws ColorSpectrum
	{
		//if number is less than 7, this statement is printed.
		if (number < 7)
		{
			throw new ColorSpectrum("Close, guess a little larger! " + number);
		}
		//if number is greater than 7, this statement is printed.
		else if (number > 7)
		{
			this.name = name;
			this.number = number;
			System.out.println("Too high, guess lower! ");
		}
		//if number is equal to 7, this statement is printed.
		else if (number == 7)
		{
			System.out.println("Spot on!");
		}

	}
}
