//Chase Lawson
//CSCI 1302
//Project 2
//December 5, 2016
//QuaterbackList.java
//Methods to add, delete, and insert nodes into the linked list. 
public class QuaterbackList {
	
	private QuaterBacksNode start;
	private QuaterBacksNode end;
	private int count;
	public QuaterbackList(){
		this.start = null;
		this.end = null;
		this.count = 0;
	}
	//Add method that allows you to add object
	public void add(QuaterBacks qb){
		
		QuaterBacksNode newName = new QuaterBacksNode(qb);
		QuaterBacksNode current;
		//Signals the beginnig of the list
		if(start==null){
			
			start = newName;
			end = newName;
			
		}
		//Signals that there have already been nodes added and that you must add to the next
		else {
			
			current = start;
			
			while(current.next !=null)
				current = current.next;
			current.next = newName;
			
		}
		count++;
	}
	//This will allow you to insert into your desired position in the list. 
	public void insert(QuaterBacks qb, int pos) throws QuaterBackException{
		
		QuaterBacksNode newName = new QuaterBacksNode(qb);
		QuaterBacksNode current = start;
		int currpos = 1;
		//If no object in the list then it will make name inserted the start and end of list.
		if(start == null){
			
			start = newName;
			end = newName;
	
		}
		else if (pos == 0){
			newName.setNext(start);
			start = newName;
			
			
		}
		else{
			//Custom exception class to catch Null Pointer Exception if object is placed in a part of the list that has not been reached yet
			try{
			
			for( int j = 1; j< pos; j++){
				current = current.getNext();
			}
			newName.setNext(current.getNext());
			current.setNext(newName);
		
			count++;
		}
		catch(NullPointerException e){
			System.out.println("You attemepted to insert a Quaterback in a place that is yet to exist. Try positioning it right after the last position.");
			throw new QuaterBackException(); 
		}
		}
		
		}
	//Method allows you to delete a object out of the list
	public void delete(int pos){
		
		QuaterBacksNode current, remove;
		int curPos= 1;
		// If you delete the only object then the list will equal null
		if(start == null){
			
		}
		else if(pos == 0){
			
			start = start.getNext();
			if(start.getNext()==null)
			end = start;
			count--;
				
		}
		remove = start.next;
		for (int i=1; remove!=null&&i<pos; i++)
			remove = remove.next;
		if(remove == null || remove.next == null)
			return;
		
		QuaterBacksNode next = remove.next.next;
		remove.next = next;
	}
	//Tells you if the list is empty or not
	public boolean empty(){
		return (count == 0) ? true : false;
	}
	//Creates the toString Method 
	public String toString(){
		String result = "";
		
		QuaterBacksNode current = start;
		
		while(current != null){
			result += current.getQb() + "\n";
			current = current.getNext();
		}
		return result;
	}
	//Recursive method to help with writing into file
	public String recursive(int pos){
		if(pos < 0)
			return "";
		QuaterBacksNode current = start;
		for(int i = 0; i<pos; i++){
			current = current.next;
		}
		if(current != null)
		{
			return current + "\n" + recursive(pos-1);
			
		}
		return "";
		
		
		
			
	}
}
