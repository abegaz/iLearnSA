 /*
 * Created by Michael Simica
 * CSCI 1302
 * Bonus Project
 * Due: 12/9/2016
 * Title: GUI
 * Description: Sets up the exception to be passed into the
 * driver class. Allows us to create a custom exception.
 */
public class ColorSpectrum extends Exception
{
	//Constructor
	public ColorSpectrum(String message)
	{
		super(message);
	}

}