//Chase Lawson
//CSCI 1302
//Project 2
//December 5, 2016
//QuaterBacks.java
//This will set-up the quaterback class to get a name
public class QuaterBacks {
		String name; 
		
		//Sets up Name
		public QuaterBacks(String name){
			super();
			this.name = name; 
		}

		public String getName(){
			return name;
		}
		
		public void setName(String name){
			this.name = name;
		}
		public String toString(){
			
			return name;
		}
		
		
}
