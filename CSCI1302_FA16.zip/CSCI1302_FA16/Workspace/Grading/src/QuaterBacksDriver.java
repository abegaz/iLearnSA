//Chase Lawson
//CSCI 1302
//Project 2
//December 5, 2016
//QuaterBacksDriver.java
//This is the driver class


import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class QuaterBacksDriver {

	public static void main(String[] args)throws FileNotFoundException{
		QuaterbackList list = new QuaterbackList();
		
		PrintWriter pw = new PrintWriter("qb.txt");
		
		
		//Adds to double linked list
		list.add(new QuaterBacks("Tom Brady"));
		list.add(new QuaterBacks("Matt Ryan"));
		list.add(new QuaterBacks("Andrew Luck"));
		list.add(new QuaterBacks("Brock Osweller"));
		list.add(new QuaterBacks("Kirk Cousins"));
		
		//Prints out added list
		System.out.println(list);
		//Deletes out of the double linked list
		list.delete(2);
		//Prints out the list with the deleted node
		System.out.println("Deleted List"+"\n"+list);
		//Catches the Custom Exception
		try{
		list.insert(new QuaterBacks("Aaron Rodgers"), 1);
		}
		catch(QuaterBackException e){
			e.printStackTrace();
		}
		//Prints out the insert into the double linked list
		System.out.println("Insert List: \n"+list);
		
		//Allows to print into a File
		pw.println(list.recursive(4));
		
		pw.close();
	
		
		
		
		
		
	}

	
}
