//Chase Lawson
//CSCI 1302
//Project 2
//December 5, 2016
//QuaterBacksNode.java
//Sets up the node object

public class QuaterBacksNode{
	
	private QuaterBacks qb;
	public QuaterBacksNode next;
	
	//Sets up node
	public QuaterBacksNode(QuaterBacks qb){
		this.qb = qb;
		this.next = null;
	}
	public QuaterBacks getQb(){
		return qb;
	}
	public void setQb(QuaterBacks qb){
		
		this.qb = qb;
		
	}
	//go to the next object
	public QuaterBacksNode getNext(){
		return next;
	}
	public void setNext(QuaterBacksNode next){
		this.next = next;
	}
	public String toString(){
		
		return qb.toString();
		
	}
}