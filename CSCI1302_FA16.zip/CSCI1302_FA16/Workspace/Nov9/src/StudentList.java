
public class StudentList {
	private StudentNode start;
	private StudentNode end;
	private int count;
	public StudentList() {
		this.start = null;
		this.end = null;
		this.count = 0;
	}

	public void add(StudentData student)
	{
		StudentNode newItem = new StudentNode(student);

		if(start == null)
		{
			start = newItem;
			end = newItem;
		}
		else
		{
			/*
			 * Find end of list and add new item
			 * set new end of list pointer
			 */
		}
		count++;
	}
	public void insert(StudentData student, int pos)
	{
		StudentNode newItem = new StudentNode(student);
		StudentNode current;
		int currPos = 1;
		if(start == null)
		{
			start = newItem;
			end = newItem;
		}
		else if(pos == 0)
		{
			newItem.setNext(start);
			start = newItem;
		}
		else
		{
			/*
			 * Find position for insertion OR end of list
			 * set next item to go after new item
			 * set current item to have new item come after it
			 * double check that end item is set correctly
			 */
		}
		count++;
	}
	public void delete(int pos)
	{
		StudentNode current, remove;
		int currPos = 1;
		if(start == null)
		{
		}
		else if(pos == 0)
		{
			start = start.getNext();
			if(start.getNext() == null)
				end = start;
			count--;
		}
		else
		{
			/*
			 * Find position to remove
			 * Set item before it to item after it
			 * Adjust end variable if item removed is last item
			 * decrease counter
			 */
		}
	}
	public boolean empty()
	{
		return (count == 0) ? true : false;
	}

}
