
public class StudentNode {
	private StudentData student;
	private StudentNode next;
	public StudentNode(StudentData student) {
		this.student = student;
		this.next = null;
	}
	public StudentData getStudent() {
		return student;
	}
	public void setStudent(StudentData student) {
		this.student = student;
	}
	public StudentNode getNext() {
		return next;
	}
	public void setNext(StudentNode next) {
		this.next = next;
	}
}
