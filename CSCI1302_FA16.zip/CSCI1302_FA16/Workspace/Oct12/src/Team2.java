import java.util.Scanner;
import java.util.ArrayList;
/**
 * @author Michael Simica
 * @author Jacob Malimban
 * @author Dwight Larkins
 * @version 1.0, Team 2
 * 3rd place
 */
public class Team2 {
	public static void main(String[] args) {
		ArrayList<Long> step = new ArrayList<Long>();
		int run;
		long sum, aOrg, bOrg;
		Scanner scan = new Scanner(System.in);
		System.out.print("How many runs?\n> ");
		run = scan.nextInt();
		for(int i = 0; i < run; i++) {
			step.clear();
			sum = 0;
			long a = scan.nextInt();
			aOrg = a;
			long b = scan.nextInt();
			bOrg = b;
			while(a > 0) {
				if (a % 2 == 0) {
					a = (int)a/2;
					b *= 2;
				}
				else {//implies a is odd
					sum += b;
					step.add((long)b);
					a = (int)a/2;
					b *= 2;
				}
			}
			System.out.print(aOrg + " X " + bOrg + " = ");
			String str = "";
			for(int j = 0; j < step.size(); j++) {
				str += step.get(j);
				if(j < step.size() - 1)
					str += " + ";
			}
			System.out.println(str + " = " + sum);
		}
	}
}