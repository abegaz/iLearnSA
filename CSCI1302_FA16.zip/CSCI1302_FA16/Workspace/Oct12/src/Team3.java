/*
Team 3?
Brad Regeski
Chad Monahan
Ethan David
2nd place
*/
import java.text.DecimalFormat;
import java.util.Scanner;
public class Team3 {
	public static void main(String[] args) {
		int iter = 0;
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number of calculations desired: ");
		iter = input.nextInt();
		for (int i = iter; iter > 0; iter--) {
			System.out.println("Enter numbers to calculate, separated by spaces: ");
			int a = input.nextInt();
			int b = input.nextInt();
			System.out.println(multiplier(a,b));
		}
		input.close();
	}
	public static String multiplier(int a, int b) {
		long aa = a;
		long bb = b;
		long sum = 0;
		String result = a + " X " + b + " = ";
		while((int) aa > 0) {
			if ((int) aa % 2 != 0) {sum += bb; result += (bb);if (!(aa / 2 <= 0)) result +=" + "; }
			aa = aa/2;
			bb = bb * 2;
		}
		if (a != 0) result += " = ";
		result += sum;
		return result;
	}
}
