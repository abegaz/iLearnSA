//Team 4
//Tristan Derloshon, Emily Weeks, Brian Manzo, Kyle Wilson
//1st place
import java.util.Scanner;

public class Team4 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		System.out.println("How many test cases?");
		int testCases = scan.nextInt();
		scan.nextLine();

		for(int i=1; i<=testCases; i++)
		{
			System.out.println("Enter a test case: ");
			String case1 = scan.nextLine();
			String nums[] = case1.split(" ");
			long num1 = Integer.parseInt(nums[0]);
			long num2 = Integer.parseInt(nums[1]);

			long sum = 0;
			String output = "";
			while(num1>0)
			{

				if(num1%2 == 1)
				{
					sum += num2;
					output += " + " + num2;
				}
				num1 /= 2;
				num2 *= 2;
			}
			System.out.println("[for " + nums[0] + " " + nums[1] + "]");
			System.out.println(nums[0] + " X " + nums[1] + " = 0" + output + " = " + sum);
		}



	}

}
