// Kevin Lin, Evan Myers, Kyra Bessey, Madeleine Godwin
import java.util.*;
public class Team1 {
	public static void main(String[]args){
		
		
		int size1, size2, c, e, f, casee;
		long a, b, sum;
		
		Scanner input = new Scanner(System.in);
		
		casee = input.nextInt();
		for(int j = 0 ; j < casee; j++){
			a = input.nextInt();
			b = input.nextInt();
			c = (int)a;
			e = (int)a;
			f = (int)b;
			size1=0;
			size2=0;
			sum=0;
			while(c>0){ //array size
				if(c%2==1){
					c/=2;
					size1++;
					size2++;
				}else{
					c/=2;
				}
			}// array size
			long[] numarray = new long[size1]; //array created
			
			while(a>0){
				if(a%2==1){
					numarray[(size2-1)]=b;
					sum+=b;
					a/=2;
					b*=2;
					size2--;
				}else{
					a/=2;
					b*=2;
				}
			}
			System.out.println("[for " + e + " " + f + "]");//output
			System.out.print(e+" X "+f+" = ");
			for(int p = 0; size1 > p; size1--){
				System.out.print(numarray[(size1-1)]);
				if(size1>1){
					System.out.print(" + ");
				}else{
					System.out.print(" = ");
					System.out.print(sum);
					System.out.println();//output
				}
			}
		}
		input.close();
	}

}
