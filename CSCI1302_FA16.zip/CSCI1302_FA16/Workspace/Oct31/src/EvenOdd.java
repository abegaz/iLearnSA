/*
 * isEven(n)
 * n = 0 : even
 * n = 1 : odd
 * n > 0 : isOdd(n-1)
 *
 * isOdd(n)
 * n = 0 : even
 * n = 1 : odd
 * n > 0 : isEven(n-1)
 */
public class EvenOdd {

	public static void main(String[] args) {
		System.out.println("Is 10 even :" + isEven(10));
		System.out.println("Is 10 odd :" + isOdd(10));
		System.out.println("Is 15 even :" + isEven(15));
		System.out.println("Is 15 odd :" + isOdd(15));

	}
	public static boolean isEven(int n)
	{
		//System.out.println("even: " + n);
		if(n == 0)
			return true;
		else
			return isOdd(n-1);
	}
	public static boolean isOdd(int n)
	{
		//System.out.println("odd: " + n);
		if(n == 0)
			return false;
		else if(n == 1)
			return true;
		else
			return isEven(n-1);
	}
}
