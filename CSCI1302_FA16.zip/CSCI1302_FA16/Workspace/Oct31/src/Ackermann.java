/*
 * A(m,n)
 * m = 0 : n+1
 * m > 0 & n = 0 : A(m-1, 1)
 * m > 0 & n > 0 : A(m-1, A(m, n-1))
 */
public class Ackermann {

	public static void main(String[] args) {
		System.out.println(Ackermann(1, 1));
		//System.out.println(Ackermann(1, 2));
		//System.out.println(Ackermann(2, 1));

	}
	public static int Ackermann(int m, int n)
	{
		System.out.println("M: " + m + " :: N: " + n);
		if(m == 0)
		{
			return n+1;//base case
		}
		else if(n == 0)
		{
			return Ackermann(m-1, 1);//linear recursion
		}
		else
		{
			return Ackermann(m-1, Ackermann(m, n-1));//nested recursion
		}
	}
}
