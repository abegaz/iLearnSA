import java.util.Arrays;
import java.util.Random;

public class DeckOfCards {
	private Card[] deck;
	private int numberOfCards;
	public DeckOfCards()
	{
		addDeck();
	}
	public void addDeck()
	{
		deck = new Card[52];
		for(int i = 0; i < deck.length; i++)
		{
			String suit;
			switch(i / 13){
			case 0:
				suit = "Clubs";
				break;
			case 1:
				suit = "Hearts";
				break;
			case 2:
				suit = "Diamonds";
				break;
			default:
				suit = "Spades";
				break;
			}
			deck[i] = new Card(suit, (i%13)+1);
		}
		numberOfCards = 52;
		shuffle();
		System.out.println(Arrays.toString(deck));
	}
	public int getNumberOfCards()
	{
		return numberOfCards;
	}
	public Card deal()
	{
		if(numberOfCards > 0)
		{
			numberOfCards--;
			return deck[numberOfCards];
		}
		else
			return null;
	}
	public void shuffle()
	{
		Random rand = new Random();
		for(int i = 0; i < deck.length; i++)
		{
			int index1 = rand.nextInt(52);
			int index2 = rand.nextInt(52);
			Card temp = deck[index1];
			deck[index1] = deck[index2];
			deck[index2] = temp;
		}
	}
}










