
public class Card {
	private String suit;
	private int value;
	public Card(String suit, int value) {
		super();
		this.suit = suit;
		this.value = value;
	}
	@Override
	public String toString() {
		String cardFace = ""+value;
		switch(value)
		{
		case 11:
			cardFace = "Jack";
			break;
		case 12:
			cardFace = "Queen";
			break;
		case 13:
			cardFace = "King";
			break;
		}
		return cardFace + " of " + suit;//Jack of Clubs//9 of Hearts
	}
}
