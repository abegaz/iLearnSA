import java.util.Scanner;

public class PP8_2 {

	public static void main(String[] args) {
		//Modify 8.1 to work for numbers in the range -25 to 25

		Scanner scan = new Scanner(System.in);
		//set up array of counters
		int[] counters = new int[51];//0-50 are valid index

		//ask for numbers until one is entered that is < 0 or > 50
		System.out.print("Enter a number between -25 and 25:");
		int num = scan.nextInt();
		num += 25;
		while(num >= 0 && num <= 50)
		{
			//increment the counter for the number entered
			counters[num]++;
			//ask for next number
			System.out.print("Enter a number between -25 and 25:");
			num = scan.nextInt();
			num += 25;
		}
		//System.out.println("End");//test that loop ended correctly
		//System.out.println(Arrays.toString(counters));//test what is collected into array

		//After all numbers collected print out counts of each number that was entered at least once
		for(int i = 0; i < counters.length; i++)
		{
			//print sum if at least one of the number was entered
			if(counters[i] > 0)
				System.out.println("The number " + (i-25) + " was entered " + counters[i] +  " times.");

		}

	}

}
