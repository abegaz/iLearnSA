
public class PP8_7 {

	public static void main(String[] args) {
		DeckOfCards doc = new DeckOfCards();
		System.out.println("Number of cards in deck:" + doc.getNumberOfCards());
		for(int i = 0; i < 13; i++)
			System.out.println(doc.deal());
		System.out.println("Number of cards in deck:" + doc.getNumberOfCards());

		for(int i = doc.getNumberOfCards(); i > 0; i--)
		{
			System.out.println(doc.deal());
		}
		System.out.println("Number of cards in deck:" + doc.getNumberOfCards());

	}

}
