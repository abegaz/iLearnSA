import java.util.Arrays;
import java.util.Scanner;

public class PP8_1 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//set up array of counters
		int[] counters = new int[51];//0-50 are valid index

		//ask for numbers until one is entered that is < 0 or > 50
		System.out.print("Enter a number between 0 and 50:");
		int num = scan.nextInt();
		while(num >= 0 && num <= 50)
		{
			//increment the counter for the number entered
			counters[num]++;
			//ask for next number
			System.out.print("Enter a number between 0 and 50:");
			num = scan.nextInt();
		}
		//System.out.println("End");//test that loop ended correctly
		//System.out.println(Arrays.toString(counters));//test what is collected into array

		//After all numbers collected print out counts of each number that was entered at least once
		for(int i = 0; i < counters.length; i++)
		{
			//print sum if at least one of the number was entered
			if(counters[i] > 0)
				System.out.println("The number " + i + " was entered " + counters[i] +  " times.");
				
		}
	}

}
