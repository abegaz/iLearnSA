/*
 * Factorial:
 * 		1! = 1
 * 		N! = N * (N-1)!
 */
public class RecursiveFactorial {

	public static void main(String[] args) {
		System.out.println(Factorial(1));//1 = 1
		System.out.println(Factorial(2));//2*1 = 2
		System.out.println(Factorial(3));//3*2*1 = 6
		System.out.println(Factorial(4));//4*3*2*1 = 24
		System.out.println(Factorial(5));//5*4*3*2*1 = 120
	}
	public static int Factorial(int N)
	{
		if(N == 1)//1! = 1
		{
			System.out.print("1 = ");
			return 1;
		}
		else//N! = N * (N-1)!
		{
			System.out.print(N + " * ");
			int NFactorial = N * Factorial(N-1);
			return NFactorial;
		}
	}
}
/*
 *
 *

5!
Factorial(5) = 5 * Factorial(4)
Factorial(4) = 4 * Factorial(3)
Factorial(3) = 3 * Factorial(2)
Factorial(2) = 2 * Factorial(1)
Factorial(1) = 1

Factorial(5) = 5 * Factorial(4 * Factorial(3 * Factorial(2 * Factorial(1))))

 *
 *
 */