import java.util.ArrayList;

/*
 * List:
 * 		number
 * 		number, List
 */
public class RecursiveList {

	private static ArrayList<Integer> numbers = new ArrayList<Integer>();
	public static void main(String[] args) {
		String list = "12, 23, 42, 8, 1234, 13, 2425, 2";
		ListProcessor(list);
		for(int n : numbers)
			System.out.println(n);
		//System.out.println(numbers);
	}
	public static void ListProcessor(String list)
	{
		int commaPosition = list.indexOf(',');
		if(commaPosition > 0)//number, List
		{
			int num = Integer.parseInt(list.substring(0, commaPosition));//remove up to comma as number
			list = list.substring(commaPosition+2);//remove after comma and space for rest of list
			numbers.add(num);
			ListProcessor(list);
		}
		else//number
		{
			numbers.add(Integer.parseInt(list));
		}
	}

}
