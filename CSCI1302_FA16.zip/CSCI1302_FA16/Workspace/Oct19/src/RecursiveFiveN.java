/*
 * Reduce by 1 at a time
 * 5*N
 * 		5 * 1 = 5
 * 		5 * N = 5 + (5 * (N-1))
 *
 * Reduce by 2 at a time
 * 5*N
 * 		5 * 1 = 5
 * 		5 * 2 = 10
 * 		5 * N = 10 + (5 * (N-2))
 */
public class RecursiveFiveN {

	public static void main(String[] args) {
		System.out.println(FiveNByOne(4));
		System.out.println(FiveNByTwo(4));

		System.out.println(FiveNByOne(5));
		System.out.println(FiveNByTwo(5));

	}
	public static int FiveNByOne(int N)
	{
		if(N == 1)//5 * 1 = 5
		{
			System.out.print("5 = ");
			return 5;
		}
		else//5 * N = 5 + (5 * (N-1))
		{
			System.out.print("5 + ");
			return 5 + FiveNByOne(N-1);
		}
	}
	public static int FiveNByTwo(int N)
	{
		if(N == 1)//5 * 1 = 5
		{
			System.out.print("5 = ");
			return 5;
		}
		else if(N == 2)//5 * 2 = 10
		{
			System.out.print("10 = ");
			return 10;
		}
		else//5 * N = 10 + (5 * (N-2))
		{
			System.out.print("10 + ");
			return 10 + FiveNByTwo(N-2);
		}
	}

}
