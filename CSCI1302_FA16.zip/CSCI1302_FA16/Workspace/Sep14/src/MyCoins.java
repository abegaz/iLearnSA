import java.text.DecimalFormat;
import java.util.Random;

public class MyCoins {

	public static void main(String[] args) {
		//create several monetary coins
		Random rand = new Random();
		MonetaryCoin[] coins = new MonetaryCoin[50];
		for(int i = 0; i < coins.length; i++)
		{
			double value = 0;
			switch(rand.nextInt(5))
			{
			case 0:
				value = 0.01;
				break;
			case 1:
				value = 0.05;
				break;
			case 2:
				value = 0.1;
				break;
			case 3:
				value = 0.25;
				break;
			case 4:
				value = 1;
				break;
			}
			coins[i] = new MonetaryCoin(value);
		}

		DecimalFormat df = new DecimalFormat("0.00");
		double sum = 0;
		int heads = 0;
		int tails = 0;
		//sum up the value of the coins
		for(MonetaryCoin mc : coins)
		{
			//System.out.println(mc.getValue());
			sum += mc.getValue();
			if(mc.isHeads())
				heads++;
			else
				tails++;
			System.out.println(mc);
		}

		//show if the coins are heads or tails
		System.out.println("The sum of my coins is $"+df.format(sum)+".");
		System.out.println(heads+" are heads and "+tails+" are tails.");

		heads = 0;
		tails = 0;
		//flip the coins
		for(MonetaryCoin mc : coins)
		{
			mc.flip();
			if(mc.isHeads())
				heads++;
			else
				tails++;
		}
		//show new heads/tails
		System.out.println(heads+" are heads and "+tails+" are tails after flipping all the coins.");

	}

}
