
public class Car extends Vehicle {
	private String color;
	private int wheels;
	public Car(int maxSpeed, int maxPassengers, String color, int wheels) {
		super(maxSpeed, maxPassengers);
		this.color = color;
		this.wheels = wheels;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public int getWheels() {
		return wheels;
	}
	public void setWheels(int wheels) {
		this.wheels = wheels;
	}
	@Override
	public String toString() {
		return "Car color of " + color + ", wheels " + wheels +
				", max speed of " + super.getMaxSpeed() +
				", max passengers of " + super.getMaxPassengers();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		Car other = (Car) obj;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (wheels != other.wheels)
			return false;
		return true;
	}

}
