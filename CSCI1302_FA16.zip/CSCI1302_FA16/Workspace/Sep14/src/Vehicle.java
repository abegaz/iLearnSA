
public class Vehicle {
	private int maxSpeed;
	private int maxPassengers;
	public Vehicle(int maxSpeed, int maxPassengers) {
		super();
		this.maxSpeed = maxSpeed;
		this.maxPassengers = maxPassengers;
	}
	public int getMaxSpeed() {
		return maxSpeed;
	}
	public void setMaxSpeed(int maxSpeed) {
		if(maxSpeed >= 0)
			this.maxSpeed = maxSpeed;
	}
	public int getMaxPassengers() {
		return maxPassengers;
	}
	public void setMaxPassengers(int maxPassengers) {
		if(maxPassengers >= 0)
			this.maxPassengers = maxPassengers;
	}
	@Override
	public String toString() {
		return "Vehicle with a max speed of " + maxSpeed + " and a max passengers of " + maxPassengers;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Vehicle other = (Vehicle) obj;
		if (maxPassengers != other.maxPassengers)
			return false;
		if (maxSpeed != other.maxSpeed)
			return false;
		return true;
	}

}
