








public class MonetaryCoin extends Coin {
	//store coin value
	private double value;

	//constructor to initialize value and Coin class
	public MonetaryCoin(double value) {
		super();
		this.value = value;
	}

	//return coin value
	public double getValue() {
		return value;
	}

	/*
	 * Change private int face in the Coin class to protected int face for this method to work
	public void setFace(){
		super.face = 0;
	}
	*/

	@Override
	public String toString() {
		return "Coin value $" + value + " and it is " + super.toString();
	}

	/*
	 * Gained the following methods from extending the Coin class
	 * flip()
	 * isHeads()
	 */

}