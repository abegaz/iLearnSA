
public class MyCars {

	public static void main(String[] args) {
		Vehicle v1 = new Vehicle(5, 10);
		System.out.println(v1);

		Car c1 = new Car(5, 10, "red", 4);
		System.out.println(c1);
		System.out.println(c1.getMaxPassengers());
		c1.setMaxSpeed(55);
		System.out.println(c1);
	}

}
