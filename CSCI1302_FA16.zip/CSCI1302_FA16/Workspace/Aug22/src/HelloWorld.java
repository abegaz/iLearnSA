import java.util.Scanner;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello World!");
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter a name:");
		String name = scan.nextLine();
		System.out.println("Your name is:" + name);
	}

}
