import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
 * Team 6
Kyle Wilson
Kevin Lin
Bradford Regeski
 */
public class Team6 {

	public static void main(String[] args) {
	    Scanner input = new Scanner(System.in);
	    Random r = new Random();
	    int a = input.nextInt();
	    for(int q = 0; q < a; q++){
	      int[][] nums  = new int[input.nextInt()][input.nextInt()];
	      isDiverse(nums);
	      if (isDiverse(nums) == true){
	        System.out.println("no"); 
	      } 
	      else{
	        System.out.println("yes"); 
	      }
	    }  
	  }  
	  public static int arraySum(int[] arr) {
	    int sum = 0;
	    for (int i=0; i<arr.length; i++)
	      sum += arr[i];
	    return sum;
	  }
	  public static int[] rowSums(int[][] arr2D) {
	    int[] res = new int[arr2D.length];
	    for (int i=0; i<arr2D.length; i++)
	      res[i] = arraySum(arr2D[i]);
	    return res;
	  }
	  public static boolean isDiverse(int[][] arr2D) {
	    int[] sums = rowSums(arr2D);
	    Arrays.sort(sums);
	    for (int i=0; i<sums.length-1; i++)
	      if (sums[i] == sums[i+1])
	      return false;
	    return true;
	  }

}
