/*
 * Team 2
Kyra Bessey
Madeleine Godwin
Chadd Monahan
 */
public class Team2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
