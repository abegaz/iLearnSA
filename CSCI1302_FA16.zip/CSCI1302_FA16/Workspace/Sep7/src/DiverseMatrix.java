import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class DiverseMatrix {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		for(int i = s.nextInt(); i > 0; i--)
		{
			int[][] matrix = new int[s.nextInt()][s.nextInt()];
			for(int j = matrix.length; j > 0; j--)
			{
				for(int k = matrix[0].length; k > 0; k--)
				{
					matrix[j-1][k-1] = s.nextInt();
				}
			}
			//System.out.println(Arrays.deepToString(matrix));

			ArrayList<Integer> sums = new ArrayList<Integer>();
			boolean diverse = true;
			//sum rows
			for(int j = matrix.length; j > 0; j--)
			{
				int rowSum = 0;
				for(int k = matrix[0].length; k > 0; k--)
				{
					rowSum += matrix[j-1][k-1];
				}
				if(sums.contains(rowSum))
					diverse = false;
				else
					sums.add(rowSum);
				if(!diverse)
					break;
			}
			//sum columns
			for(int k = matrix[0].length; k > 0; k--)
			{
				int colSum = 0;
				for(int j = matrix.length; j > 0; j--)
				{
					colSum += matrix[j-1][k-1];
				}
				if(sums.contains(colSum))
					diverse = false;
				else
					sums.add(colSum);
				if(!diverse)
					break;
			}
			System.out.println((diverse)?"yes":"no");
		}

	}

}
