import java.util.ArrayList;
import java.util.Scanner;

/*
 * 2ND Place!!
 *
 * Team 1
Ethan David**
Brian Manzo
Emily Weeks
 */
public class Team1 {
	public static Scanner input= new Scanner(System.in);
	public static void main(String[] args) {
		//Scanner input = new Scanner(System.in);
		System.out.println("Enter number of arrays: ");
		int numarrays = input.nextInt();
		for (int i = 0; i < numarrays; i++) {
			ArrayList<Integer> result = sumRowColumns();
			if (isDiverse(result)) System.out.println("yes"); else
				System.out.println("no");
		}
	}
	public static ArrayList<Integer> sumRowColumns() {
		//Scanner input = new Scanner(System.in);
		System.out.println("Enter number of rows and columns in the format 'rows columns' :");
		int numrows = input.nextInt();
		int numcolumns = input.nextInt();
		int[][] mainarray = new int[numrows][numcolumns];
		for (int j = 0; j < numrows; j++) {
			System.out.println("Enter values for row " + (j+1) + ", separated by spaces: ");
			for (int i = 0; i < numcolumns; i++) {
				mainarray[j][i] = input.nextInt();
			}
		}
		ArrayList<Integer> results = new ArrayList<>();
		for (int[] row : mainarray) {
			int r = 0;
			for (int item : row) {
				r += item;
			}
			results.add(r);
		}
		for (int i = 0; i < numcolumns; i++) {
			int r = 0;
			for (int j = 0; j < numrows; j++) {
				r += mainarray[j][i];
			}
			results.add(r);
		}
		return results;
	}
	public static boolean isDiverse(ArrayList<Integer> results) {
		for (int i = 0; i < results.size(); i++) {
			for (int j = i+1; j < results.size(); j++) {
				if (results.get(i) == results.get(j)) return false;
			}
		}
		return true;
	}

}
