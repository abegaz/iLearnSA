import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

/*
 * 1ST PLACE!!
 *
 * Team 5
Tristan Derloshon
Jeffrey Thomson**
Jacob Malimban
 */
public class Team5 {

	public static void main(String[] args) {
		boolean simSum = false; //for output
		Scanner scan = new Scanner(System.in);
		System.out.println("Number of two-dimensional arrays?");
		int numArrays = scan.nextInt();
		//Prompt user
		for(int i = 0; i < numArrays; i++)
		{
			//prompt user for two numbers row, column
System.out.println("Enter the number of Rows and Columns for array " + i);
			int[][] diverse = new int[scan.nextInt()][scan.nextInt()];
			for(int j = 0; j < diverse.length; j++)
			{
				System.out.println("Enter the ints for the row and column" + j);
				for(int k = 0; k < diverse[0].length; k++)
				{
					diverse[j][k] = scan.nextInt();
				}
			}
			//calculate the sums
			ArrayList sum = new ArrayList();
			//gets row sum
			for(int j = 0; j < diverse.length; j++)
			{
				int arrSum = 0;
				for(int k = 0; k < diverse[0].length; k++)
				{
					arrSum += diverse[j][k];
				}
				sum.add(arrSum);
			}
			//get column sum
			for(int k = 0; k < diverse[0].length; k++)
			{
				int arrSum = 0;
				for(int j = 0; j < diverse.length; j++)
				{
					arrSum += diverse[j][k];
				}
				sum.add(arrSum);
			}
			//order ArrayList
Collections collections = null;
			collections.sort(sum);
			simSum = false;
			//check ArrayList for similar values
			for(int j = 0; j < sum.size() - 1; j++)
			{
				if(sum.get(j) == sum.get(j + 1))
					simSum = true;
			}
			if(simSum)
				System.out.println("No");
			else
				System.out.println("Yes");

}

	}

}
