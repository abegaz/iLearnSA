
public class FourthOfJuly extends Holiday {
	public void celebrate()
	{
		System.out.println( "Fireworks!");
	}
}
