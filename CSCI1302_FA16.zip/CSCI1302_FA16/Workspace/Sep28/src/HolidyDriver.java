
public class HolidyDriver {

	public static void main(String[] args) {
		Holiday day = new LaborDay();
		//LaborDay day2 = (LaborDay)new Holiday();//can't cast parent object into child object
		Holiday day3 = new Holiday();

		day.celebrate();
		((LaborDay)day).closePool();
		//((LaborDay)day3).closePool();//not a holiday
		day3.celebrate();

		Holiday[] days = new Holiday[3];
		days[0] = new LaborDay();
		days[1] = new FourthOfJuly();
		days[2] = new Holiday();

		for(Holiday h : days)
			h.celebrate();

	}

}
