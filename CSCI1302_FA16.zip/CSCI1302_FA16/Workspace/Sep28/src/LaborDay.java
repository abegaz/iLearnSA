
public class LaborDay extends Holiday {
	public void celebrate()
	{
		System.out.println( "Celebrate Labor Day");
	}
	public void closePool()
	{
		System.out.println("Pool is closed");
	}
}
