
public class Holiday {
	public void celebrate()
	{
		System.out.println( "Celebrate Holiday");
	}
}
