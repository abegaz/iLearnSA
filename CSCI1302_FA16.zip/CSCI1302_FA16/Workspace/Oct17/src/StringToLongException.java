
public class StringToLongException extends Exception {

	public StringToLongException() {
		super("String entered is to long, must be less than 20 characters.");
	}
	public StringToLongException(int num) {
		super("String entered is to long, must be less than " + num + " characters.");
	}
}
