import java.util.Scanner;

public class ProductCodes {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String code = scan.next().toUpperCase();
		int valid = 0;
		int banned = 0;
		while(!code.equals("STOP"))
		{
			try{
				char c = code.charAt(8);
				int num = Integer.parseInt(code.substring(3, 7));
				if(num >= 2000 && c == 'R')
					banned++;
				else
					valid++;
			}catch(IndexOutOfBoundsException e){
				System.out.println(e.getMessage());
				e.printStackTrace();
				System.out.println("Invalid code, to short");
			}catch(NumberFormatException e){
				System.out.println(e.getMessage());
				System.out.println("Invalid code, number section not correct");
			}catch(Exception e){
				e.printStackTrace();
			}finally{
				code = scan.next().toUpperCase();
			}
		}
		System.out.println("Banned: " + banned);
		System.out.println("Valid: " + valid);
	}

}
