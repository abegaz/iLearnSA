
public class ExceptionScope {
	public void Level1(){
		System.out.println("Begin Level 1");

		this.Level2();

		System.out.println("End Level 1");
	}
	public void Level2(){
		System.out.println("Begin Level 2");

		this.Level3();

		System.out.println("End Level 2");
	}
	public void Level3() {
		System.out.println("Begin Level 3");

			System.out.println(10/0);

		System.out.println("End Level 3");
	}
}
