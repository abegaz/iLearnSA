import java.util.Scanner;

public class CreatingExceptions {

	public static void main(String[] args) throws OutOfRangeException 
	{
		Scanner scan = new Scanner(System.in);
		int num = scan.nextInt();
		if(num < 1 || num > 25)
			throw new OutOfRangeException();
		else
			System.out.println(num);

	}

}
