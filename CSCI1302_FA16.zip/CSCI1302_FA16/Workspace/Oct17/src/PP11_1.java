import java.util.Scanner;

public class PP11_1 {

	public static void main(String[] args) throws StringToLongException {
		Scanner scan = new Scanner(System.in);
		String input = scan.next().toUpperCase();
		int valid = 0;
		while(!input.equals("DONE"))
		{
			//if string is to long, throw exception
			//let exception cause program to terminate
			if(input.length() > 20)
			{
				throw new StringToLongException();
			}
			else
			{
				valid++;
			}
			input = scan.next().toUpperCase();
		}
		System.out.println("Valid strings: " + valid);
	}

}
