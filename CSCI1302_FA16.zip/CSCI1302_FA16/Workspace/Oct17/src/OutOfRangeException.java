
public class OutOfRangeException extends Exception {
	public OutOfRangeException()
	{
		super("Out of range exception, must be between 1 and 25");
	}
}
