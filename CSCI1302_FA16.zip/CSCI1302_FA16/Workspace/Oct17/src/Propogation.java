
public class Propogation {

	public static void main(String[] args) {
		ExceptionScope es = new ExceptionScope();
		try{
		es.Level1();
		}catch(ArithmeticException e){
			System.out.println("Exception Caught!");
			System.out.println(e.getMessage());
			e.printStackTrace();
		}
	}

}
