import java.util.Scanner;

public class PP11_2 {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		String input = scan.next().toUpperCase();
		int valid = 0;
		while(!input.equals("DONE"))
		{
			try {
				if(input.length() > 20)
				{
					throw new StringToLongException();
				}
				else
				{
					valid++;
				}
			} catch (StringToLongException e) {
				// TODO Auto-generated catch block
				//e.printStackTrace();
				System.out.println(e.getMessage());
			}
			input = scan.next().toUpperCase();
		}
		System.out.println("Valid strings: " + valid);

	}

}
