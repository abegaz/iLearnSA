
public class Review {

	public static void main(String[] args) {
		String[] myArray = new String[10];
		String[] myArray2 = {"first","second","last"};
		String[][] myArray3 = new String[5][5];
		String[] myArray4 = myArray3[0];
		String str = myArray3[0][0];
		int size = myArray.length;
		/*
		 * extends
		 * super
		 * abstract
		 * final
		 * protected
		 */
	}

}
