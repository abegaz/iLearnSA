
public class Course implements Comparable<Course> {
	@Override
	public int compareTo(Course arg0) {
		if(this.courseNumber > arg0.getCourseNumber())
			return 1;
		else if(this.courseNumber < arg0.getCourseNumber())
			return -1;
		return 0;
	}

	private static int courseCount;
	public static int getCourseCount()
	{
		return courseCount;
	}
	private String courseName;
	private int courseNumber;
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((courseName == null) ? 0 : courseName.hashCode());
		result = prime * result + courseNumber;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Course other = (Course) obj;
		if (courseName == null) {
			if (other.courseName != null)
				return false;
		} else if (!courseName.equals(other.courseName))
			return false;
		if (courseNumber != other.courseNumber)
			return false;
		return true;
	}

	public Course(String courseName, int courseNumber) {
		super();
		this.courseName = courseName;
		this.courseNumber = courseNumber;
		courseCount++;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getCourseNumber() {
		return courseNumber;
	}
	public void setCourseNumber(int courseNumber) {
		this.courseNumber = courseNumber;
	}
	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", courseNumber=" + courseNumber + "]";
	}

}
