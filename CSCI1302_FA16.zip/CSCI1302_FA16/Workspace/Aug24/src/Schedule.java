import java.util.Arrays;

public class Schedule {

	public static void main(String[] args) {
		Course csci1301 = new Course("CSCI", 1301);
		Course csci1302 = new Course("CSCI", 1302);
		Course csci3000 = new Course("CSCI", 3000);

		System.out.println(csci1301);
		System.out.println(csci1302);
		System.out.println(csci3000);

		csci1301.setCourseName("Intro to Programming");

		System.out.println(csci1301);

		//csci1301.courseName = "";//not visible to this class
		System.out.println("Number of Course Objects Created: "+Course.getCourseCount());


		Course[] list = new Course[3];
		list[0] = csci3000;
		list[1] = csci1302;
		list[2] = csci1301;

		System.out.println("UNSORTED");
		for(Course c : list)
			System.out.println(c);

		Arrays.sort(list);

		System.out.println("SORTED");
		for(Course c : list)
			System.out.println(c);

	}

}
