
public class Conversions {

	public static void main(String[] args) {
		int a = 250;
		short b = (short) a;//casting
		double c = 10.5;
		int d = (int) c;//casting
		c = a;//assignment
		c = a * 10.5;//promotion

	}

}
