import java.text.DecimalFormat;

public class Formatter {

	public static void main(String[] args) {
		DecimalFormat df = new DecimalFormat("#.##");//2 optional decimal places
		double a = 10.12845;
		System.out.println(df.format(a));
		double b = 10.0;
		System.out.println(df.format(b));
		DecimalFormat df2 = new DecimalFormat("#.00");//2 forced decimal places
		System.out.println(df2.format(a));
		System.out.println(df2.format(b));
	}

}
