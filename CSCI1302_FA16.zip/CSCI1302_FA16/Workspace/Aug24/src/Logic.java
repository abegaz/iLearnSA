/*
Logic l = new Logic();
l.main();
Logic.main();
*/
public class Logic {

	public static void main(String[] args) {
		double a = 13.123456;
		double b = 13.123455;
		double CloseEnough = .0000001;
		if(Math.abs(a-b) < CloseEnough)
			System.out.println("Basically Equal");
		else
			System.out.println("Not really equal");

		String c = "Hello World";
		String d = "hello world";
		if(d.compareTo(c) > 0)
			System.out.println("String d is greater than c");
		System.out.println(d.compareTo(c));

		Course c1 = new Course("Name", 1234);
		Course c2 = c1;

		System.out.println(c1);
		System.out.println(c2);
		System.out.println(c1==c2);
		c2.setCourseName("New Name");
		System.out.println(c1);
		System.out.println(c2);

		Course c3 = new Course("Name", 1234);
		Course c4 = new Course("Name", 1234);
		System.out.println(c3==c4);
		System.out.println(c3.equals(c4));

		int f = 10;
		int g = 15;
		int h = 17;

		if(f < g)
		{
			System.out.println("line 1");
			if(g < h)
				System.out.println("line 2");
		}
		else
		{
			System.out.println("line 3");
			System.out.println("line 4");
		}

		if(f > g)
			System.out.println("f > g");
		else if(f > h)
			System.out.println("f > h");
		else if(g > h)
			System.out.println("g > h");

		switch(f)
		{
		case 13:
			System.out.println("13");
			break;
		case 15:
			System.out.println("15");
			break;
		case 17:
			System.out.println("17");
			break;
		default:
			System.out.println("other");
			break;
		}

		int a1 = 15;
		int a2 = 6;
		int a3 = (a1 > a2) ? a1 : a2;
		System.out.println(a3);
		if(a1 > a2)
			a3 = a1;
		else
			a3 = a2;

		while(a3 > 0)
		{
			System.out.println(a3);
			a3--;
		}
		do{
			System.out.println(a3);
		}while(a3 > 10);


		/*
		 * int a4 = 0;
		 * while(a4 < 10)
		 * {
		 * 		System.out.println(a4);
		 * 		a4++;
		 * }
		 */

		for(int a4 = 0; a4 < 10; a4++)
		{
			System.out.println(a4);
		}

		System.out.println("Number of Course Objects Created: "+Course.getCourseCount());
	}

}


















