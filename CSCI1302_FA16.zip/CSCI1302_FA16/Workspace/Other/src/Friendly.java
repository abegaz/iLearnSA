/**
 * The final program that adds
 * 5 friends to your linked list, 
 * inserts 2 friends, 
 * then deletes 3 friends 
 * and print the list at each state
 * @author Jacob Malimban
 * Lab 7 - Collections
 */
public class Friendly {
	public static void main (String[] args) {
		FriendsList friendly = new FriendsList();
		System.out.println(friendly.toString());
		friendly.add(new Friends("Brandon", "Gomez", 18));
		System.out.println(friendly.toString());
		friendly.add(new Friends("Sarah", "Simpson", 18));
		System.out.println(friendly.toString());
		friendly.add(new Friends("Stephen", "Hughes", 18));
		System.out.println(friendly.toString());
		friendly.add(new Friends("Chadler", "Iriarte", 18));
		System.out.println(friendly.toString());
		friendly.add(new Friends("Juri", "Monma", 21));
		System.out.println(friendly.toString());
		friendly.insert(new Friends("Min", "Ho", 19), 1);
		System.out.println(friendly.toString());
		friendly.insert(new Friends("Kurt", "Knaut", 18), 6);
		System.out.println(friendly.toString());
		friendly.delete(1);
		System.out.println(friendly.toString());
		friendly.delete(3);
		System.out.println(friendly.toString());
		friendly.delete(4);
		System.out.println(friendly.toString());
		
		
	}
}
