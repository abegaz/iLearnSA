
import java.util.Scanner;
import java.util.ArrayList;
/**
 * Nodes are a noding 
 * @author Jacob
 *
 */
public class JacobM_Recursion_Lab {
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		recursPlit(scan.nextLine(), "");
	}
	/**
	 * Recursive tree slicer
	 * @param tree - a tree to be sliced if possible
	 * @param currentPath - current node path
	 */
	public static void recursPlit(String tree, String currentPath){
		String[] halfNode = splitTree(tree);
		String node = halfNode[0], treeL = halfNode[1], treeR = halfNode[2];
		currentPath += node + " ";
		if(treeL.equals("()") && treeR.equals("()")) { //if we've reached an end
			System.out.println(currentPath);
		}
		else { //we've started a node path and we have not reached an end
			if(!(treeL.equals("()"))) {//there's something in the left
				recursPlit(halfNode[1], currentPath);
			}
			if(!(treeR.equals("()"))) {//there's something in the right
				recursPlit(halfNode[2], currentPath);
			}
		}		
	}
	/**
	 * Takes in tree : (node tree tree)
	 * Returns pieces: [0] = node, [1] = leftTree, [2] = rightTree
	 * @param tree - a tree
	 * @return String[] - split tree
	 */
	public static String[] splitTree(String tree){
		//expected tree format
		//(node tree tree)
		//0 1 2-x x-(length-2) length-1
		if(tree.length() <= 2)//tree not long enough to process
			return new String[]{tree, "", ""};
		String[] temp = new String[3];
		temp[0] = "" + tree.charAt(1);//grab tree node
		tree = tree.substring(2, tree.length()-1);//remove node and outer paren
		int parenCount = 0;//count of open paren
		int endTreeOne = 0;//end of first tree
		for(int i = 0; i < tree.length(); i++){
			if(tree.charAt(i) == '(')
				parenCount++;
			if(tree.charAt(i) == ')')
				parenCount--;
			if(parenCount == 0){
				endTreeOne = i;
				break;//ends for loop early
			}
		}
		temp[1] = tree.substring(0, endTreeOne+1);//left tree
		temp[2] = tree.substring(endTreeOne+1);//right tree
		return temp;
	}
}
