/**
 * A collection of Friends
 * @author Jacob Malimban
 * Lab 7 - Collection
 */
public class FriendsList {
	/**
	 * Apparently class-ception exists, or nested classes
	 * @author Jacob Malimban
	 * Inner node class with public variables to take care of remembering 
	 * the current Friend reference and the next Friend reference
	 */
	private class FriendsNode {
		public Friends friend;
		public FriendsNode next;
		/**
		 * Constructor
		 * @param friend <3
		 */
		public FriendsNode(Friends friend) {
			this.friend = friend;
			next = null;
		}
	}
	
	//Now for the actual FriendsList class collection
	private int count; //how many friends
	private FriendsNode start; //first friend reference
	private FriendsNode end; //last friend reference
	/**
	 * Constructor creating a list with no friends </3
	 */
	public FriendsList() {
		start = null;
		end = null;
		count = 0;
	}
	/**
	 * Creates a new FriendNode object reference then
	 * adds it to the end of the list! :D
	 * @param friend - a friend!
	 */
	public void add(Friends friend) {
		//node is the new friend node
		FriendsNode node = new FriendsNode(friend);
		if(start == null){ //no friends </3
			start = node; //now there's one :)
			end = node;
		}
		else { //there's friends and now more to come!
			end.next = node; //we go to then end and set its next to the new node
			end = node; //then the new node becomes the new end
		}
		count++; //new friend get!
	}
	/**
	 * Inserts a new FriendNode object reference
	 * @param friend - a friend!
	 * @param place - place it where? (positive int)
	 * 0 is first
	 */
	public void insert(Friends friend, int place) {
		FriendsNode node = new FriendsNode(friend); //new friend node created
		//that place doesn't exist silly user
		if(place > count || place < 0) {
			System.out.println("Wrong input. Int < friend count needed.");
		}
		//add it to the end of the list
		else if(place == count - 1) 
			add(friend);
		//valid not end insert
		else {
			//add it to the beginning of the list
			if(place == 0) {
				node.next = start;
				start = node;
			}
			//actually insert it in between two nodes 	
			else {
				FriendsNode before = start, after;
				for (int i = 0; i < place - 1; i++) { //find node before insertion point
					before = before.next;
				}
				after = before.next; //find node after 
				before.next = node; //inserts new node
				node.next = after; //sets new node next to after
			}
			count++; //more friends!
		}
	}
	/**
	 * Delete a friend </friend>
	 * @param friend - a friend!
	 * @param place - place that used to be a friend </3 (positive int)
	 */
	public void delete(int place) {
		//invalid input, too big or negative place int
		if(place > count || place < 0) {
			System.out.println("Wrong input. Positive int < friend count needed.");
		}
		//delete first friend
		else if(place == 0) {
			start = start.next; //really just set the first friend to the second
			count--;
		}
		//delete a friend that's not the first
		else {
			FriendsNode before = start;
			for(int i = 0; i < place - 1; i++) { //find friend before the notfriend
				before = before.next; 
			}
			//delete friend in the middle
			if(place + 1 < count)
				before.next = before.next.next;
			//delete last friend
			else if(place == count - 1) {
				before.next = null;
				end = before;
			}
			count--;
		}
	}
	/**
	 * Is it empty?
	 * @return boolean value for having no friends
	 */
	public boolean empty()
	{
		return (count == 0) ? true : false;
	}
	/**
	 * toString!
	 */
	@Override
	public String toString() {
		if(empty()) {
			return "There are no friends </3";
		}
		else {
			String str = "";
			FriendsNode current = start;
			do {
				str += current.friend.toString() + "\n";
				current = current.next;
			} while(current != null);
			return str;
		}
	}
}
