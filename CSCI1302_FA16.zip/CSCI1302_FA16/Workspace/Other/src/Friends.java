/**
 * Contains info about friends
 * @author Jacob Malimban
 * Lab 7 - Collections
 */
public class Friends {
	String firstName, lastName;
	int age;
	/**
	 * Constructor for Friends
	 * @param firstName - self explanatory
	 * @param lastName - ditto
	 * @param age - ditto again
	 */
	public Friends(String firstName, String lastName, int age) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
	}
	/**
	 * Gets First Name
	 * @return firstName
	 */
	public String getFirstName() {
		return firstName;
	}
	/**
	 * Sets First Name
	 * @param firstName
	 */
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	/**
	 * Gets Last Name
	 * @return lastName
	 */
	public String getLastName() {
		return lastName;
	}
	/**
	 * Sets Last Name
	 * @param lastName
	 */
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	/**
	 * Gets Age
	 * @return age
	 */
	public int getAge() {
		return age;
	}
	/**
	 * Sets Age
	 * @param age
	 */
	public void setAge(int age) {
		this.age = age;
	}
	/**
	 * Equals method to see if two Friends are the same
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Friends other = (Friends) obj;
		if (age != other.age)
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		return true;
	}
	/**
	 * toString Method
	 */
	@Override
	public String toString() {
		return firstName + " " + lastName + " is a(n) " + age + " year old friend.";
	}
}
