/*
 * +34 = (3+4)
 * *+543 = ((5+4)*3)
 * %*-+12345 = ((((1+2)-3)*4)%5)
 */
public class PrefixToInfix {

	public static void main(String[] args) {
		String prefix = "%*-+AB5DE";
		System.out.println(infix(prefix));
	}
	public static String infix(String prefix)
	{
		System.out.println("Prefix:"+prefix);
		String infix = "";
		if(prefix.length() > 0)
		{
			char test = prefix.charAt(0);
			switch(test)
			{
			case '/':
			case '*':
			case '-':
			case '+':
			case '%':
				//is a symbol, recursive step
				infix += "(";
				infix += infix(prefix.substring(1, prefix.length()-1));
				infix += test;
				infix += prefix.charAt(prefix.length()-1);
				infix += ")";
				break;
			default:
				infix += test;
				//not a symbol, base case
				break;
			}
			System.out.println("Infix:"+infix);
			return infix;
		}
		return "";
	}

}
