import java.util.Scanner;
public class Solution3 {
	public static String[][] grid;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		grid = new String[size][size];
		int y=0, x=0;
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				grid[i][j] = s.next().toUpperCase();
			}
		}
		String path = "";
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				path = traverse(j,i) + path;
			}
		}
		System.out.println(path);
	}
	public static String traverse(int x, int y)
	{
		String temp = grid[y][x];
		grid[y][x] = "";
		if(temp.equals("OPEN") || temp.equals(""))
			return temp;
		else
		{
			int distance = Integer.parseInt(""+temp.charAt(0));
			switch(temp.charAt(1))
			{
			case 'R':
				x+=distance;
				break;
			case 'L':
				x-=distance;
				break;
			case 'U':
				y-=distance;
				break;
			case 'D':
				y+=distance;
				break;
			}
			return temp + " " + traverse(x,y);
		}
	}
}