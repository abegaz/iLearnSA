import java.util.Scanner;
public class Solution2 {
	public static String[][] grid;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		grid = new String[size][size];
		int y=0, x=0;
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				grid[i][j] = s.next().toUpperCase();
				if(grid[i][j].equals("OPEN"))
				{
					x = j;
					y = i;
				}
			}
		}
		System.out.println(traverse(x,y));
	}
	public static String traverse(int x, int y)
	{
		for(int i = 0; i < 4; i++)
		{
			for(int j = 1; j < grid.length; j++)
			{
				int newX = x, newY = y;
				String test = j+"";
				switch(i)
				{
				case 0:
					newX -= j;
					test += "R";
					break;
				case 1:
					newX += j;
					test += "L";
					break;
				case 2:
					newY -= j;
					test += "D";
					break;
				case 3:
					newY += j;
					test += "U";
					break;
				}
				if(!isValid(newX, newY))
					break;
				else if(grid[newY][newX].equals(test))
					return traverse(newX, newY) + " " + grid[y][x];
			}
		}
		return grid[y][x];
	}
	public static boolean isValid(int x, int y)
	{
		if(y >=0 && y < grid.length && x >= 0 && x < grid[0].length)
			return true;
		return false;
	}
}