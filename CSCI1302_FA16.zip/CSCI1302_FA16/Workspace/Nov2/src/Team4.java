
public class Team4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
