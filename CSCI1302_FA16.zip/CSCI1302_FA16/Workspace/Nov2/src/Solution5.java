import java.util.Scanner;
public class Solution5 {
	public static String[][] grid;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		int size = s.nextInt();
		grid = new String[size][size];
		int y=0, x=0;
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				grid[i][j] = s.next().toUpperCase();
				if(grid[i][j].equals("OPEN"))
				{
					x = j;
					y = i;
				}
			}
		}
		System.out.println(traverse(x,y));
	}
	public static String traverse(int x, int y)
	{
		for(int j = 1; j < grid.length; j++)
		{
			int newX1 = x+j, newY1 = y+j, newX2 = x-j, newY2 = y-j;
			if(isValid(newX1, y) && grid[y][newX1].equals(j+"L"))
				return traverse(newX1, y) + " " + grid[y][x];
			if(isValid(newX2, y) && grid[y][newX2].equals(j+"R"))
				return traverse(newX2, y) + " " + grid[y][x];
			if(isValid(x, newY1) && grid[newY1][x].equals(j+"U"))
				return traverse(x, newY1) + " " + grid[y][x];
			if(isValid(x, newY2) && grid[newY2][x].equals(j+"D"))
				return traverse(x, newY2) + " " + grid[y][x];
		}
		return grid[y][x];
	}
	public static boolean isValid(int x, int y)
	{
		if(y >=0 && y < grid.length && x >= 0 && x < grid[0].length)
			return true;
		return false;
	}
}