import java.util.Arrays;
import java.util.Scanner;
/**
 * Something about cracking safes I think.
 * @author Jacob Malimban and Team 1
 * That took longer than expected
 * T_T
 * #deadinside
 */
public class Team1 {
	public static String[][] grid;
	public static int size;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		size = s.nextInt();
		grid = new String[size][size];
		int y=0, x=0;
		for(int i = 0; i < size; i++)
		{
			for(int j = 0; j < size; j++)
			{
				grid[i][j] = s.next().toUpperCase();
				if(grid[i][j].equals("OPEN"))
				{
					x = j;
					y = i;
				}
			}
		}
		traverse(x,y);
	}
	/**
	 * Check up, left, down, right for square that leads to current one
	 * Call method again on found square
	 * when no option found, you have completed the path
	 */
	public static void traverse(int x, int y)
	{
		for(int i = 0; i < size; i++){
			if(i != x){
				if(!(grid[y][i].equals("OPEN"))){
					int dis = 0;
					String dir = grid[y][i].substring(1);
					if(dir.equals("L"))
						dis = Integer.parseInt(grid[y][i].substring(0,1)) * -1;
					else if(dir.equals("R"))
						dis = Integer.parseInt(grid[y][i].substring(0,1));
					if(i + dis == x){
						traverse(i,y);
						break;
					}
				}
			}
			if (i != y){
				if(!(grid[i][x].equals("OPEN"))){
					int dis = 0;
					String dir = grid[i][x].substring(1);
					if(dir.equals("U"))
						dis = Integer.parseInt(grid[i][x].substring(0,1)) * -1;
					else if(dir.equals("D"))
						dis = Integer.parseInt(grid[i][x].substring(0,1));
					if(i + dis == y){
						traverse(x,i);
						break;
					}
				}
			}
		}
		System.out.print(grid[y][x].toString() + " ");
	}	
}
