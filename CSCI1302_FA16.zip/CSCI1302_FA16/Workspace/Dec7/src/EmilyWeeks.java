//Emily Weeks
//Chadd Monahan

import java.util.Scanner;
public class EmilyWeeks{
  public static void main(String[] args){
 Scanner scan1 = new Scanner(System.in);
 //Receiving variables
    int a = scan1.nextInt();
    int b = scan1.nextInt();
    int c = scan1.nextInt();
    int d = scan1.nextInt();
   
    int ab = absoluteSubtraction(a,b);
    int bc = absoluteSubtraction(b,c);
    int cd = absoluteSubtraction(c,d);
    int da = absoluteSubtraction(d,a);
    
    int count = 1;

   while(ab != bc || ab!= cd || ab != da || bc != cd || bc != da || cd != da){
	   ab = absoluteSubtraction(a,b);
	      bc = absoluteSubtraction(b,c);
	      cd = absoluteSubtraction(c,d);
	      da = absoluteSubtraction(d,a);

	      System.out.print("Step " + count + ": ");
	      System.out.print(ab + " ");
	      System.out.print(bc + " ");
	      System.out.print(cd + " ");
	      System.out.println(da + " ");
	      
	      a = ab;
	      b = bc;
	      c = cd;
	      d = da;
	      
	      count++;
    }

      //Printing results
     
      System.out.println("Steps: " + (count-1));
    }
  public static int absoluteSubtraction(int x,int y){
     int result = (x-y);
     result = Math.abs(result);
     return result;
   }
}
