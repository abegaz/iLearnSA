import java.util.Scanner;

public class Solution {
	public static int a = 0,b = 0, c = 0, d = 0, count = 0;
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		a = s.nextInt();
		b = s.nextInt();
		c = s.nextInt();
		d = s.nextInt();
		solve();
		System.out.println(count + " Step" +((count==1)?"":"s"));
	}
	public static void solve()
	{
		if(a == b && b == c && c == d)
		{}
		else
		{
			int at, bt, ct, dt;
			at = Math.abs(a-b);
			bt = Math.abs(b-c);
			ct = Math.abs(c-d);
			dt = Math.abs(d-a);
			a = at;
			b = bt;
			c = ct;
			d = dt;
			count++;
			System.out.println("Step "+count+": " + a + " " + b + " " + c + " " + d);
			solve();
		}
	}
}
