//Subtraction.java
//Evan Myers and Michael Simica
//07DEC2016
//Final exam bonus

import java.util.Scanner;

public class EvanMyers {
	int a, b, c, d;
	static int steps;
	

	public EvanMyers(int a, int b, int c, int d) {
		super();
		this.a = a;
		this.b = b;
		this.c = c;
		this.d = d;
	}

	public static void subtract(int a,int b,int c,int d)
	{
		if (a!=b||a!=c||a!=d)
		{
			steps++;
			int z = Math.abs(a-b);
			int i = Math.abs(b-c);
			int k = Math.abs(c-d);
			int x = Math.abs(d-a);
			System.out.println("Step " + steps + ": " + z + " " + i + " " + k + " " + x);
			a = z;
			b = i;
			c = k;
			d = x;
			subtract(a,b,c,d);	

		}

		

	}
	
	public static void main(String[] args)
	{
		Scanner scan = new Scanner (System.in);
		
		int a, b, c, d;
		a= scan.nextInt();
		b= scan.nextInt();
		c = scan.nextInt();
		d= scan.nextInt();
		subtract(a, b, c, d);
		System.out.println("Total steps: " + steps);

		
	}

}
