import java.util.Scanner;

//Tristan Derloshon and Nolan Flynn

public class TristanDerloshon {
	
	public static int count = 0;

	public static void absValue(int a,int b,int c, int d)
	{
		int aCopy=a;
		if(a==b && a==c && a==d && b==c && b==d && c==d)
		{
			System.out.println(count + " Steps");
		}
		else
		{
			a = Math.abs(a-b);
			b = Math.abs(b-c);
			c = Math.abs(c-d);
			d = Math.abs(d-aCopy);
			count++;
			System.out.println("Step " + count + ": " + a + " " + b + " " + c + " " + d);
			absValue(a,b,c,d);
		}
	}
	
	
	public static void main(String[] args) {
		int n1,n2,n3,n4,temp1, temp2, temp3, temp4;
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter 4 ints: ");
		
		n1=scan.nextInt();
		n2=scan.nextInt();
		n3=scan.nextInt();
		n4=scan.nextInt();
		
		System.out.println(n1 + " " + n2 + " " + n3 + " " + n4);
		absValue(n1, n2,n3,n4);
		
	
		
		
		
	}

}
