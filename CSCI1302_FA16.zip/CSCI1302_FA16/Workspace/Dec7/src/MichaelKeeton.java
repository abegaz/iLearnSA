//Chase Lawson and Michael Keeton

import java.util.Scanner;

public class MichaelKeeton {

	//public int n1, n2, n3, n4, temp;
	public static int n1, n2, n3, n4, temp, count;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter 4 numbers: ");
		n1 = scan.nextInt();
		n2 = scan.nextInt();
		n3 = scan.nextInt();
		n4 = scan.nextInt();
		
		solve(n1,n2,n3,n4);
		
		
		
	}
	
	
	
	public static void solve(int num1, int num2, int num3, int num4)
	{
		
		count++;
		temp = num1;
		n1 = Math.abs(num1 - num2);
		n2 = Math.abs(num2 - num3);
		n3 = Math.abs(num3 - num4);
		n4 = Math.abs(num4 - temp);
		
		System.out.println("Step " + count + ": " + n1 + " " + n2 + " " + n3 + " " + n4);
		if (n1 == n2 && n1 == n2 && n1 == n3 && n1 == n4)
			System.out.println(count + " Steps");
		else
			solve(n1,n2,n3,n4);
		
		
	}
}
