

/*	
* Kyle Wilson
* Ethan David
* CSCI 1302
* 12/07/16
* Final Exam Bonus Competition
*/

//package Differences;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
public class EthanDavid extends JPanel implements ActionListener {
		  public static JTextField one = new JTextField(5);
	      public static JTextField two = new JTextField(5);
	     public static  JTextField three = new JTextField(5);
	      public static JTextField four = new JTextField(5);
	      public static JTextArea word = new JTextArea(5, 20);
	      public static JButton abutton = new JButton("Press");
	      public EthanDavid() {
	      super();
	      word.setEditable(false);
	      add(new JLabel("number 1: "));
	      add(one);
	      add(Box.createHorizontalStrut(7)); // a spacer
	      add(new JLabel("number 2: "));
	      add(two);
	      add(new JLabel("number3: "));
	      add(three);
	      add(Box.createHorizontalStrut(15));
	      add(new JLabel("number4: "));
	      add(four);
	      add(Box.createHorizontalStrut(15));
	      add(abutton);
	      JScrollPane leScrollPane = new JScrollPane(word);
	      add(leScrollPane);
	      abutton.addActionListener(this);
	      }
	public static void main(String[] args) {
		 JFrame frame = new JFrame();
		 frame.setPreferredSize(new Dimension(720,200));
	      frame.add(new EthanDavid());
	      frame.pack();
	      frame.setVisible(true);

	}
	public static int[] calcDifference(int a, int b, int c, int d) {
		return calcDifference(a,b,c,d,0);
	}
	public static int[] calcDifference(int a, int b, int c, int d, int step) {
		if (!(a == b && b == c && c == d && d == a)) {
			int aa = Math.abs(a-b);
			int bb = Math.abs(b-c);
			int cc = Math.abs(c-d);
			int dd = Math.abs(d-a);
			step++;
			word.append("Step "+step+": "+aa+" "+bb+" "+cc+" "+dd+"\n");
			return calcDifference(aa,bb,cc,dd,step);
		} else {
			int[] out = {a,b,c,d,step};
			//word.append("Step "+step+": "+a+" "+b+" "+c+" "+d+"\n");
			word.append(step+" Steps");
			return out;
		}
	}
	public void actionPerformed(ActionEvent e) {
		word.setText("");
		calcDifference(Integer.parseInt(one.getText()),Integer.parseInt(two.getText()),Integer.parseInt(three.getText()),Integer.parseInt(four.getText()));
	}
}

