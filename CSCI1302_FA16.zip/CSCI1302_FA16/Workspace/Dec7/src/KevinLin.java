import java.util.Scanner;
public class KevinLin {
	public static void main(String[]args){
		int a, b, c, d, aa, bb, cc, dd;
		int count = 0;
		Scanner input = new Scanner(System.in);
		
		a = input.nextInt();
		b = input.nextInt();
		c = input.nextInt();
		d = input.nextInt();
		
		while(a!=b || b!=c || c!=d || d!=a){
			aa=a;
			bb=b;
			cc=c;
			dd=d;
			
			a-=bb;
			b-=cc;
			c-=dd;
			d-=aa;
			if(a < 0){
				a*=-1;
			}
			if(b < 0){
				b*=-1;
			}
			if(c < 0){
				c*=-1;
			}
			if(d < 0){
				d*=-1;
			}
			count++;
			System.out.println("Step " + count + ": " + a + " " + b + " " + c + " " + d);
		}
		System.out.println(count + " Steps");
		input.close();
	}
}
