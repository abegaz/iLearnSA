import java.util.Scanner;

public class UserExample {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("Enter how many numbers you want:");
		int count = scan.nextInt();

		int[] numbers = new int[count];

		for(int i = 0; i < numbers.length; i++)
		{
			System.out.print("Enter a number:");
			numbers[i] = scan.nextInt();
		}
		System.out.println("The numbers you entered:");
		for(int number : numbers)
			System.out.println(number);

	}

}
