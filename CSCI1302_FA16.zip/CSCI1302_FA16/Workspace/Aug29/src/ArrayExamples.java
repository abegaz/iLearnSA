import java.util.Random;

public class ArrayExamples {

	public static void main(String[] args) {
		Random rand = new Random();
		int[] scores = new int[10];//zero to length-1
		String[] names = new String[100];
		//object not initialized yet
		//System.out.println(names[0].length());

		scores[5] = 100;
		System.out.println(scores[5]);
		scores[4] = scores[5] - 20;
		System.out.println(scores[4]);

		for(int i = 0; i < scores.length; i++)
		{
			scores[i] = 10 + (i*5);
		}
		for(int score : scores)
			System.out.println(score);

		//outside of bounds of array size
		//System.out.println(scores[10]);

		for(int i = scores.length-1; i >= 0; i--)
		{
			scores[i] = rand.nextInt(101);
		}
		for(int score : scores)
			System.out.println(score);

		int[] numbers = {1,2,3,4,5,6};


		Coin[] coins = new Coin[1000000];
		for(int i = 0; i < coins.length; i++)
			coins[i] = new Coin();

		int sumHeads = 0;
		int sumTails = 0;
		for(Coin coin : coins)
		{
			if(coin.isHeads())
				sumHeads++;
			else
				sumTails++;
		}
		System.out.println("Number of Heads: " + sumHeads);
		System.out.println("Number of Tails: " + sumTails);
	}

}
