
public class MyMethods {
	public static double average(int ... list)
	{
		double sum = 0;
		for(int item : list)
			sum += item;
		return sum / list.length;
	}
	public static int distance(int ... distances)
	{
		int distance = 0;
		for(int i = 0; i < distances.length; i++)
			distance += distances[i];
		return distance;
	}
	public static String example(String name, int num, MyMethods ... list)
	{

		return "";
	}
}
