
public class VariableLength {

	public static void main(String[] args) {
		System.out.println(MyMethods.average(1,2,3,4,56,7,8,9,3,1,5,1));
		System.out.println(MyMethods.distance(1,2,3,4,56,7,8,9,3,1,5));

	}

}
