import java.util.Arrays;

public class MultiArrays {

	public static void main(String[] args) {
		double[] numbers = new double[5];

		double[][] lotsOfNumbers = new double[10][5];

		for(int i = 0; i < lotsOfNumbers.length; i++)
		{
			for(int j = 0; j < lotsOfNumbers[0].length; j++)
			{
				lotsOfNumbers[i][j] = Math.random();
			}
		}

		System.out.println(lotsOfNumbers[5][3]);
		System.out.println(lotsOfNumbers[9][4]);
		System.out.println(lotsOfNumbers[0][0]);

		numbers = lotsOfNumbers[0];

		System.out.println(numbers);
		System.out.println(numbers[0]);

		System.out.println(Arrays.toString(numbers));
		System.out.println(Arrays.deepToString(lotsOfNumbers));
		for(double[] someNumbers : lotsOfNumbers)
		{
			for(double aNumber : someNumbers)
				System.out.print(aNumber+", ");
			System.out.println();
		}

	}

}
