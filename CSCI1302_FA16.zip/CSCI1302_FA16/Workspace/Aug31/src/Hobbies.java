




import java.util.Arrays;
import java.util.Scanner;

public class Hobbies {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		//ask user for number of hobbies
		System.out.print("Enter the number of hobbies you have: ");
		int hobbies = scan.nextInt();
		scan.nextLine();

		//set up multi-dimensional array to store hobby information
		// - Name[0], Hours[1], Number of People[2]
		String[][] myHobbies = new String[hobbies][3];

		//Ask user for the information on each hobby
		for(int i = 0; i < myHobbies.length; i++)
		{
			System.out.print("Enter the name of the hobby: ");
			myHobbies[i][0] = scan.nextLine();
			System.out.print("Enter the hours spent doing the hobby per week: ");
			myHobbies[i][1] = scan.nextLine();
			System.out.print("Enter the number of people you do the hobby with: ");
			myHobbies[i][2] = scan.nextLine();
		}

		//Print out all the data received from the user
		//System.out.println(Arrays.deepToString(myHobbies));//confirm data being stored in array correctly
		double totalHours = 0;
		double totalPeople = 0;
		System.out.println("Name : Hours : People");
		for(String[] myHobby : myHobbies)
		{
			System.out.println(myHobby[0] + " : " + myHobby[1] + " : " + myHobby[2]);
			totalHours += Double.parseDouble(myHobby[1]);
			totalPeople += Double.parseDouble(myHobby[2]);
		}
		
		//Print out the total number of hours spent on hobbies
		System.out.println("The total hours spent on hobbies is: " + totalHours);
		
		//Print out the average number of people they do hobbies with
		System.out.println("The average number of people you do hobbies with is: " + (totalPeople/myHobbies.length));

	}

}
