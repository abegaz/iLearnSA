import java.text.DecimalFormat;
import java.util.Scanner;

public class CourseList {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		
		//Ask the user for the number of courses
		System.out.print("Enter the number of courses you have completed: ");
		int numCourses = scan.nextInt();
		
		//Create a multi-dimensional array to store the course information
		//- Number[0], Grade(0-4)[1], Credit Hours[2], Quality Points[3]
		int[][] courses = new int[numCourses][4];
		
		//Ask the user for the course number, grade, credit hours
		//calculate the quality points (grade * credit hours)
		for(int i = 0; i < courses.length; i++)
		{
			System.out.print("Enter the course number: ");
			courses[i][0] = scan.nextInt();
			System.out.print("Enter the course grade(0-4): ");
			courses[i][1] = scan.nextInt();
			System.out.print("Enter the course credit hours: ");
			courses[i][2] = scan.nextInt();
			//calculate quality points
			courses[i][3] = courses[i][1] * courses[i][2];//grade * credit hours
		}
		
		//print all the courses
		//create a running total of credit hours and quality points
		double totalCreditHours = 0;
		double totalQualityPoints = 0;
		System.out.println("COURSES:");
		System.out.println("Number : Grade : Hours : Quality Points");
		for(int[] course : courses)
		{
			System.out.println(course[0] + " : " + course[1] + " : " + course[2] + " : " + course[3]);
			totalCreditHours += course[2];
			totalQualityPoints += course[3];
		}
		
		DecimalFormat df = new DecimalFormat("0.00");
		//print an overall gpa (quality points / credit hours)
		System.out.println("\n\nOverall GPA: " + df.format(totalQualityPoints/totalCreditHours));
	}

}
