
public class Fibonacci {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//System.out.println(fib(50));
		System.out.println(fib(0));
		System.out.println(fib(1));
		System.out.println(fib(2));
		System.out.println(fib(3));
		System.out.println(fib(4));
		System.out.println(fib(5));
		System.out.println(fib(6));
		System.out.println(fib(7));
		System.out.println("40:" + fib(40));
		System.out.println("45:" + fib(45));
	}
	public static int fib(int n)
	{
		if(n == 0)//base case
			return 0;
		else if(n == 1)//base case
			return 1;
		else//sum of previous 2 fibonacci numbers
			return fib(n-1) + fib(n-2);
	}
}
