public class RegionSearch
{
   public static void main(String[] args)
   {
      FindRegions labyrinth = new FindRegions();
      System.out.println(labyrinth);
      System.out.println("Region Count: " + labyrinth.countRegions());
      System.out.println(labyrinth);
   }
}