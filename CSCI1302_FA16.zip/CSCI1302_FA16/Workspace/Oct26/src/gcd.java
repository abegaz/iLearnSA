
public class gcd {

	public static void main(String[] args) {
		System.out.println(gcd(8, 12));
		System.out.println(gcd(24, 54));
		System.out.println(gcd(13, 5));

	}
	public static int gcd(int n1, int n2)
	{
		System.out.println("n1:" + n1 + " :: n2:" + n2);
		if(n1 < n2)
			gcd(n2, n1);//force n1 to be >= n2

		int r = n1 % n2;//remainder of larger divided by smaller

		if(r == 0)
			return n2;//if divides equally, return smaller
		else
			return gcd(n2, r);//else re-run with smaller and remainder
	}

}
