import java.util.Arrays;

public class DepartmentWebsite extends Website {
	private String name;
	private Faculty[] facultyMembers;
	public DepartmentWebsite(String protocol, String subdomain, String domain, String topLevelDomain, String path,
			String name, Faculty[] facultyMembers) {
		super(protocol, subdomain, domain, topLevelDomain, path);
		this.name = name;
		this.facultyMembers = facultyMembers;
	}
	public void displayContent()
	{
		System.out.println("Web Content: "+toString());
	}
	@Override
	public String toString() {
		return name+" Website, faculty members :" + Arrays.toString(facultyMembers) + ";"+super.toString();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		DepartmentWebsite other = (DepartmentWebsite) obj;
		if (!Arrays.equals(facultyMembers, other.facultyMembers))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}
}
