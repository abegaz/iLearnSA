
public interface Content {
	public void displayContent();
}
