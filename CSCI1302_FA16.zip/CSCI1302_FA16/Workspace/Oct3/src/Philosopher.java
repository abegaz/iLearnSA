
public class Philosopher implements Speaker {

	@Override
	public void speak() {
		System.out.println("I think therefore I am");

	}

	@Override
	public void announce(String str) {
		System.out.println("Contemplate: " + str);

	}

}
