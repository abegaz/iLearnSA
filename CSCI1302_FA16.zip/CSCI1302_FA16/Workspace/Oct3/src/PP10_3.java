
public class PP10_3 {

	public static void main(String[] args) {
		//Generic variable container with specific object types that are different than container
		Speaker[] speakers = new Speaker[3];
		speakers[0] = new Dictator();
		speakers[1] = new Philosopher();
		speakers[2] = new Teacher();

		for(Speaker speaker : speakers)
		{
			//polymorphic references
			speaker.speak();
			speaker.announce("Announcement");
		}

		//accessing child methods
		((Dictator)speakers[0]).conquer();

		((Teacher)speakers[2]).test();

		((Dictator)speakers[1]).conquer();//error because object is not actually Dictator class

	}

}
