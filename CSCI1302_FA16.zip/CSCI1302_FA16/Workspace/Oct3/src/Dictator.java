
public class Dictator implements Speaker {

	@Override
	public void speak() {
		System.out.println("For the motherland!");

	}

	@Override
	public void announce(String str) {
		System.out.println(str.toUpperCase()+"!!!!!");

	}
	
	public void conquer()
	{
		System.out.println("TAKE OVER THE WORLD!!");
	}

}
