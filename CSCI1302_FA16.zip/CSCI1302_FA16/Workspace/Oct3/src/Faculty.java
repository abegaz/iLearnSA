
public class Faculty {
	private String name;
	private String coursesTaught;
	public Faculty(String name, String coursesTaught) {
		super();
		this.name = name;
		this.coursesTaught = coursesTaught;
	}
	@Override
	public String toString() {
		return name + " teaches " + coursesTaught;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Faculty other = (Faculty) obj;
		if (coursesTaught == null) {
			if (other.coursesTaught != null)
				return false;
		} else if (!coursesTaught.equals(other.coursesTaught))
			return false;
		if (name == null) {
			if (other.name != null)
				return false;
		} else if (!name.equals(other.name))
			return false;
		return true;
	}

}
