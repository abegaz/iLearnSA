
public class FacultyWebsite extends Website {
	private Faculty fac;

	public FacultyWebsite(String protocol, String subdomain, String domain, String topLevelDomain, String path,
			Faculty fac) {
		super(protocol, subdomain, domain, topLevelDomain, path);
		this.fac = fac;
	}

	public void displayContent()
	{
		System.out.println("Web Content: "+toString());
	}

	@Override
	public String toString() {
		return fac + " and has a website with the url " + getURL();
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		FacultyWebsite other = (FacultyWebsite) obj;
		if (fac == null) {
			if (other.fac != null)
				return false;
		} else if (!fac.equals(other.fac))
			return false;
		return true;
	}

}
