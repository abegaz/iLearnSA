
public class WebsiteDriver {

	public static void main(String[] args) {
		/*
		Website ung = new Website("http", "www", "ung", "edu", "directory");
		System.out.println(ung);
		Faculty jet = new Faculty("JET", "CSCI1302, CSCI3000");
		System.out.println(jet);
		FacultyWebsite jetWeb = new FacultyWebsite("http", "www", "ung", "edu", "it", jet);
		System.out.println(jetWeb);
		Faculty sean = new Faculty("Sean", "CSCI2250");
		DepartmentWebsite csWeb = new DepartmentWebsite("http", "www", "ung", "edu", "computer-science",
				"Computer Science", new Faculty[]{jet, sean});
		System.out.println(csWeb);

		ung.displayContent();
		jetWeb.displayContent();
		csWeb.displayContent();
		*/
		Faculty jet = new Faculty("JET", "CSCI1302, CSCI3000");
		Faculty sean = new Faculty("Sean", "CSCI2250");
		Website[] sites = new Website[3];
		sites[0] = new Website("http", "www", "ung", "edu", "directory");
		sites[1] = new FacultyWebsite("http", "www", "ung", "edu", "it", jet);
		sites[2] = new DepartmentWebsite("http", "www", "ung", "edu", "computer-science",
				"Computer Science", new Faculty[]{jet, sean});

		//Polymorphism through inheritance
		for(Website site : sites)
		{
			site.displayContent();
			System.out.println(site.getURL());
			System.out.println();
		}

		Content[] contentPages = new Content[3];
		contentPages[0] = new Website("http", "www", "ung", "edu", "directory");
		contentPages[1] = new FacultyWebsite("http", "www", "ung", "edu", "it", jet);
		contentPages[2] = new DepartmentWebsite("http", "www", "ung", "edu", "computer-science",
				"Computer Science", new Faculty[]{jet, sean});

		//Polymorphism through interfaces
		for(Content contentPage : contentPages)
		{
			contentPage.displayContent();
			System.out.println(((Website)contentPage).getURL());//Polymorphism through inheritance
			System.out.println();
		}

	}

}
