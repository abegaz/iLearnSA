
public class Teacher implements Speaker {

	@Override
	public void speak() {
		System.out.println("Good afternoon class.");

	}

	@Override
	public void announce(String str) {
		System.out.println("Present:"+str);

	}

	public void test(){
		System.out.println("Get ready for the test.");
	}

}
