
public class Website implements Content {
	private String protocol;//http
	private String subdomain;//www
	private String domain;//ung
	private String topLevelDomain;//edu
	private String path;//directory
	public Website(String protocol, String subdomain, String domain, String topLevelDomain, String path) {
		super();
		this.protocol = protocol;
		this.subdomain = subdomain;
		this.domain = domain;
		this.topLevelDomain = topLevelDomain;
		this.path = path;
	}
	public String getURL()
	{
		return protocol+"://"+subdomain+"."+domain+"."+topLevelDomain+"/"+path;
	}
	@Override
	public String toString() {
		return "Website URL: "+getURL();
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Website other = (Website) obj;
		if (domain == null) {
			if (other.domain != null)
				return false;
		} else if (!domain.equals(other.domain))
			return false;
		if (path == null) {
			if (other.path != null)
				return false;
		} else if (!path.equals(other.path))
			return false;
		if (protocol == null) {
			if (other.protocol != null)
				return false;
		} else if (!protocol.equals(other.protocol))
			return false;
		if (subdomain == null) {
			if (other.subdomain != null)
				return false;
		} else if (!subdomain.equals(other.subdomain))
			return false;
		if (topLevelDomain == null) {
			if (other.topLevelDomain != null)
				return false;
		} else if (!topLevelDomain.equals(other.topLevelDomain))
			return false;
		return true;
	}
	@Override
	public void displayContent() {
		System.out.println("Basic Content");

	}

}
