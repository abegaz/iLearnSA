
public class SpeakerTester {

	public static void main(String[] args) {
		Philosopher p = new Philosopher();
		Dictator d = new Dictator();
		p.speak();
		d.speak();
		
		Speaker s1 = new Philosopher();
		Speaker s2 = new Dictator();
		
		s1.speak();
		s2.speak();
		d.conquer();
		((Dictator)s2).conquer();

	}

}
