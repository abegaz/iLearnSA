import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

public class SplitTree {
	public static ArrayList<String> paths = new ArrayList<>();
	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);

		/*
		System.out.println(Arrays.toString(splitTree("(a()())")));
		System.out.println(Arrays.toString(splitTree("(a(b()())(c()()))")));
		System.out.println(Arrays.toString(splitTree("(a(b()(d()()))(c(e()())()))")));
(A(B(D()())())(C(E()())(F()())))
		*/

		traverse(scan.nextLine(), "");
		System.out.println(paths);
	}
	public static void traverse(String tree, String path)
	{
		String[] parts = splitTree(tree);
		System.out.println(parts[0]);//root
		System.out.println(parts[1]);//left
		System.out.println(parts[2]);//right
		//paths.add(path);//how to add solutions to array list
	}
	/*
	Takes in tree : (node tree tree)
	Returns pieces: [0] = node, [1] = leftTree, [2] = rightTree
	*/
	public static String[] splitTree(String tree){
		//expected tree format
		//(node tree tree)
		//0 1 2-x x-(length-2) length-1
		if(tree.length() <= 2)//tree not long enough to process
			return new String[]{tree, "", ""};
		String[] temp = new String[3];
		temp[0] = "" + tree.charAt(1);//grab tree node
		tree = tree.substring(2, tree.length()-1);//remove node and outer paren
		int parenCount = 0;//count of open paren
		int endTreeOne = 0;//end of first tree
		for(int i = 0; i < tree.length(); i++){
			if(tree.charAt(i) == '(')
				parenCount++;
			if(tree.charAt(i) == ')')
				parenCount--;
			if(parenCount == 0){
				endTreeOne = i;
				break;//ends for loop early
			}
		}
		temp[1] = tree.substring(0, endTreeOne+1);//left tree
		temp[2] = tree.substring(endTreeOne+1);//right tree
		return temp;
	}

}
