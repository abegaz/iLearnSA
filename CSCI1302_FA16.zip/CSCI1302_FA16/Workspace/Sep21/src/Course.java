
public abstract class Course implements Comparable<Course> {
	//Instance Data
	private String title;
	private String number;
	private String description;
	private String prefix;
	private String department;
	//Constructor
	public Course(String title, String number, String description, String prefix, String department) {
		super();
		this.title = title;
		this.number = number;
		this.description = description;
		this.prefix = prefix;
		this.department = department;
		courseCount++;//increment static variable every time a course object is created
	}
	//Getters/Setters
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		if(number.length() == 4)
			this.number = number;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		if(prefix.length() == 3 || prefix.length() == 4)
			this.prefix = prefix;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	@Override
	public String toString() {
		return prefix+number+" "+title+" : "+description+ ":"+department;
	}
	//Comparable Interface Method CompareTo
	//checks if course number is greater/less/equal with another course object
	@Override
	public int compareTo(Course arg0) {
		if(Integer.parseInt(this.number) > Integer.parseInt(arg0.getNumber()))
			return 1;
		else if(Integer.parseInt(this.number) < Integer.parseInt(arg0.getNumber()))
			return -1;
		return 0;
	}
	//Static examples
	private static int courseCount;
	public static int getCourseCount()
	{
		return courseCount;
	}
}
/*
 * Course Info:
 * 		Title
 * 		Prefix
 * 		Number
 * 		Description
 * 		Department
 * Output Course Information
 * Group Courses
 *
 *
 * Course //parent - abstract
 * CSCICourse //child :: BUSACourse //child :: MATHCourse //child
 *
 */