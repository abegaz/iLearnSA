import java.util.Arrays;

public class CSCICourse extends Course {
	private String[] numbers = new String[]{"1301", "1302", "3000"};
	public CSCICourse(String title, String number, String description) {
		super(title, number, description, "CSCI", "Computer Science");
		// TODO Auto-generated constructor stub
	}

	@Override
	public void setNumber(String number) {
		if(Arrays.asList(numbers).contains(number))
			super.setNumber(number);
	}


}
