
public class CourseDriver {

	public static void main(String[] args) {
		//Course c = new Course("Intro programming 1", "1301", "Learn Java 1", "", "");
		CSCICourse cs1 = new CSCICourse("Intro programming 1", "1301", "Learn Java 1");
		CSCICourse cs2 = new CSCICourse("Intro programming 2", "1302", "Learn Java 2");

		System.out.println(cs1);
		System.out.println(cs2);
		cs1.setNumber("1234");
		System.out.println(cs1);
	}

}
/*
 * Course Info:
 * 		Title
 * 		Prefix
 * 		Number
 * 		Description
 * 		Department
 * Output Course Information
 * Group Courses
 *
 *
 * Course //parent - abstract
 * CSCICourse //child :: BUSACourse //child :: MATHCourse //child
 *
 */