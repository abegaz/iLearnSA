
abstract public class AbstractThought {
	abstract public void message();
	public void NotAbstract()
	{
		System.out.println("Ancestor");
	}

}
