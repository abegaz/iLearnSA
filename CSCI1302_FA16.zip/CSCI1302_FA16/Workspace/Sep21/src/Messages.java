//********************************************************************
//  Messages.java       Author: Lewis/Loftus
//
//  Demonstrates the use of an overridden method.
//********************************************************************

public class Messages
{
   //-----------------------------------------------------------------
   //  Creates two objects and invokes the message method in each.
   //-----------------------------------------------------------------
   public static void main(String[] args)
   {
	  //AbstractThought ancestor = new AbstractThought();//parent
	  Thought parked = new Thought();//parent
      Advice dates = new Advice();//child

      System.out.println("Parent Object");
      parked.message();
      parked.parentMethodOnly();
      //parked.childOnlyMethod();//doesn't exist in parent class
      System.out.println("Child Object");
      dates.message();  // overridden
      dates.parentMethodOnly();
      dates.childOnlyMethod();
   }
}
