//********************************************************************
//  Thought.java       Author: Lewis/Loftus
//
//  Represents a stray thought. Used as the parent of a derived
//  class to demonstrate the use of an overridden method.
//********************************************************************

public class Thought extends AbstractThought
{
   //-----------------------------------------------------------------
   //  Prints a message.
   //-----------------------------------------------------------------
   public void message()
   {
      System.out.println("I feel like I'm diagonally parked in a " +
                         "parallel universe.");

      System.out.println();
   }
   //overload
   public void message(String text)
   {
	   System.out.println(text);
	   System.out.println();
  }
   public void anotherMethod(String text)
   {
	   System.out.println(text);
	   System.out.println();

   }
   final public void parentMethodOnly()
   {
	   System.out.println("Parent's method");
   }
}
